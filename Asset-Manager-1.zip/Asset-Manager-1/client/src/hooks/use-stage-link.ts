import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type PostInput, type ProfileInput, type BookingInput } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";
import type { Profile, Application } from "@shared/schema";

// ============================================
// POSTS (Feed)
// ============================================

export function usePosts(filters?: { search?: string; category?: string; sortBy?: "Newest" | "Pay"; includeNsfw?: boolean; postType?: string }) {
  const queryKey = [api.posts.list.path, filters];

  return useQuery({
    queryKey,
    queryFn: async () => {
      const url = new URL(api.posts.list.path, window.location.origin);
      if (filters?.search) url.searchParams.append("search", filters.search);
      if (filters?.category && filters.category !== "All") url.searchParams.append("category", filters.category);
      if (filters?.sortBy) url.searchParams.append("sortBy", filters.sortBy);
      if (filters?.includeNsfw) url.searchParams.append("includeNsfw", "true");
      if (filters?.postType && filters.postType !== "all") url.searchParams.append("postType", filters.postType);

      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch posts");
      return res.json();
    },
  });
}

export function useCreatePost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: PostInput) => {
      const validated = api.posts.create.input.parse(data);

      const res = await fetch(api.posts.create.path, {
        method: api.posts.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create post");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.posts.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.credits.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.me.get.path] });
      toast({
        title: "Post Created",
        description: "Your opportunity is live on the feed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

// ============================================
// PROFILES
// ============================================

export function useProfiles() {
  return useQuery<{ profiles: Profile[]; viewerCategory: string | null; hasProfile: boolean; nsfwBlocked: boolean; allowedCategories: string[]; categoryGroupName: string | null }>({
    queryKey: [api.profiles.list.path],
    queryFn: async () => {
      const res = await fetch(api.profiles.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch profiles");
      return res.json();
    },
  });
}

export function useProfile(slug: string) {
  return useQuery({
    queryKey: [api.profiles.getBySlug.path, slug],
    queryFn: async () => {
      const url = buildUrl(api.profiles.getBySlug.path, { slug });
      const res = await fetch(url, { credentials: "include" });

      if (res.status === 404) return null;
      if (res.status === 403) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.message || "This profile is restricted.");
      }
      if (!res.ok) throw new Error("Failed to fetch profile");

      return res.json();
    },
    enabled: !!slug,
  });
}

export function useMyProfile() {
  return useQuery({
    queryKey: [api.me.get.path],
    queryFn: async () => {
      const res = await fetch(api.me.get.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch user data");
      return res.json();
    },
    retry: false,
  });
}

export function useCreateProfile() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: ProfileInput) => {
      const validated = api.profiles.create.input.parse(data);

      const res = await fetch(api.profiles.create.path, {
        method: api.profiles.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create profile");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.profiles.list.path] });
      queryClient.invalidateQueries({ queryKey: [api.me.get.path] });
      toast({
        title: "Profile Updated",
        description: "Your Re-Up Spots profile is now active.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

// ============================================
// BOOKINGS
// ============================================

export function useCreateBooking() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (data: BookingInput) => {
      const validated = api.bookings.create.input.parse(data);

      const res = await fetch(api.bookings.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });

      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to create booking");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.myBookings.path] });
      queryClient.invalidateQueries({ queryKey: [api.credits.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.me.get.path] });
      toast({
        title: "Booking Created",
        description: "Your booking request has been submitted.",
      });
    },
    onError: (error) => {
      toast({
        title: "Booking Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useMyBookings() {
  return useQuery({
    queryKey: [api.bookings.myBookings.path],
    queryFn: async () => {
      const res = await fetch(api.bookings.myBookings.path, { credentials: "include" });
      if (res.status === 401) return [];
      if (!res.ok) throw new Error("Failed to fetch bookings");
      return res.json();
    },
    retry: false,
  });
}

export function useMarkBookingPaid() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async ({ bookingId, installment }: { bookingId: number; installment?: "deposit" | "final" }) => {
      const res = await fetch(`/api/bookings/${bookingId}/mark-paid`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(installment ? { installment } : {}),
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to mark as paid");
      }
      return res.json();
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.myBookings.path] });
      const label = variables.installment === "deposit" ? "Deposit" : variables.installment === "final" ? "Final Payment" : "Payment";
      toast({
        title: `${label} Submitted`,
        description: "Awaiting admin confirmation.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useConfirmBooking() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (bookingId: number) => {
      const res = await fetch(`/api/bookings/${bookingId}/confirm`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to confirm booking");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.myBookings.path] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/bookings"] });
      toast({
        title: "Booking Confirmed",
        description: "Payment verified and booking confirmed.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useCancelBooking() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (bookingId: number) => {
      const res = await fetch(`/api/bookings/${bookingId}/cancel`, {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to cancel booking");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.bookings.myBookings.path] });
      toast({
        title: "Booking Cancelled",
        description: "The booking has been cancelled.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  });
}

export function useBookingPaymentInfo(bookingId: number | null) {
  return useQuery({
    queryKey: ["/api/bookings", bookingId, "payment-info"],
    queryFn: async () => {
      if (!bookingId) return null;
      const res = await fetch(`/api/bookings/${bookingId}/payment-info`, { credentials: "include" });
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!bookingId,
  });
}

// ============================================
// CREDITS
// ============================================

export function useCredits() {
  return useQuery({
    queryKey: [api.credits.get.path],
    queryFn: async () => {
      const res = await fetch(api.credits.get.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch credits");
      return res.json();
    },
    retry: false,
  });
}

export function useCreditLogs() {
  return useQuery({
    queryKey: [api.credits.logs.path],
    queryFn: async () => {
      const res = await fetch(api.credits.logs.path, { credentials: "include" });
      if (res.status === 401) return [];
      if (!res.ok) throw new Error("Failed to fetch credit logs");
      return res.json();
    },
    retry: false,
  });
}

// ============================================
// ADMIN
// ============================================

// ============================================
// APPLICATIONS
// ============================================

export function useApplyToPost() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  return useMutation({
    mutationFn: async (postId: number) => {
      const res = await fetch(api.applications.create.path, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ postId }),
        credentials: "include",
      });
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || "Failed to apply");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.applications.mine.path] });
      queryClient.invalidateQueries({ queryKey: [api.credits.get.path] });
      queryClient.invalidateQueries({ queryKey: [api.me.get.path] });
      toast({
        title: "Application Submitted",
        description: "Your application has been sent. You'll hear back from the host.",
      });
    },
    onError: (error) => {
      toast({
        title: "Application Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}

export function useMyApplications() {
  return useQuery({
    queryKey: [api.applications.mine.path],
    queryFn: async () => {
      const res = await fetch(api.applications.mine.path, { credentials: "include" });
      if (res.status === 401) return [];
      if (!res.ok) throw new Error("Failed to fetch applications");
      return res.json();
    },
    retry: false,
  });
}

export function useAllBookings() {
  return useQuery({
    queryKey: ["/api/admin/bookings"],
    queryFn: async () => {
      const res = await fetch("/api/admin/bookings", { credentials: "include" });
      if (res.status === 403 || res.status === 401) return [];
      if (!res.ok) throw new Error("Failed to fetch bookings");
      return res.json();
    },
    retry: false,
  });
}
