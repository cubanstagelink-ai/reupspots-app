import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";

export type ThemeConfig = {
  name: string;
  label: string;
  primary: string;
  accent: string;
  ring: string;
  background: string;
  secondary: string;
  border: string;
  input: string;
  muted: string;
  mutedForeground: string;
  glowPrimary: string;
  glowAccent: string;
};

export const THEMES: ThemeConfig[] = [
  {
    name: "neon-pink",
    label: "Neon Pink",
    primary: "320 100% 55%",
    accent: "190 100% 50%",
    ring: "320 100% 55%",
    background: "260 50% 5%",
    secondary: "260 50% 15%",
    border: "260 50% 20%",
    input: "260 50% 15%",
    muted: "260 30% 15%",
    mutedForeground: "260 20% 60%",
    glowPrimary: "rgba(255,0,229,0.3)",
    glowAccent: "rgba(0,255,255,0.5)",
  },
  {
    name: "toxic-green",
    label: "Toxic Green",
    primary: "120 100% 45%",
    accent: "280 100% 65%",
    ring: "120 100% 45%",
    background: "140 50% 4%",
    secondary: "140 40% 12%",
    border: "140 40% 18%",
    input: "140 40% 12%",
    muted: "140 25% 13%",
    mutedForeground: "140 20% 55%",
    glowPrimary: "rgba(0,255,60,0.3)",
    glowAccent: "rgba(180,0,255,0.5)",
  },
  {
    name: "electric-blue",
    label: "Electric Blue",
    primary: "210 100% 55%",
    accent: "45 100% 55%",
    ring: "210 100% 55%",
    background: "220 55% 5%",
    secondary: "220 50% 13%",
    border: "220 50% 20%",
    input: "220 50% 13%",
    muted: "220 30% 13%",
    mutedForeground: "220 20% 55%",
    glowPrimary: "rgba(0,120,255,0.3)",
    glowAccent: "rgba(255,200,0,0.5)",
  },
  {
    name: "sunset-orange",
    label: "Sunset Orange",
    primary: "25 100% 55%",
    accent: "340 100% 60%",
    ring: "25 100% 55%",
    background: "15 50% 5%",
    secondary: "15 45% 13%",
    border: "15 45% 20%",
    input: "15 45% 13%",
    muted: "15 25% 13%",
    mutedForeground: "15 20% 55%",
    glowPrimary: "rgba(255,120,0,0.3)",
    glowAccent: "rgba(255,40,100,0.5)",
  },
  {
    name: "ultraviolet",
    label: "Ultraviolet",
    primary: "270 100% 60%",
    accent: "170 100% 50%",
    ring: "270 100% 60%",
    background: "275 55% 5%",
    secondary: "275 50% 13%",
    border: "275 50% 20%",
    input: "275 50% 13%",
    muted: "275 25% 13%",
    mutedForeground: "275 20% 55%",
    glowPrimary: "rgba(140,0,255,0.3)",
    glowAccent: "rgba(0,255,200,0.5)",
  },
  {
    name: "crimson-gold",
    label: "Crimson Gold",
    primary: "0 100% 50%",
    accent: "50 100% 55%",
    ring: "0 100% 50%",
    background: "0 40% 5%",
    secondary: "0 35% 13%",
    border: "0 35% 20%",
    input: "0 35% 13%",
    muted: "0 20% 13%",
    mutedForeground: "0 15% 55%",
    glowPrimary: "rgba(255,0,30,0.3)",
    glowAccent: "rgba(255,220,0,0.5)",
  },
  {
    name: "arctic-ice",
    label: "Arctic Ice",
    primary: "195 100% 50%",
    accent: "330 100% 60%",
    ring: "195 100% 50%",
    background: "200 55% 5%",
    secondary: "200 45% 13%",
    border: "200 45% 20%",
    input: "200 45% 13%",
    muted: "200 25% 13%",
    mutedForeground: "200 20% 55%",
    glowPrimary: "rgba(0,200,255,0.3)",
    glowAccent: "rgba(255,50,150,0.5)",
  },
];

const STORAGE_KEY = "reupspots-theme";

let currentThemeName: string | null = null;

const recentHistory: number[] = [];
const HISTORY_SIZE = Math.min(4, THEMES.length - 1);

function pickDifferentTheme(): ThemeConfig {
  const available = THEMES.map((_, i) => i).filter(i => !recentHistory.includes(i));
  const pool = available.length > 0 ? available : [0];
  const idx = pool[Math.floor(Math.random() * pool.length)];
  recentHistory.push(idx);
  if (recentHistory.length > HISTORY_SIZE) {
    recentHistory.shift();
  }
  return THEMES[idx];
}

function applyTheme(theme: ThemeConfig) {
  const root = document.documentElement;
  root.style.setProperty("--primary", theme.primary);
  root.style.setProperty("--primary-foreground", "0 0% 98%");
  root.style.setProperty("--accent", theme.accent);
  root.style.setProperty("--accent-foreground", "0 0% 5%");
  root.style.setProperty("--ring", theme.ring);
  root.style.setProperty("--background", theme.background);
  root.style.setProperty("--secondary", theme.secondary);
  root.style.setProperty("--border", theme.border);
  root.style.setProperty("--input", theme.input);
  root.style.setProperty("--muted", theme.muted);
  root.style.setProperty("--muted-foreground", theme.mutedForeground);
  root.style.setProperty("--glow-primary", theme.glowPrimary);
  root.style.setProperty("--glow-accent", theme.glowAccent);
  currentThemeName = theme.name;
}

export function applyThemeByName(name: string): string {
  const theme = THEMES.find(t => t.name === name);
  if (theme) {
    applyTheme(theme);
    try { localStorage.setItem(STORAGE_KEY, name); } catch {}
    return theme.name;
  }
  return applyRandomTheme();
}

export function applyRandomTheme(): string {
  const theme = pickDifferentTheme();
  applyTheme(theme);
  try { localStorage.setItem(STORAGE_KEY, theme.name); } catch {}
  return theme.name;
}

export function loadSavedTheme(): string {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const theme = THEMES.find(t => t.name === saved);
      if (theme) {
        applyTheme(theme);
        return theme.name;
      }
    }
  } catch {}
  return applyRandomTheme();
}

export function getCurrentThemeName(): string | null {
  return currentThemeName;
}

const AUTO_SHIFT_INTERVAL = 30_000;

export function useThemeShift() {
  const [location] = useLocation();
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const prevLocationRef = useRef<string | null>(null);
  const [themeName, setThemeName] = useState<string>("");

  useEffect(() => {
    const name = loadSavedTheme();
    setThemeName(name);
    prevLocationRef.current = location;
  }, []);

  useEffect(() => {
    if (prevLocationRef.current !== null && prevLocationRef.current !== location) {
      const name = applyRandomTheme();
      setThemeName(name);
    }
    prevLocationRef.current = location;
  }, [location]);

  useEffect(() => {
    timerRef.current = setInterval(() => {
      const name = applyRandomTheme();
      setThemeName(name);
    }, AUTO_SHIFT_INTERVAL);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return themeName;
}
