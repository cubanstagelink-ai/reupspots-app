import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
// @ts-ignore
import appLogo from "@assets/myicon.png_1770508188377.PNG";
import { Logo } from "@/components/Logo";

export function CinematicIntro({ onComplete }: { onComplete: () => void }) {
  const [phase, setPhase] = useState<"logo" | "text" | "fade">("logo");

  useEffect(() => {
    const t1 = setTimeout(() => setPhase("text"), 800);
    const t2 = setTimeout(() => setPhase("fade"), 2200);
    const t3 = setTimeout(() => onComplete(), 2800);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
    };
  }, [onComplete]);

  return (
    <AnimatePresence>
      <motion.div
        className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-black"
        initial={{ opacity: 1 }}
        animate={{ opacity: phase === "fade" ? 0 : 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute h-px bg-primary/30"
              style={{
                top: `${5 + i * 5}%`,
                left: 0,
                right: 0,
              }}
              initial={{ scaleX: 0, opacity: 0 }}
              animate={{ scaleX: 1, opacity: [0, 0.4, 0] }}
              transition={{
                duration: 1.5,
                delay: i * 0.05,
                ease: "easeOut",
              }}
            />
          ))}
        </div>

        <motion.div
          className="relative flex flex-col items-center gap-4"
          initial={{ scale: 0.3, opacity: 0 }}
          animate={{
            scale: phase === "logo" ? [0.3, 1.1, 1] : 1,
            opacity: 1,
          }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <div className="relative">
            <img
              src={appLogo}
              alt="The Re-Up Spots"
              className="h-24 md:h-32 rounded-full object-cover"
              style={{ filter: "drop-shadow(0 0 20px var(--glow-primary))", mixBlendMode: "lighten" }}
            />
            <motion.div
              className="absolute inset-0 rounded-full"
              initial={{ opacity: 0 }}
              animate={{ opacity: [0, 0.6, 0] }}
              transition={{ duration: 1.2, delay: 0.3 }}
              style={{
                background: "radial-gradient(circle, var(--glow-primary) 0%, transparent 70%)",
                filter: "blur(20px)",
              }}
            />
          </div>
          <Logo size="lg" />
        </motion.div>

        <motion.h1
          className="mt-6 font-display text-3xl md:text-5xl font-black uppercase tracking-[0.3em] text-white"
          initial={{ opacity: 0, y: 20, letterSpacing: "0.5em" }}
          animate={{
            opacity: phase === "text" || phase === "fade" ? 1 : 0,
            y: phase === "text" || phase === "fade" ? 0 : 20,
            letterSpacing: "0.3em",
          }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="text-primary neon-text">Re-Up</span>{" "}
          <span className="text-accent">Spots</span>
        </motion.h1>

        <motion.p
          className="mt-3 font-mono text-xs text-muted-foreground uppercase tracking-[0.4em]"
          initial={{ opacity: 0 }}
          animate={{ opacity: phase === "text" || phase === "fade" ? 0.7 : 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Connecting Talent With Opportunity
        </motion.p>

        <motion.div
          className="absolute bottom-12 left-1/2 -translate-x-1/2"
          initial={{ opacity: 0 }}
          animate={{ opacity: phase === "text" ? [0, 1, 0] : 0 }}
          transition={{ duration: 1.5, repeat: 1 }}
        >
          <div className="w-16 h-0.5 bg-gradient-to-r from-transparent via-primary to-transparent" />
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
