import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { CyberButton } from "./CyberButton";
import { Button } from "@/components/ui/button";
import { useCreatePost, useCredits, useMyProfile } from "@/hooks/use-stage-link";
import { useAuth } from "@/hooks/use-auth";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATEGORIES, TIERS, BOOSTS, CREDIT_COSTS, NSFW_CATEGORY, LICENSED_CATEGORIES, EVENT_CATEGORIES } from "@shared/schema";
import { Plus, Lock, ShieldAlert, FileCheck, RefreshCw, CalendarHeart, Briefcase } from "lucide-react";
import { Textarea } from "@/components/ui/textarea";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { getPostCreditCost, getEventCreditCost, getBoostCreditCost } from "@shared/credits";
import { canUseBoosts } from "@shared/subscriptions";

export function CreatePostModal() {
  const [open, setOpen] = useState(false);
  const { user } = useAuth();
  const createPost = useCreatePost();
  const { data: creditData } = useCredits();
  const { data: myData } = useMyProfile();

  const { data: verifications } = useQuery<any[]>({
    queryKey: ["/api/verification"],
    enabled: !!user,
  });
  const isAgeVerified = verifications?.some((v: any) => v.status === "approved" && v.ageConfirmed);

  const [postType, setPostType] = useState<"gig" | "event">("gig");
  const isEvent = postType === "event";

  const [formData, setFormData] = useState({
    title: "",
    category: CATEGORIES[0] as string,
    tier: TIERS[0],
    pay: "",
    venue: "",
    address: "",
    fullAddress: "",
    date: "",
    promoterName: user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "",
    boostLevel: "None" as string,
    nsfw: false,
    paymentStructure: "full_upfront" as string,
    recurring: false,
    description: "",
    contactInfo: "",
    directions: "",
  });

  const isLicensedCategory = !isEvent && !!LICENSED_CATEGORIES[formData.category];
  const { data: proVerCheck } = useQuery<{ required: boolean; approved: boolean; pending: boolean; categoryInfo?: any }>({
    queryKey: [`/api/professional-verification/check/${encodeURIComponent(formData.category)}`],
    enabled: !!user && isLicensedCategory,
  });
  const needsProVerification = isLicensedCategory && proVerCheck?.required && !proVerCheck?.approved;

  const userPlan = myData?.profile?.plan || "free";
  const boostsAllowed = canUseBoosts(userPlan);

  const isNsfwEvent = isEvent && formData.category === "Adult Club Event";
  const postCost = isEvent ? getEventCreditCost(isNsfwEvent) : getPostCreditCost(formData.tier);
  const boostCost = boostsAllowed ? getBoostCreditCost(formData.boostLevel) : 0;
  const totalCreditCost = postCost + boostCost;
  const currentBalance = creditData?.balance ?? 0;

  const handlePostTypeSwitch = (type: "gig" | "event") => {
    setPostType(type);
    if (type === "event") {
      setFormData(prev => ({
        ...prev,
        category: EVENT_CATEGORIES[0] as string,
        tier: TIERS[0],
        pay: "0",
        paymentStructure: "full_upfront",
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        category: CATEGORIES[0] as string,
        pay: "",
      }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const isNsfw = isEvent
        ? formData.category === "Adult Club Event"
        : formData.category === NSFW_CATEGORY || formData.nsfw;
      const userId = (user as any)?.claims?.sub || user?.id;
      if (!userId) return;
      await createPost.mutateAsync({
        userId,
        postType,
        title: formData.title,
        category: formData.category,
        tier: isEvent ? TIERS[0] : formData.tier,
        pay: isEvent ? 0 : Number(formData.pay),
        venue: formData.venue,
        address: formData.address,
        fullAddress: formData.fullAddress || null,
        date: formData.date,
        promoterName: formData.promoterName,
        verified: false,
        media: [],
        boostLevel: formData.boostLevel,
        nsfw: isNsfw,
        paymentStructure: isEvent ? "full_upfront" : formData.paymentStructure,
        recurring: formData.recurring,
        description: formData.description || null,
        contactInfo: formData.contactInfo || null,
        directions: formData.directions || null,
      });
      setOpen(false);
      setPostType("gig");
      setFormData({
        title: "",
        category: CATEGORIES[0] as string,
        tier: TIERS[0],
        pay: "",
        venue: "",
        address: "",
        fullAddress: "",
        date: "",
        promoterName: user?.firstName ? `${user.firstName} ${user.lastName || ''}`.trim() : "",
        boostLevel: "None",
        nsfw: false,
        paymentStructure: "full_upfront",
        recurring: false,
        description: "",
        contactInfo: "",
        directions: "",
      });
    } catch (err) {
    }
  };

  if (!user) return null;

  const eventCategories = isAgeVerified
    ? [...EVENT_CATEGORIES, "Adult Club Event" as const]
    : [...EVENT_CATEGORIES];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <CyberButton className="w-full md:w-auto" data-testid="button-new-gig">
          <Plus className="w-4 h-4" /> New Post
        </CyberButton>
      </DialogTrigger>
      <DialogContent className="bg-background/95 border border-primary/20 backdrop-blur-xl max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-display text-primary tracking-wider uppercase">
            {isEvent ? "Post an Event" : "Broadcast Opportunity"}
          </DialogTitle>
        </DialogHeader>

        <div className="flex gap-2 pt-2" data-testid="toggle-post-type">
          <Button
            type="button"
            variant={postType === "gig" ? "default" : "ghost"}
            onClick={() => handlePostTypeSwitch("gig")}
            className="flex-1 gap-2 font-mono toggle-elevate"
            data-testid="button-type-gig"
          >
            <Briefcase className="w-4 h-4" />
            Paid Gig
          </Button>
          <Button
            type="button"
            variant={postType === "event" ? "default" : "ghost"}
            onClick={() => handlePostTypeSwitch("event")}
            className="flex-1 gap-2 font-mono toggle-elevate"
            data-testid="button-type-event"
          >
            <CalendarHeart className="w-4 h-4" />
            Free Event
          </Button>
        </div>

        {isEvent && (
          <div className="bg-accent/10 border border-accent/20 rounded-md p-3 font-mono text-xs text-accent" data-testid="text-event-info">
            Post free events like club parties, festivals, job fairs, and more. Visitors can discover your event and check your host page for paid gig opportunities.
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6 pt-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="font-mono text-accent">{isEvent ? "Event Name" : "Title / Role"}</Label>
              <Input
                required
                placeholder={isEvent ? "e.g. Friday Night Vibes" : "e.g. Lead Guitarist Needed"}
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
                data-testid="input-title"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent">{isEvent ? "Event Type" : "Category"}</Label>
              <Select
                value={formData.category}
                onValueChange={(val: any) => setFormData({...formData, category: val})}
              >
                <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background border-white/10 max-h-[300px]">
                  {isEvent ? (
                    eventCategories.map(cat => (
                      <SelectItem
                        key={cat}
                        value={cat}
                        className={`font-mono cursor-pointer ${cat === "Adult Club Event" ? "text-red-400" : ""}`}
                      >
                        {cat}
                      </SelectItem>
                    ))
                  ) : (
                    <>
                      {CATEGORIES.map(cat => (
                        <SelectItem key={cat} value={cat} className="font-mono cursor-pointer">{cat}</SelectItem>
                      ))}
                      {isAgeVerified && (
                        <SelectItem value={NSFW_CATEGORY} className="font-mono cursor-pointer text-red-400">
                          {NSFW_CATEGORY}
                        </SelectItem>
                      )}
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>

            {!isEvent && (
              <>
                <div className="space-y-2">
                  <Label className="font-mono text-accent">Tier Level</Label>
                  <Select
                    value={formData.tier}
                    onValueChange={(val: any) => setFormData({...formData, tier: val})}
                  >
                    <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-tier">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-background border-white/10">
                      {TIERS.map(tier => (
                        <SelectItem key={tier} value={tier} className="font-mono cursor-pointer">{tier}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label className="font-mono text-accent">Pay ($)</Label>
                  <Input
                    type="number"
                    required
                    min="0"
                    placeholder="200"
                    className="bg-black/40 border-white/10 focus:border-primary font-mono"
                    value={formData.pay}
                    onChange={e => setFormData({...formData, pay: e.target.value})}
                    data-testid="input-pay"
                  />
                </div>
              </>
            )}

            <div className="space-y-2">
              <Label className="font-mono text-accent">Venue Name</Label>
              <Input
                placeholder={isEvent ? "The Grand Ballroom" : "The Neon Lounge"}
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.venue}
                onChange={e => setFormData({...formData, venue: e.target.value})}
                data-testid="input-venue"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent">Date & Time</Label>
              <Input
                placeholder="Oct 24, 2077 @ 9PM"
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.date}
                onChange={e => setFormData({...formData, date: e.target.value})}
                data-testid="input-date"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent">General Area</Label>
              <Input
                placeholder="Oak Park, IL"
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.address}
                onChange={e => setFormData({...formData, address: e.target.value})}
                data-testid="input-address"
              />
              <p className="font-mono text-[10px] text-muted-foreground">Visible to everyone browsing</p>
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent flex items-center gap-2">
                Exact Address
                <Lock className="w-3 h-3 text-yellow-400" />
              </Label>
              <Input
                placeholder="123 Main St, Oak Park, IL 60302"
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.fullAddress}
                onChange={e => setFormData({...formData, fullAddress: e.target.value})}
                data-testid="input-full-address"
              />
              <p className="font-mono text-[10px] text-yellow-400/70">{isEvent ? "Only shared after RSVP / acceptance" : "Only shared with accepted talent"}</p>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label className="font-mono text-accent">{isEvent ? "Event Description" : "Description"}</Label>
              <Textarea
                placeholder={isEvent ? "What's the event about? Dress code, entry details, what to expect..." : "Describe the opportunity, what's expected, and any requirements..."}
                className="bg-black/40 border-white/10 focus:border-primary font-mono resize-none min-h-[80px]"
                value={formData.description}
                onChange={e => setFormData({...formData, description: e.target.value})}
                data-testid="input-description"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent">Contact Info</Label>
              <Input
                placeholder="Phone, email, or social handle"
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.contactInfo}
                onChange={e => setFormData({...formData, contactInfo: e.target.value})}
                data-testid="input-contact-info"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent">Directions / Notes</Label>
              <Input
                placeholder="Park in back lot, enter through side door..."
                className="bg-black/40 border-white/10 focus:border-primary font-mono"
                value={formData.directions}
                onChange={e => setFormData({...formData, directions: e.target.value})}
                data-testid="input-directions"
              />
            </div>

            {!isEvent && (
              <div className="space-y-2 md:col-span-2">
                <Label className="font-mono text-accent">Payment Structure</Label>
                <Select
                  value={formData.paymentStructure}
                  onValueChange={(val: any) => setFormData({...formData, paymentStructure: val})}
                >
                  <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-payment-structure">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    <SelectItem value="full_upfront" className="font-mono cursor-pointer">Full Payment Upfront</SelectItem>
                    <SelectItem value="split_50_50" className="font-mono cursor-pointer">50/50 Split (Half on booking, half on completion)</SelectItem>
                  </SelectContent>
                </Select>
                {formData.paymentStructure === "split_50_50" && formData.pay && (
                  <div className="bg-accent/10 border border-accent/20 rounded-lg p-3 font-mono text-xs text-accent">
                    Deposit: ${(Number(formData.pay) / 2).toFixed(2)} on booking &middot; Final: ${(Number(formData.pay) - Number(formData.pay) / 2).toFixed(2)} on completion
                  </div>
                )}
              </div>
            )}

            <div className="space-y-2 md:col-span-2">
              <Button
                type="button"
                variant={formData.recurring ? "outline" : "ghost"}
                onClick={() => setFormData({...formData, recurring: !formData.recurring})}
                className={`w-full justify-start gap-3 font-mono text-sm h-auto py-3 ${
                  formData.recurring ? "border-accent/40 bg-accent/10 text-accent" : ""
                }`}
                data-testid="button-toggle-recurring"
              >
                <RefreshCw className={`w-4 h-4 shrink-0 ${formData.recurring ? "text-accent" : ""}`} />
                <div className="text-left">
                  <span className="font-bold">{formData.recurring ? (isEvent ? "Recurring Event" : "Recurring Gig") : (isEvent ? "One-Time Event" : "One-Time Gig")}</span>
                  <span className="block text-xs text-muted-foreground mt-0.5">
                    {formData.recurring ? (isEvent ? "This event repeats on a regular basis" : "This opportunity repeats on a regular basis") : "Tap to mark as recurring"}
                  </span>
                </div>
              </Button>
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label className="font-mono text-accent flex items-center gap-2">
                Boost Level
                {!boostsAllowed && <span className="text-xs text-muted-foreground flex items-center gap-1"><Lock className="w-3 h-3" /> Pro/Elite only</span>}
              </Label>
              {boostsAllowed ? (
                <Select
                  value={formData.boostLevel}
                  onValueChange={(val: any) => setFormData({...formData, boostLevel: val})}
                >
                  <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-boost">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    {BOOSTS.map(boost => (
                      <SelectItem key={boost} value={boost} className="font-mono cursor-pointer">
                        {boost}{boost !== "None" ? ` (+${getBoostCreditCost(boost)} credits)` : ""}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <div className="bg-black/40 border border-white/10 rounded-md px-3 py-2 font-mono text-sm text-muted-foreground" data-testid="text-boost-locked">
                  Upgrade to Pro or Elite to access boosts
                </div>
              )}
            </div>
          </div>

          {needsProVerification && (
            <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4 space-y-2" data-testid="alert-pro-verification-required">
              <div className="flex items-start gap-2">
                <FileCheck className="w-5 h-5 text-yellow-400 mt-0.5 shrink-0" />
                <div>
                  <p className="font-mono text-sm text-yellow-300 font-bold">Professional Verification Required</p>
                  <p className="font-mono text-xs text-gray-400 mt-1">
                    {formData.category} requires verified professional credentials before you can post.
                    {proVerCheck?.pending ? " Your verification is pending review." : ""}
                  </p>
                  <Link href="/professional-verification" className="font-mono text-xs text-primary underline mt-2 inline-block" data-testid="link-pro-verification">
                    {proVerCheck?.pending ? "View Status" : "Submit Credentials"}
                  </Link>
                </div>
              </div>
            </div>
          )}

          <div className="bg-black/40 border border-white/10 rounded-lg p-4 font-mono text-sm">
            <div className="flex justify-between text-gray-400 mb-1">
              <span>{isEvent ? `Event post${isNsfwEvent ? " (Adult)" : ""}` : `Post cost (${formData.tier})`}</span>
              <span className="text-white">{postCost} credit{postCost !== 1 ? "s" : ""}</span>
            </div>
            {boostCost > 0 && (
              <div className="flex justify-between text-gray-400 mb-1">
                <span>Boost ({formData.boostLevel})</span>
                <span className="text-white">{boostCost} credits</span>
              </div>
            )}
            <div className="border-t border-white/10 pt-2 mt-2 flex justify-between font-bold">
              <span className="text-accent">Total Cost</span>
              <span className="text-white" data-testid="text-total-credit-cost">{totalCreditCost} credit{totalCreditCost !== 1 ? "s" : ""}</span>
            </div>
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>Your balance</span>
              <span data-testid="text-credit-balance">{currentBalance} credits</span>
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-4 border-t border-white/10">
            <Button
              type="button"
              variant="ghost"
              onClick={() => setOpen(false)}
              className="font-mono text-sm"
              data-testid="button-cancel"
            >
              CANCEL
            </Button>
            <CyberButton
              type="submit"
              loading={createPost.isPending}
              disabled={currentBalance < totalCreditCost || needsProVerification}
              data-testid="button-publish-gig"
            >
              {isEvent ? "POST EVENT" : "PUBLISH GIG"}
            </CyberButton>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
