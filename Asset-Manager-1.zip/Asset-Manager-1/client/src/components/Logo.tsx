interface LogoProps {
  size?: "sm" | "md" | "lg" | "xl";
  showText?: boolean;
  className?: string;
}

const SIZES = {
  sm: { width: 32, height: 32, fontSize: 10, tagline: 6 },
  md: { width: 48, height: 48, fontSize: 14, tagline: 8 },
  lg: { width: 80, height: 80, fontSize: 22, tagline: 10 },
  xl: { width: 120, height: 120, fontSize: 34, tagline: 14 },
};

export function Logo({ size = "md", showText = false, className = "" }: LogoProps) {
  const s = SIZES[size];

  return (
    <div className={`flex items-center gap-2 ${className}`} data-testid="logo-svg">
      <svg
        width={s.width}
        height={s.height}
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        role="img"
        aria-label="The Re-Up Spots Logo"
        style={{ filter: "drop-shadow(0 0 12px var(--glow-primary))" }}
      >
        <rect
          x="4"
          y="4"
          width="112"
          height="112"
          rx="8"
          stroke="hsl(var(--primary))"
          strokeWidth="2"
          fill="hsl(var(--background))"
          opacity="0.9"
        />

        <polygon
          points="60,18 95,38 95,78 60,98 25,78 25,38"
          stroke="hsl(var(--accent))"
          strokeWidth="1.5"
          fill="none"
          opacity="0.4"
        />

        <line x1="10" y1="25" x2="50" y2="25" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.3" />
        <line x1="70" y1="95" x2="110" y2="95" stroke="hsl(var(--primary))" strokeWidth="1" opacity="0.3" />
        <line x1="10" y1="30" x2="35" y2="30" stroke="hsl(var(--accent))" strokeWidth="0.5" opacity="0.2" />
        <line x1="85" y1="90" x2="110" y2="90" stroke="hsl(var(--accent))" strokeWidth="0.5" opacity="0.2" />

        <text
          x="60"
          y="50"
          textAnchor="middle"
          dominantBaseline="central"
          fontFamily="'Orbitron', sans-serif"
          fontWeight="900"
          fontSize="28"
          fill="hsl(var(--primary))"
          style={{ filter: "drop-shadow(0 0 6px var(--glow-primary))" }}
        >
          R
        </text>
        <text
          x="60"
          y="74"
          textAnchor="middle"
          dominantBaseline="central"
          fontFamily="'Orbitron', sans-serif"
          fontWeight="700"
          fontSize="16"
          fill="hsl(var(--accent))"
          style={{ filter: "drop-shadow(0 0 4px var(--glow-accent))" }}
        >
          UP
        </text>

        <circle cx="60" cy="60" r="52" stroke="hsl(var(--primary))" strokeWidth="0.5" fill="none" opacity="0.15" />
        <circle cx="60" cy="60" r="56" stroke="hsl(var(--accent))" strokeWidth="0.3" fill="none" opacity="0.1" />

        <rect x="15" y="105" width="8" height="2" fill="hsl(var(--primary))" opacity="0.5" />
        <rect x="97" y="13" width="8" height="2" fill="hsl(var(--accent))" opacity="0.5" />
        <rect x="15" y="13" width="3" height="3" fill="hsl(var(--primary))" opacity="0.3" />
        <rect x="102" y="104" width="3" height="3" fill="hsl(var(--accent))" opacity="0.3" />
      </svg>

      {showText && (
        <div className="flex flex-col">
          <span
            className="font-display font-black uppercase tracking-wider leading-tight"
            style={{ fontSize: s.fontSize, filter: "drop-shadow(0 0 4px var(--glow-primary))" }}
          >
            <span className="text-primary">Re-Up</span>{" "}
            <span className="text-accent">Spots</span>
          </span>
          {size !== "sm" && (
            <span
              className="font-mono uppercase tracking-[0.2em] text-muted-foreground"
              style={{ fontSize: s.tagline }}
            >
              Talent x Opportunity
            </span>
          )}
        </div>
      )}
    </div>
  );
}
