import { Link, useLocation } from "wouter";
import { Zap, Mic2, FileText, Info, LogOut, User, Menu, X, MessageSquare, ShieldCheck, Building2, Bell, Palette, Shield } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";
import appLogo from "@assets/myicon.png_1770508188377.PNG";
import { InstallPrompt } from "@/components/InstallPrompt";
import { applyRandomTheme, applyThemeByName, THEMES, getCurrentThemeName } from "@/hooks/use-theme-shift";
import { Logo } from "@/components/Logo";
import { ADMIN_EMAILS } from "@shared/schema";
import type { Notification } from "@shared/schema";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { user, logout, isAuthenticated } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [notifOpen, setNotifOpen] = useState(false);
  const notifRef = useRef<HTMLDivElement>(null);
  const [vibeFlash, setVibeFlash] = useState(false);
  const [activeTheme, setActiveTheme] = useState<string>(getCurrentThemeName() || "neon-pink");
  const [themePickerOpen, setThemePickerOpen] = useState(false);
  const themePickerRef = useRef<HTMLDivElement>(null);
  const isAdmin = !!user?.email && ADMIN_EMAILS.includes(user.email);

  const vibeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const switchVibe = () => {
    const name = applyRandomTheme();
    setActiveTheme(name);
    setVibeFlash(true);
    if (vibeTimerRef.current) clearTimeout(vibeTimerRef.current);
    vibeTimerRef.current = setTimeout(() => setVibeFlash(false), 400);
  };

  const pickTheme = (name: string) => {
    applyThemeByName(name);
    setActiveTheme(name);
    setThemePickerOpen(false);
    setVibeFlash(true);
    if (vibeTimerRef.current) clearTimeout(vibeTimerRef.current);
    vibeTimerRef.current = setTimeout(() => setVibeFlash(false), 400);
  };

  useEffect(() => {
    return () => {
      if (vibeTimerRef.current) clearTimeout(vibeTimerRef.current);
    };
  }, []);

  useEffect(() => {
    function handleClickOutsideThemePicker(e: MouseEvent) {
      if (themePickerRef.current && !themePickerRef.current.contains(e.target as Node)) {
        setThemePickerOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutsideThemePicker);
    return () => document.removeEventListener("mousedown", handleClickOutsideThemePicker);
  }, []);

  const navItems = [
    { href: "/", label: "Feed", icon: Zap },
    { href: "/profiles", label: "Talent", icon: Mic2 },
    { href: "/posters", label: "Hosts", icon: Building2 },
    { href: "/rules", label: "Protocol", icon: Info },
  ];

  const { data: unreadData } = useQuery<{ count: number }>({
    queryKey: ["/api/notifications/unread-count"],
    enabled: isAuthenticated,
    refetchInterval: 30000,
  });

  const { data: notifList } = useQuery<Notification[]>({
    queryKey: ["/api/notifications"],
    enabled: isAuthenticated && notifOpen,
  });

  const markAllRead = useMutation({
    mutationFn: () => apiRequest("POST", "/api/notifications/read-all"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const markOneRead = useMutation({
    mutationFn: (id: number) => apiRequest("POST", `/api/notifications/${id}/read`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications/unread-count"] });
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const unreadCount = unreadData?.count || 0;

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) {
        setNotifOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="min-h-screen flex flex-col relative overflow-x-hidden">
      {/* Background Grid Effect */}
      <div className="fixed inset-0 pointer-events-none z-[-1]" 
           style={{ 
             backgroundImage: 'linear-gradient(rgba(255, 255, 255, 0.03) 1px, transparent 1px), linear-gradient(90deg, rgba(255, 255, 255, 0.03) 1px, transparent 1px)',
             backgroundSize: '40px 40px'
           }} 
      />

      <nav className="border-b border-white/10 bg-black/50 backdrop-blur-lg sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-3">
              <Link href="/" className="flex items-center gap-2 group">
                <img src={appLogo} alt="The Re-Up Spots" className="h-10 relative z-10 transition-all rounded-full object-cover" style={{ filter: "drop-shadow(0 0 8px var(--glow-primary))", mixBlendMode: "lighten" }} data-testid="img-logo" />
                <Logo size="sm" className="hidden sm:flex" />
              </Link>
              <div className="relative" ref={themePickerRef}>
                <button
                  type="button"
                  onClick={() => setThemePickerOpen(!themePickerOpen)}
                  className={cn(
                    "flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-mono text-[10px] uppercase tracking-wider transition-all duration-300 cursor-pointer",
                    vibeFlash
                      ? "border-primary/50 bg-primary/20 text-primary"
                      : "border-white/10 bg-white/5 text-muted-foreground hover:text-primary hover:border-primary/30"
                  )}
                  data-testid="button-switch-vibe"
                >
                  <Palette className="w-3 h-3" />
                  <span className="hidden sm:inline">Vibe</span>
                </button>

                <AnimatePresence>
                  {themePickerOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: -8, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: -8, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      className="absolute left-0 top-10 w-52 bg-black/95 border border-white/10 rounded-xl shadow-2xl z-50 backdrop-blur-xl overflow-hidden"
                      data-testid="dropdown-theme-picker"
                    >
                      <button
                        type="button"
                        onClick={switchVibe}
                        className="w-full text-left px-4 py-2.5 font-mono text-xs text-accent hover:bg-accent/10 border-b border-white/10 uppercase tracking-wider cursor-pointer flex items-center gap-2"
                        data-testid="button-random-vibe"
                      >
                        <Palette className="w-3 h-3" />
                        Random Vibe
                      </button>
                      <div className="max-h-64 overflow-y-auto">
                        {THEMES.map((theme) => (
                          <button
                            key={theme.name}
                            type="button"
                            onClick={() => pickTheme(theme.name)}
                            className={cn(
                              "w-full text-left px-4 py-2 font-mono text-xs cursor-pointer flex items-center gap-3 transition-colors",
                              activeTheme === theme.name
                                ? "bg-primary/10 text-primary"
                                : "text-gray-400 hover:bg-white/5 hover:text-white"
                            )}
                            data-testid={`button-theme-${theme.name}`}
                          >
                            <span
                              className="w-3 h-3 rounded-full shrink-0 border border-white/20"
                              style={{ backgroundColor: `hsl(${theme.primary})` }}
                            />
                            <span
                              className="w-2 h-2 rounded-full shrink-0"
                              style={{ backgroundColor: `hsl(${theme.accent})` }}
                            />
                            <span className="truncate">{theme.label}</span>
                            {activeTheme === theme.name && (
                              <span className="ml-auto text-primary text-[8px]">ACTIVE</span>
                            )}
                          </button>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-8">
              {navItems.map((item) => {
                const isActive = location === item.href;
                const Icon = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <div className={cn(
                      "flex items-center gap-2 text-sm font-bold uppercase tracking-wider transition-all duration-300 cursor-pointer hover:text-primary",
                      isActive ? "text-primary neon-text" : "text-muted-foreground"
                    )}>
                      <Icon className="w-4 h-4" />
                      {item.label}
                      {isActive && (
                        <motion.div 
                          layoutId="nav-underline"
                          className="absolute -bottom-8 left-0 right-0 h-1 bg-primary"
                          style={{ boxShadow: "0 0 10px var(--glow-primary)" }}
                        />
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>

            {/* Auth Buttons */}
            <div className="hidden md:flex items-center gap-4">
              {isAuthenticated ? (
                <div className="flex items-center gap-4">
                  <div className="relative" ref={notifRef}>
                    <button
                      type="button"
                      onClick={() => setNotifOpen(!notifOpen)}
                      className={cn(
                        "relative flex items-center gap-1 text-sm font-medium cursor-pointer transition-colors",
                        notifOpen ? "text-primary" : "text-muted-foreground hover:text-primary"
                      )}
                      data-testid="button-notifications"
                    >
                      <Bell className="w-4 h-4" />
                      {unreadCount > 0 && (
                        <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-primary text-[9px] font-bold text-white flex items-center justify-center font-mono" data-testid="text-unread-count">
                          {unreadCount > 9 ? "9+" : unreadCount}
                        </span>
                      )}
                    </button>

                    <AnimatePresence>
                      {notifOpen && (
                        <motion.div
                          initial={{ opacity: 0, y: -10, scale: 0.95 }}
                          animate={{ opacity: 1, y: 0, scale: 1 }}
                          exit={{ opacity: 0, y: -10, scale: 0.95 }}
                          transition={{ duration: 0.15 }}
                          className="absolute right-0 top-8 w-80 max-h-96 overflow-y-auto bg-black/95 border border-white/10 rounded-xl shadow-2xl z-50 backdrop-blur-xl"
                          data-testid="dropdown-notifications"
                        >
                          <div className="flex items-center justify-between p-3 border-b border-white/10">
                            <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider">Notifications</h3>
                            {unreadCount > 0 && (
                              <button
                                type="button"
                                onClick={() => markAllRead.mutate()}
                                className="font-mono text-[10px] text-primary hover:text-primary/80 uppercase tracking-wider"
                                data-testid="button-mark-all-read"
                              >
                                Mark all read
                              </button>
                            )}
                          </div>
                          {(!notifList || notifList.length === 0) ? (
                            <div className="p-6 text-center">
                              <Bell className="w-8 h-8 mx-auto mb-2 text-muted-foreground/30" />
                              <p className="font-mono text-xs text-muted-foreground">No notifications yet</p>
                            </div>
                          ) : (
                            <div className="divide-y divide-white/5">
                              {notifList.map((n) => (
                                <Link key={n.id} href={n.linkUrl || "#"}>
                                  <div
                                    className={cn(
                                      "block px-3 py-3 cursor-pointer transition-colors",
                                      n.read ? "bg-transparent hover:bg-white/5" : "bg-primary/5 hover:bg-primary/10"
                                    )}
                                    onClick={() => {
                                      if (!n.read) markOneRead.mutate(n.id);
                                      setNotifOpen(false);
                                    }}
                                    data-testid={`notification-${n.id}`}
                                  >
                                    <div className="flex items-start gap-2">
                                      {!n.read && <div className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" />}
                                      <div className={cn("flex-1", n.read && "ml-3.5")}>
                                        <p className="font-mono text-xs text-white leading-relaxed">{n.message}</p>
                                        <p className="font-mono text-[10px] text-muted-foreground mt-1">
                                          {new Date(n.createdAt!).toLocaleDateString()}
                                        </p>
                                      </div>
                                    </div>
                                  </div>
                                </Link>
                              ))}
                            </div>
                          )}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                  <Link href="/messages">
                    <div className={cn(
                      "flex items-center gap-1 text-sm font-medium cursor-pointer transition-colors",
                      location === "/messages" ? "text-primary" : "text-muted-foreground hover:text-primary"
                    )} data-testid="link-messages">
                      <MessageSquare className="w-4 h-4" />
                    </div>
                  </Link>
                  <Link href="/verification">
                    <div className={cn(
                      "flex items-center gap-1 text-sm font-medium cursor-pointer transition-colors",
                      location === "/verification" ? "text-primary" : "text-muted-foreground hover:text-primary"
                    )} data-testid="link-verification">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                  </Link>
                  {isAdmin && (
                    <Link href="/admin">
                      <div className={cn(
                        "flex items-center gap-1 text-sm font-medium cursor-pointer transition-colors",
                        location === "/admin" ? "text-primary" : "text-muted-foreground hover:text-primary"
                      )} data-testid="link-admin">
                        <Shield className="w-4 h-4" />
                      </div>
                    </Link>
                  )}
                  <Link href="/me">
                    <div className="flex items-center gap-2 text-sm font-medium text-white hover:text-primary cursor-pointer transition-colors">
                      <User className="w-4 h-4" />
                      <span className="font-mono">{user?.firstName || "User"}</span>
                    </div>
                  </Link>
                  <button 
                    onClick={() => { window.location.href = "/api/logout"; }}
                    className="text-muted-foreground hover:text-destructive transition-colors"
                    data-testid="button-logout"
                  >
                    <LogOut className="w-5 h-5" />
                  </button>
                </div>
              ) : (
                <a href="/api/login" className="cyber-button-accent text-xs">
                  Connect Node
                </a>
              )}
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button 
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-white hover:text-primary transition-colors"
              >
                {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-black/90 border-b border-white/10 overflow-hidden"
            >
              <div className="px-4 py-6 space-y-4">
                {navItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <div 
                      className={cn(
                        "block px-4 py-3 rounded-lg text-lg font-bold uppercase tracking-wider",
                        location === item.href ? "bg-primary/10 text-primary border border-primary/20" : "text-white hover:bg-white/5"
                      )}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.label}
                    </div>
                  </Link>
                ))}
                
                <div className="pt-4 border-t border-white/10">
                  {isAuthenticated ? (
                    <>
                      <Link href="/messages">
                        <div className="block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer" onClick={() => setMobileMenuOpen(false)}>
                          <MessageSquare className="w-4 h-4 inline mr-2" />Messages
                        </div>
                      </Link>
                      <button
                        type="button"
                        onClick={() => { setNotifOpen(!notifOpen); setMobileMenuOpen(false); }}
                        className="w-full text-left block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer"
                        data-testid="button-notifications-mobile"
                      >
                        <Bell className="w-4 h-4 inline mr-2" />
                        Notifications
                        {unreadCount > 0 && (
                          <span className="ml-2 px-1.5 py-0.5 rounded-full bg-primary text-[10px] font-bold text-white font-mono">
                            {unreadCount}
                          </span>
                        )}
                      </button>
                      <Link href="/verification">
                        <div className="block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer" onClick={() => setMobileMenuOpen(false)}>
                          <ShieldCheck className="w-4 h-4 inline mr-2" />Verification
                        </div>
                      </Link>
                      <Link href="/professional-verification">
                        <div className="block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer" onClick={() => setMobileMenuOpen(false)}>
                          <ShieldCheck className="w-4 h-4 inline mr-2" />Pro Credentials
                        </div>
                      </Link>
                      {isAdmin && (
                        <Link href="/admin">
                          <div className="block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer" onClick={() => setMobileMenuOpen(false)} data-testid="link-admin-mobile">
                            <Shield className="w-4 h-4 inline mr-2" />Admin Panel
                          </div>
                        </Link>
                      )}
                      <button
                        type="button"
                        onClick={() => { switchVibe(); setMobileMenuOpen(false); }}
                        className="w-full text-left block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer"
                        data-testid="button-switch-vibe-mobile"
                      >
                        <Palette className="w-4 h-4 inline mr-2" />Random Vibe
                      </button>
                      <div className="px-4 py-2 space-y-1">
                        <p className="font-mono text-[10px] text-muted-foreground uppercase tracking-wider mb-2">Pick Vibe</p>
                        <div className="grid grid-cols-2 gap-1">
                          {THEMES.map((theme) => (
                            <button
                              key={theme.name}
                              type="button"
                              onClick={() => { pickTheme(theme.name); setMobileMenuOpen(false); }}
                              className={cn(
                                "flex items-center gap-2 px-3 py-2 rounded-lg font-mono text-[10px] cursor-pointer transition-colors",
                                activeTheme === theme.name
                                  ? "bg-primary/10 text-primary border border-primary/20"
                                  : "text-gray-400 hover:bg-white/5 hover:text-white"
                              )}
                              data-testid={`button-theme-mobile-${theme.name}`}
                            >
                              <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ backgroundColor: `hsl(${theme.primary})` }} />
                              {theme.label}
                            </button>
                          ))}
                        </div>
                      </div>
                      <Link href="/me">
                        <div className="block px-4 py-3 text-white hover:text-primary font-mono cursor-pointer" onClick={() => setMobileMenuOpen(false)}>
                          Profile: {user?.firstName}
                        </div>
                      </Link>
                      <button 
                        onClick={() => { window.location.href = "/api/logout"; }}
                        className="w-full text-left px-4 py-3 text-destructive hover:bg-destructive/10 rounded-lg"
                        data-testid="button-logout-mobile"
                      >
                        Disconnect
                      </button>
                    </>
                  ) : (
                    <a href="/api/login" className="block w-full text-center cyber-button-accent">
                      Connect Node
                    </a>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-12">
        {children}
      </main>

      <footer className="border-t border-white/10 bg-black/80 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4 text-center space-y-3">
          <div className="flex justify-center mb-3">
            <Logo size="sm" showText />
          </div>
          <div className="flex items-center justify-center gap-4 flex-wrap">
            <Link href="/terms" className="font-mono text-xs text-muted-foreground hover:text-primary transition-colors uppercase tracking-wider" data-testid="link-terms">
              Terms of Service
            </Link>
            <span className="text-muted-foreground/40">&bull;</span>
            <Link href="/privacy" className="font-mono text-xs text-muted-foreground hover:text-primary transition-colors uppercase tracking-wider" data-testid="link-privacy">
              Privacy Policy
            </Link>
            <span className="text-muted-foreground/40">&bull;</span>
            <Link href="/rules" className="font-mono text-xs text-muted-foreground hover:text-primary transition-colors uppercase tracking-wider" data-testid="link-rules-footer">
              Protocol
            </Link>
            <span className="text-muted-foreground/40">&bull;</span>
            <Link href="/feedback" className="font-mono text-xs text-muted-foreground hover:text-primary transition-colors uppercase tracking-wider" data-testid="link-feedback-footer">
              Feedback
            </Link>
          </div>
          <p className="font-mono text-xs text-muted-foreground">
            HR: humanresources@reupspots.com &bull; Legal: legal@reupspots.com &bull; Support: support@reupspots.com
          </p>
          <p className="font-mono text-xs text-muted-foreground uppercase tracking-widest">
            System Online &bull; v2.0.4 &bull; The Re-Up Spots Network
          </p>
        </div>
      </footer>

      <InstallPrompt />
    </div>
  );
}
