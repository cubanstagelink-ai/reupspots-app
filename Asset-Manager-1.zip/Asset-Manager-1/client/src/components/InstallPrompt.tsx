import { useState, useEffect } from "react";
import { Download, X, Share } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";

interface BeforeInstallPromptEvent extends Event {
  prompt(): Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  useEffect(() => {
    const isStandalone = window.matchMedia("(display-mode: standalone)").matches
      || ("standalone" in window.navigator && (window.navigator as any).standalone);
    if (isStandalone) return;

    const dismissed = localStorage.getItem("pwa-install-dismissed");
    if (dismissed) {
      const dismissedAt = parseInt(dismissed, 10);
      if (Date.now() - dismissedAt < 7 * 24 * 60 * 60 * 1000) return;
    }

    const ua = navigator.userAgent;
    const isiOS = /iPad|iPhone|iPod/.test(ua) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    setIsIOS(isiOS);

    if (isiOS) {
      setTimeout(() => setShowPrompt(true), 3000);
      return;
    }

    const handler = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      setTimeout(() => setShowPrompt(true), 2000);
    };

    window.addEventListener("beforeinstallprompt", handler);
    return () => window.removeEventListener("beforeinstallprompt", handler);
  }, []);

  const handleInstall = async () => {
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === "accepted") {
        setShowPrompt(false);
      }
      setDeferredPrompt(null);
    }
  };

  const handleDismiss = () => {
    setShowPrompt(false);
    localStorage.setItem("pwa-install-dismissed", Date.now().toString());
  };

  return (
    <AnimatePresence>
      {showPrompt && (
        <motion.div
          initial={{ opacity: 0, y: 80 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 80 }}
          className="fixed bottom-4 left-4 right-4 z-[100] max-w-md mx-auto"
        >
          <div className="bg-black/95 border border-primary/30 rounded-2xl p-5 backdrop-blur-xl" style={{ boxShadow: "0 0 30px var(--glow-primary)" }}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="bg-primary/10 rounded-xl p-2.5 shrink-0">
                  <Download className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-display font-bold text-white text-sm">Add The Re-Up Spots to Home Screen</p>
                  <p className="font-mono text-xs text-gray-400 mt-0.5">Use The Re-Up Spots like an app — fast and fullscreen</p>
                </div>
              </div>
              <button onClick={handleDismiss} className="text-gray-500 hover:text-white transition-colors shrink-0 mt-0.5" data-testid="button-dismiss-install">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="mt-4">
              {isIOS ? (
                <>
                  {!showIOSGuide ? (
                    <Button
                      variant="default"
                      className="w-full"
                      onClick={() => setShowIOSGuide(true)}
                      data-testid="button-show-ios-guide"
                    >
                      <Share className="w-4 h-4 mr-2" />
                      Show Me How
                    </Button>
                  ) : (
                    <div className="space-y-2 font-mono text-xs text-gray-300">
                      <p className="flex items-start gap-2"><span className="text-primary font-bold">1.</span> Tap the Share button in Safari's toolbar</p>
                      <p className="flex items-start gap-2"><span className="text-primary font-bold">2.</span> Scroll down and tap "Add to Home Screen"</p>
                      <p className="flex items-start gap-2"><span className="text-primary font-bold">3.</span> Tap "Add" to confirm</p>
                    </div>
                  )}
                </>
              ) : deferredPrompt ? (
                <Button
                  variant="default"
                  className="w-full"
                  onClick={handleInstall}
                  data-testid="button-install-app"
                >
                  <Download className="w-4 h-4 mr-2" />
                  Install App
                </Button>
              ) : (
                <div className="space-y-2 font-mono text-xs text-gray-300">
                  <p className="flex items-start gap-2"><span className="text-primary font-bold">1.</span> Open browser menu (three dots)</p>
                  <p className="flex items-start gap-2"><span className="text-primary font-bold">2.</span> Tap "Add to Home Screen" or "Install App"</p>
                </div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
