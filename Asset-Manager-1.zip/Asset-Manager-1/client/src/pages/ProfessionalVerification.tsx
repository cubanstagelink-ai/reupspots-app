import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { CyberButton } from "@/components/CyberButton";
import { useUpload } from "@/hooks/use-upload";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { ShieldCheck, Upload, Clock, CheckCircle, XCircle, AlertTriangle, FileCheck, Award } from "lucide-react";
import { LICENSED_CATEGORIES } from "@shared/schema";
import { Card } from "@/components/ui/card";

export default function ProfessionalVerification() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const queryClient = useQueryClient();
  const [documentPath, setDocumentPath] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [licenseType, setLicenseType] = useState("");
  const [licenseNumber, setLicenseNumber] = useState("");
  const [issuingAuthority, setIssuingAuthority] = useState("");
  const [expirationDate, setExpirationDate] = useState("");
  const [businessName, setBusinessName] = useState("");

  const { uploadFile } = useUpload({
    onSuccess: (response) => {
      setDocumentPath(response.objectPath);
    },
  });

  const { data: verifications, isLoading } = useQuery<any[]>({
    queryKey: ["/api/professional-verification"],
    enabled: isAuthenticated,
  });

  const submitVerification = useMutation({
    mutationFn: async () => {
      if (!documentPath) throw new Error("Please upload your document first");
      if (!selectedCategory) throw new Error("Please select a category");
      if (!licenseType) throw new Error("Please enter your license/certification type");
      const res = await apiRequest("POST", "/api/professional-verification", {
        category: selectedCategory,
        licenseType,
        licenseNumber: licenseNumber || undefined,
        issuingAuthority: issuingAuthority || undefined,
        expirationDate: expirationDate || undefined,
        documentPath,
        businessName: businessName || undefined,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/professional-verification"] });
      setDocumentPath(null);
      setSelectedCategory("");
      setLicenseType("");
      setLicenseNumber("");
      setIssuingAuthority("");
      setExpirationDate("");
      setBusinessName("");
    },
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    await uploadFile(file);
    setUploading(false);
  };

  if (authLoading) return <div className="p-20 text-center font-mono animate-pulse">AUTHENTICATING...</div>;

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
        <Award className="w-16 h-16 text-primary" />
        <h1 className="text-3xl font-display font-bold">PROFESSIONAL VERIFICATION</h1>
        <p className="font-mono text-muted-foreground">You must be logged in to verify your professional credentials.</p>
        <a href="/api/login"><CyberButton data-testid="button-login">Connect Node</CyberButton></a>
      </div>
    );
  }

  const statusConfig: Record<string, { icon: any; color: string; label: string }> = {
    pending: { icon: Clock, color: "text-yellow-400", label: "PENDING REVIEW" },
    approved: { icon: CheckCircle, color: "text-green-400", label: "APPROVED" },
    rejected: { icon: XCircle, color: "text-red-400", label: "REJECTED" },
  };

  const categoryInfo = selectedCategory ? LICENSED_CATEGORIES[selectedCategory] : null;

  return (
    <div className="max-w-2xl mx-auto py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600" data-testid="text-pro-verification-title">
          PROFESSIONAL VERIFICATION
        </h1>
        <p className="font-mono text-accent text-lg">Verify your licenses and certifications to work in regulated fields.</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="bg-black/40 border border-accent/20 rounded-2xl p-6">
        <div className="flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-accent mt-0.5 shrink-0" />
          <div className="font-mono text-sm text-gray-400 space-y-2">
            <p className="text-white font-bold">WHY PROFESSIONAL VERIFICATION?</p>
            <p>Certain job categories require licensed or certified workers. To protect both talent and employers, anyone posting or working in these fields must submit proof of their credentials. This builds trust and keeps the community safe.</p>
          </div>
        </div>
      </motion.div>

      {verifications && verifications.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-black/40 border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-display font-bold text-white mb-4">YOUR CREDENTIALS</h2>
          <div className="space-y-3">
            {verifications.map((v: any) => {
              const sc = statusConfig[v.status] || statusConfig.pending;
              const StatusIcon = sc.icon;
              return (
                <Card key={v.id} className="bg-black/40 border-white/5 p-4" data-testid={`card-pro-verification-${v.id}`}>
                  <div className="flex items-start justify-between flex-wrap gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <StatusIcon className={`w-4 h-4 ${sc.color}`} />
                        <p className={`font-mono text-sm font-bold ${sc.color}`}>{sc.label}</p>
                      </div>
                      <p className="font-mono text-sm text-white">{v.category}</p>
                      <p className="font-mono text-xs text-muted-foreground">{v.licenseType}</p>
                      {v.licenseNumber && (
                        <p className="font-mono text-xs text-muted-foreground">License #: {v.licenseNumber}</p>
                      )}
                      {v.issuingAuthority && (
                        <p className="font-mono text-xs text-muted-foreground">Issued by: {v.issuingAuthority}</p>
                      )}
                      {v.businessName && (
                        <p className="font-mono text-xs text-muted-foreground">Business: {v.businessName}</p>
                      )}
                    </div>
                    <p className="font-mono text-xs text-muted-foreground">
                      {new Date(v.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                  {v.adminNotes && (
                    <p className="font-mono text-xs text-muted-foreground mt-2 pt-2 border-t border-white/5">
                      Admin Notes: {v.adminNotes}
                    </p>
                  )}
                </Card>
              );
            })}
          </div>
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
        className="bg-black/40 border border-primary/20 rounded-2xl p-8 space-y-6">
        <h2 className="text-xl font-display font-bold text-white">SUBMIT CREDENTIALS</h2>

        <div className="space-y-4">
          <div className="space-y-2">
            <p className="font-mono text-sm text-accent">Category</p>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full bg-black/60 border border-white/10 rounded-lg p-3 font-mono text-sm text-white focus:border-primary/50 outline-none"
              data-testid="select-pro-category"
            >
              <option value="">Select a licensed category...</option>
              {Object.entries(LICENSED_CATEGORIES).map(([key, info]) => (
                <option key={key} value={key}>{info.label}</option>
              ))}
            </select>
          </div>

          {categoryInfo && (
            <div className="bg-black/40 border border-accent/10 rounded-lg p-4 space-y-2">
              <p className="font-mono text-xs text-accent font-bold">REQUIRED DOCUMENTATION</p>
              <p className="font-mono text-xs text-gray-400">{categoryInfo.requiredDocs}</p>
              <p className="font-mono text-xs text-muted-foreground">Examples: {categoryInfo.examples}</p>
            </div>
          )}

          <div className="space-y-2">
            <p className="font-mono text-sm text-accent">License / Certification Type</p>
            <input
              type="text"
              value={licenseType}
              onChange={(e) => setLicenseType(e.target.value)}
              placeholder="e.g., Forklift Operator License, Electrician License"
              className="w-full bg-black/60 border border-white/10 rounded-lg p-3 font-mono text-sm text-white placeholder:text-gray-600 focus:border-primary/50 outline-none"
              data-testid="input-license-type"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <p className="font-mono text-sm text-accent">License / Cert Number (optional)</p>
              <input
                type="text"
                value={licenseNumber}
                onChange={(e) => setLicenseNumber(e.target.value)}
                placeholder="e.g., FL-12345"
                className="w-full bg-black/60 border border-white/10 rounded-lg p-3 font-mono text-sm text-white placeholder:text-gray-600 focus:border-primary/50 outline-none"
                data-testid="input-license-number"
              />
            </div>
            <div className="space-y-2">
              <p className="font-mono text-sm text-accent">Issuing Authority (optional)</p>
              <input
                type="text"
                value={issuingAuthority}
                onChange={(e) => setIssuingAuthority(e.target.value)}
                placeholder="e.g., State of Illinois, OSHA"
                className="w-full bg-black/60 border border-white/10 rounded-lg p-3 font-mono text-sm text-white placeholder:text-gray-600 focus:border-primary/50 outline-none"
                data-testid="input-issuing-authority"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <p className="font-mono text-sm text-accent">Expiration Date (optional)</p>
              <input
                type="date"
                value={expirationDate}
                onChange={(e) => setExpirationDate(e.target.value)}
                className="w-full bg-black/60 border border-white/10 rounded-lg p-3 font-mono text-sm text-white focus:border-primary/50 outline-none"
                data-testid="input-expiration-date"
              />
            </div>
            <div className="space-y-2">
              <p className="font-mono text-sm text-accent">Business Name (optional)</p>
              <input
                type="text"
                value={businessName}
                onChange={(e) => setBusinessName(e.target.value)}
                placeholder="e.g., Your company name"
                className="w-full bg-black/60 border border-white/10 rounded-lg p-3 font-mono text-sm text-white placeholder:text-gray-600 focus:border-primary/50 outline-none"
                data-testid="input-business-name"
              />
            </div>
          </div>

          <div className="space-y-2">
            <p className="font-mono text-sm text-accent">Upload License / Certification Document</p>
            <p className="font-mono text-xs text-muted-foreground">Clear photo or scan of your license, certification card, or credential document.</p>
            <label className="flex items-center gap-3 cursor-pointer bg-black/40 border border-white/10 rounded-lg p-4 hover:border-primary/30 transition-colors">
              <Upload className="w-5 h-5 text-primary" />
              <span className="font-mono text-sm text-gray-300">
                {uploading ? "Uploading..." : documentPath ? "Document Uploaded" : "Choose File"}
              </span>
              <input
                type="file"
                accept="image/*,.pdf"
                className="hidden"
                onChange={handleFileUpload}
                disabled={uploading}
                data-testid="input-doc-upload"
              />
            </label>
            {documentPath && (
              <p className="font-mono text-xs text-green-400 flex items-center gap-1">
                <CheckCircle className="w-3 h-3" /> Document uploaded successfully
              </p>
            )}
          </div>

          <CyberButton
            className="w-full"
            onClick={() => submitVerification.mutate()}
            loading={submitVerification.isPending}
            disabled={!documentPath || uploading || !selectedCategory || !licenseType}
            data-testid="button-submit-pro-verification"
          >
            SUBMIT CREDENTIALS FOR REVIEW
          </CyberButton>

          {submitVerification.isError && (
            <p className="font-mono text-xs text-red-400 flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" /> {(submitVerification.error as Error).message}
            </p>
          )}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        className="bg-black/20 border border-white/5 rounded-xl p-6">
        <h3 className="font-display font-bold text-white mb-3">LICENSED CATEGORIES</h3>
        <div className="space-y-4">
          {Object.entries(LICENSED_CATEGORIES).map(([key, info]) => (
            <div key={key} className="flex items-start gap-3">
              <FileCheck className="w-4 h-4 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-mono text-sm text-white font-bold">{info.label}</p>
                <p className="font-mono text-xs text-muted-foreground">{info.requiredDocs}</p>
              </div>
            </div>
          ))}
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}
        className="bg-black/20 border border-white/5 rounded-xl p-6">
        <h3 className="font-display font-bold text-white mb-3">HOW IT WORKS</h3>
        <ul className="font-mono text-sm text-gray-400 space-y-3">
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">01.</span> Select the category you work in or are hiring for</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">02.</span> Enter your license or certification details</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">03.</span> Upload a clear photo of your credential document</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">04.</span> Our admin team reviews and approves your credentials</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">05.</span> Once approved, you can post and work in that category</li>
        </ul>
      </motion.div>
    </div>
  );
}
