import { useState, useMemo } from "react";
import { useProfiles } from "@/hooks/use-stage-link";
import { useAuth } from "@/hooks/use-auth";
import { CyberButton } from "@/components/CyberButton";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { BadgeCheck, DollarSign, Lock, UserPlus, Filter, Share2, Check } from "lucide-react";
import type { Profile } from "@shared/schema";

export default function Profiles() {
  const { isAuthenticated } = useAuth();
  const { data, isLoading, error } = useProfiles();
  const [activeFilters, setActiveFilters] = useState<Set<string>>(new Set());

  const profiles = data?.profiles;
  const viewerCategory = data?.viewerCategory;
  const hasProfile = data?.hasProfile ?? false;
  const nsfwBlocked = data?.nsfwBlocked ?? false;
  const allowedCategories = data?.allowedCategories ?? [];
  const categoryGroupName = data?.categoryGroupName;

  const filteredProfiles = useMemo(() => {
    if (!profiles) return [];
    if (activeFilters.size === 0) return profiles;
    return profiles.filter((p: Profile) => activeFilters.has(p.category));
  }, [profiles, activeFilters]);

  const toggleFilter = (cat: string) => {
    setActiveFilters(prev => {
      const next = new Set(prev);
      if (next.has(cat)) {
        next.delete(cat);
      } else {
        next.add(cat);
      }
      return next;
    });
  };

  const [copiedSlug, setCopiedSlug] = useState<string | null>(null);

  const copyProfileLink = async (slug: string, e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/profiles/${slug}`);
      setCopiedSlug(slug);
      setTimeout(() => setCopiedSlug(null), 2000);
    } catch {
    }
  };

  const selectAll = () => setActiveFilters(new Set());

  if (isLoading) return <div className="text-center font-mono py-20 animate-pulse text-primary">LOADING TALENT DATABASE...</div>;
  if (error) return <div className="text-center font-mono py-20 text-destructive">ERROR LOADING PROFILES</div>;

  return (
    <div className="space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-end gap-4 border-b border-white/10 pb-6">
        <div>
          <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-accent to-blue-600 mb-2 glitch-text" data-text="TALENT NETWORK" data-testid="text-talent-title">
            TALENT NETWORK
          </h1>
          <p className="font-mono text-gray-400" data-testid="text-talent-subtitle">
            {categoryGroupName
              ? `Showing ${categoryGroupName} talent for your account.`
              : viewerCategory
                ? `Showing ${viewerCategory} talent for your account.`
                : "Browse verified talent ready for deployment."}
          </p>
        </div>
        <Link href="/me">
          <CyberButton variant="primary" data-testid="button-my-profile">My Profile</CyberButton>
        </Link>
      </div>

      {allowedCategories.length > 1 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-3"
          data-testid="section-subcategory-filters"
        >
          <div className="flex items-center gap-2 flex-wrap">
            <Filter className="w-4 h-4 text-accent flex-shrink-0" />
            <span className="font-mono text-sm text-muted-foreground">Filter by subcategory:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={activeFilters.size === 0 ? "default" : "outline"}
              size="sm"
              onClick={selectAll}
              data-testid="button-filter-all"
            >
              All ({profiles?.length ?? 0})
            </Button>
            {allowedCategories.map(cat => {
              const count = profiles?.filter((p: Profile) => p.category === cat).length ?? 0;
              const isActive = activeFilters.has(cat);
              return (
                <Button
                  key={cat}
                  variant={isActive ? "default" : "outline"}
                  size="sm"
                  onClick={() => toggleFilter(cat)}
                  className={isActive ? "" : "border-white/20 text-gray-300"}
                  data-testid={`button-filter-${cat.toLowerCase().replace(/[^a-z0-9]/g, "-")}`}
                >
                  {cat} ({count})
                </Button>
              );
            })}
          </div>
        </motion.div>
      )}

      {viewerCategory && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-primary/5 border border-primary/20 rounded-xl p-4 flex items-center gap-3 flex-wrap"
          data-testid="banner-category-locked"
        >
          <Lock className="w-5 h-5 text-primary flex-shrink-0" />
          <div className="flex-1">
            <p className="font-mono text-sm text-white">
              Your account is set to <span className="text-primary font-bold">{viewerCategory}</span>.
              {categoryGroupName
                ? ` You can browse all ${categoryGroupName} talent.`
                : " You can only browse talent in your category."}
            </p>
            <p className="font-mono text-xs text-muted-foreground mt-1">
              To change your category, update your profile settings.
            </p>
          </div>
        </motion.div>
      )}

      {!isAuthenticated && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-accent/5 border border-accent/20 rounded-xl p-4 flex items-center gap-3 flex-wrap"
          data-testid="banner-login-prompt"
        >
          <UserPlus className="w-5 h-5 text-accent flex-shrink-0" />
          <div className="flex-1">
            <p className="font-mono text-sm text-white">
              Sign in and create a profile to see talent in your specific category.
            </p>
          </div>
          <a href="/api/login">
            <CyberButton variant="accent" data-testid="button-login-talent">Sign In</CyberButton>
          </a>
        </motion.div>
      )}

      {nsfwBlocked && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-red-500/5 border border-red-500/20 rounded-xl p-4 flex items-center gap-3 flex-wrap"
          data-testid="banner-nsfw-blocked"
        >
          <Lock className="w-5 h-5 text-red-400 flex-shrink-0" />
          <div className="flex-1">
            <p className="font-mono text-sm text-white">
              Your account is set to <span className="text-red-400 font-bold">Adult/NSFW</span> but you haven't completed age verification yet.
            </p>
            <p className="font-mono text-xs text-muted-foreground mt-1">
              Complete ID verification with age confirmation to view Adult/NSFW talent.
            </p>
          </div>
          <Link href="/verification">
            <CyberButton variant="primary" data-testid="button-verify-nsfw">Verify Now</CyberButton>
          </Link>
        </motion.div>
      )}

      {isAuthenticated && !hasProfile && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-accent/5 border border-accent/20 rounded-xl p-4 flex items-center gap-3 flex-wrap"
          data-testid="banner-create-profile"
        >
          <UserPlus className="w-5 h-5 text-accent flex-shrink-0" />
          <div className="flex-1">
            <p className="font-mono text-sm text-white">
              Create a profile to lock into your specific category and see matching talent only.
            </p>
          </div>
          <Link href="/me">
            <CyberButton variant="accent" data-testid="button-create-profile-cta">Set Up Profile</CyberButton>
          </Link>
        </motion.div>
      )}

      {filteredProfiles.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground font-mono" data-testid="text-empty-profiles">
          {activeFilters.size > 0
            ? `No talent found for the selected filters. Try selecting different subcategories.`
            : viewerCategory
              ? `No ${categoryGroupName || viewerCategory} talent profiles found yet. Check back soon.`
              : "No talent profiles found."}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredProfiles.map((profile: Profile, i: number) => (
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: i * 0.05 }}
              key={profile.id}
            >
              <Link href={`/profiles/${profile.profileSlug}`}>
                <div className="group relative bg-black/40 border border-white/10 rounded-xl overflow-hidden hover:border-accent/50 transition-all duration-300 h-full flex flex-col" data-testid={`card-profile-${profile.id}`}>
                  <div className="h-32 bg-gradient-to-br from-gray-900 to-black relative">
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 opacity-30 group-hover:opacity-50 transition-opacity"></div>
                    <div className="absolute -bottom-8 left-6">
                      <div className="w-16 h-16 rounded-full bg-black border-2 border-accent p-1">
                        <div className="w-full h-full rounded-full bg-accent/20 flex items-center justify-center text-accent font-bold text-xl">
                          {profile.displayName.substring(0, 2).toUpperCase()}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="pt-10 p-6 flex-1 flex flex-col">
                    <div className="flex justify-between items-start mb-2 flex-wrap gap-1">
                      <h3 className="font-display font-bold text-xl text-white group-hover:text-accent transition-colors" data-testid={`text-profile-name-${profile.id}`}>
                        {profile.displayName}
                      </h3>
                      {profile.verified && <BadgeCheck className="w-5 h-5 text-primary" />}
                    </div>

                    <p className="text-xs font-mono text-accent mb-4 uppercase tracking-widest" data-testid={`text-profile-category-${profile.id}`}>
                      {profile.category} / {profile.tier}
                    </p>

                    <p className="text-sm text-gray-400 line-clamp-3 mb-6 flex-1 font-mono">
                      {profile.bio || "No bio available."}
                    </p>

                    <div className="mt-auto pt-4 border-t border-white/5 flex justify-between items-center flex-wrap gap-1">
                      <div className="flex items-center text-white font-bold">
                        <DollarSign className="w-4 h-4 text-accent" />
                        {profile.baseRate} <span className="text-xs text-gray-500 font-normal ml-1">/ hr</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e: React.MouseEvent) => copyProfileLink(profile.profileSlug, e)}
                          className="font-mono text-xs"
                          data-testid={`button-copy-link-${profile.id}`}
                        >
                          {copiedSlug === profile.profileSlug ? (
                            <><Check className="w-3 h-3 text-green-400" /><span className="text-green-400">Copied</span></>
                          ) : (
                            <><Share2 className="w-3 h-3" /><span>Share</span></>
                          )}
                        </Button>
                        <span className="text-xs text-primary font-bold hover:underline cursor-pointer" data-testid={`link-view-profile-${profile.id}`}>
                          VIEW PROFILE
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
