import { useState } from "react";
import { useRoute, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { CyberButton } from "@/components/CyberButton";
import { Button } from "@/components/ui/button";
import { isBoostActive } from "@shared/pricing";
import {
  ArrowLeft, ThumbsUp, ThumbsDown, User, MapPin, Calendar, DollarSign,
  Flame, BadgeCheck, Instagram, Youtube, Twitter, MessageSquare, Send,
  UserPlus, UserMinus, Users, Share2, Check
} from "lucide-react";
import { SiTiktok } from "react-icons/si";
import { Textarea } from "@/components/ui/textarea";
import { motion } from "framer-motion";
import type { Post, Review } from "@shared/schema";

export default function PosterProfile() {
  const [, params] = useRoute("/poster/:userId");
  const [, navigate] = useLocation();
  const userId = params?.userId || "";
  const { user, isAuthenticated } = useAuth();
  const [reviewRating, setReviewRating] = useState<1 | -1 | null>(null);
  const [reviewComment, setReviewComment] = useState("");
  const [linkCopied, setLinkCopied] = useState(false);

  const copyProfileLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } catch {
      const input = document.createElement("input");
      input.value = window.location.href;
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      document.body.removeChild(input);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    }
  };

  const { data: posterData, isLoading, error } = useQuery<any>({
    queryKey: ["/api/poster-profile", userId],
    queryFn: async () => {
      const res = await fetch(`/api/poster-profile/${userId}`);
      if (!res.ok) throw new Error("Poster not found");
      return res.json();
    },
    enabled: !!userId,
  });

  const submitReview = useMutation({
    mutationFn: async () => {
      if (!posterData?.profile?.id || reviewRating === null) return;
      return apiRequest("POST", "/api/reviews", {
        targetProfileId: posterData.profile.id,
        targetType: "poster",
        rating: reviewRating,
        comment: reviewComment || null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/poster-profile", userId] });
      setReviewRating(null);
      setReviewComment("");
    },
  });

  const { data: followCheck } = useQuery<{ following: boolean }>({
    queryKey: ["/api/follows/check", userId],
    queryFn: async () => {
      const res = await fetch(`/api/follows/check/${userId}`);
      return res.json();
    },
    enabled: isAuthenticated && !!userId,
  });

  const followMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/follows", { followedUserId: userId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follows/check", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/posters"] });
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/follows/${userId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follows/check", userId] });
      queryClient.invalidateQueries({ queryKey: ["/api/posters"] });
    },
  });

  const isFollowing = followCheck?.following || false;

  if (isLoading) return <div className="text-center py-20 font-mono text-accent animate-pulse" data-testid="text-loading">Loading host profile...</div>;
  if (!posterData || error) return <div className="text-center py-20 font-mono text-destructive" data-testid="text-not-found">Host not found.</div>;

  const { profile, posterName, posts, reviews, reviewSummary } = posterData;
  const isOwnProfile = (user as any)?.claims?.sub === userId;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <button
        type="button"
        onClick={() => navigate("/")}
        className="flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-white transition-colors"
        data-testid="button-back"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Feed
      </button>

      <div className="relative rounded-2xl overflow-hidden bg-black/40 border border-white/10">
        <div className="h-32 bg-gradient-to-r from-orange-900/40 to-pink-900/40">
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
        </div>

        <div className="px-8 pb-8 flex flex-col md:flex-row gap-6 items-start -mt-12 relative z-10">
          <div className="w-24 h-24 rounded-full bg-black border-4 border-background shadow-xl flex items-center justify-center bg-zinc-900 text-2xl font-display font-bold text-gray-500" data-testid="img-poster-avatar">
            {posterName?.substring(0, 2).toUpperCase() || "??"}
          </div>

          <div className="flex-1 pt-10 md:pt-8">
            <div className="flex flex-col md:flex-row justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h1 className="text-3xl font-black text-white font-display uppercase" data-testid="text-poster-name">{posterName}</h1>
                  {profile?.verified && <BadgeCheck className="w-5 h-5 text-primary neon-text" />}
                </div>
                <p className="font-mono text-sm text-gray-400">
                  {profile?.category ? `${profile.category} professional` : "Opportunity host"}
                </p>
              </div>

              <div className="flex items-center gap-4">
                {isAuthenticated && !isOwnProfile && (
                  <CyberButton
                    variant={isFollowing ? "accent" : "primary"}
                    onClick={() => {
                      if (isFollowing) {
                        unfollowMutation.mutate();
                      } else {
                        followMutation.mutate();
                      }
                    }}
                    loading={followMutation.isPending || unfollowMutation.isPending}
                    className="text-xs"
                    data-testid="button-follow-poster"
                  >
                    {isFollowing ? (
                      <><UserMinus className="w-3 h-3" /> UNFOLLOW</>
                    ) : (
                      <><UserPlus className="w-3 h-3" /> FOLLOW</>
                    )}
                  </CyberButton>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={copyProfileLink}
                  className="font-mono text-xs"
                  data-testid="button-share-profile"
                >
                  {linkCopied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Share2 className="w-3.5 h-3.5" />}
                  {linkCopied ? "Copied" : "Share"}
                </Button>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2 font-mono">
                  <ThumbsUp className="w-5 h-5 text-green-400" />
                  <span className="text-white font-bold text-xl" data-testid="text-likes">{reviewSummary?.likes || 0}</span>
                </div>
                <div className="flex items-center gap-2 font-mono">
                  <ThumbsDown className="w-5 h-5 text-red-400" />
                  <span className="text-white font-bold text-xl" data-testid="text-dislikes">{reviewSummary?.dislikes || 0}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          {profile?.bio && (
            <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-lg font-display font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-primary rounded-full"></span>
                ABOUT
              </h2>
              <p className="font-mono text-gray-300 leading-relaxed whitespace-pre-line" data-testid="text-bio">
                {profile.bio}
              </p>
            </section>
          )}

          {(profile?.instagram || profile?.tiktok || profile?.youtube || profile?.twitter) && (
            <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-lg font-display font-bold text-white mb-3 flex items-center gap-2">
                <span className="w-1 h-5 bg-accent rounded-full"></span>
                SOCIAL
              </h2>
              <div className="flex flex-wrap gap-3">
                {profile.instagram && (
                  <a href={`https://instagram.com/${profile.instagram.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-primary hover:border-primary/30 transition-colors">
                    <Instagram className="w-4 h-4" /> {profile.instagram}
                  </a>
                )}
                {profile.tiktok && (
                  <a href={`https://tiktok.com/@${profile.tiktok.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-accent hover:border-accent/30 transition-colors">
                    <SiTiktok className="w-4 h-4" /> {profile.tiktok}
                  </a>
                )}
                {profile.youtube && (
                  <a href={profile.youtube.startsWith('http') ? profile.youtube : `https://youtube.com/@${profile.youtube.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-red-400 hover:border-red-400/30 transition-colors">
                    <Youtube className="w-4 h-4" /> {profile.youtube}
                  </a>
                )}
                {profile.twitter && (
                  <a href={`https://x.com/${profile.twitter.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-blue-400 hover:border-blue-400/30 transition-colors">
                    <Twitter className="w-4 h-4" /> {profile.twitter}
                  </a>
                )}
              </div>
            </section>
          )}

          <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
              <span className="w-1 h-5 bg-accent rounded-full"></span>
              POSTED OPPORTUNITIES ({posts?.length || 0})
            </h2>
            {posts && posts.length > 0 ? (
              <div className="space-y-3">
                {posts.map((p: Post) => {
                  const boosted = isBoostActive(p.boostExpiresAt);
                  return (
                    <Link
                      key={p.id}
                      href={`/opportunity/${p.id}`}
                      className={`block p-4 rounded-lg border transition-colors ${
                        boosted ? "border-primary/30 bg-primary/5 hover:bg-primary/10" : "border-white/5 bg-black/20 hover:bg-white/5"
                      }`}
                      data-testid={`link-post-${p.id}`}
                    >
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex-1">
                          <h3 className="font-bold text-white font-display">{p.title}</h3>
                          <div className="flex items-center gap-3 font-mono text-xs text-gray-400 mt-1">
                            <span className="flex items-center gap-1">
                              <DollarSign className="w-3 h-3 text-accent" /> ${p.pay}
                            </span>
                            <span>{p.category}</span>
                            {p.venue && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {p.venue}</span>}
                            {p.date && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {p.date}</span>}
                          </div>
                        </div>
                        {boosted && <Flame className="w-4 h-4 text-primary shrink-0" />}
                      </div>
                    </Link>
                  );
                })}
              </div>
            ) : (
              <p className="font-mono text-sm text-gray-500">No opportunities posted yet.</p>
            )}
          </section>

          <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
              <MessageSquare className="w-5 h-5 text-primary" />
              REVIEWS ({reviews?.length || 0})
            </h2>
            {reviews && reviews.length > 0 ? (
              <div className="space-y-4">
                {reviews.map((r: Review) => (
                  <div key={r.id} className="p-4 rounded-lg border border-white/5 bg-black/20" data-testid={`review-${r.id}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {r.rating === 1 ? (
                        <ThumbsUp className="w-4 h-4 text-green-400" />
                      ) : (
                        <ThumbsDown className="w-4 h-4 text-red-400" />
                      )}
                      <span className="font-mono text-xs text-gray-500">
                        {new Date(r.createdAt!).toLocaleDateString()}
                      </span>
                    </div>
                    {r.comment && (
                      <p className="font-mono text-sm text-gray-300">{r.comment}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="font-mono text-sm text-gray-500">No reviews yet. Be the first to leave feedback.</p>
            )}
          </section>
        </div>

        <div className="space-y-6">
          <div className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
            <h3 className="font-display font-bold text-white mb-3 text-sm">REPUTATION</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="font-mono text-xs text-gray-400">Likes</span>
                <span className="font-mono text-green-400 font-bold" data-testid="text-stat-likes">{reviewSummary?.likes || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-mono text-xs text-gray-400">Dislikes</span>
                <span className="font-mono text-red-400 font-bold" data-testid="text-stat-dislikes">{reviewSummary?.dislikes || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-mono text-xs text-gray-400">Total Reviews</span>
                <span className="font-mono text-white font-bold">{reviewSummary?.total || 0}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="font-mono text-xs text-gray-400">Opportunities</span>
                <span className="font-mono text-white font-bold">{posts?.length || 0}</span>
              </div>
            </div>
          </div>

          {isAuthenticated && !isOwnProfile && profile?.id && (
            <div className="bg-gradient-to-b from-primary/10 to-transparent border border-primary/20 rounded-xl p-6">
              <h3 className="font-display font-bold text-primary mb-3 text-sm">LEAVE A REVIEW</h3>
              <div className="flex gap-3 mb-3">
                <button
                  type="button"
                  onClick={() => setReviewRating(1)}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg border font-mono text-sm transition-colors ${
                    reviewRating === 1
                      ? "border-green-400/50 bg-green-400/20 text-green-400"
                      : "border-white/10 bg-black/40 text-gray-400 hover:text-green-400"
                  }`}
                  data-testid="button-like"
                >
                  <ThumbsUp className="w-4 h-4" /> Like
                </button>
                <button
                  type="button"
                  onClick={() => setReviewRating(-1)}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg border font-mono text-sm transition-colors ${
                    reviewRating === -1
                      ? "border-red-400/50 bg-red-400/20 text-red-400"
                      : "border-white/10 bg-black/40 text-gray-400 hover:text-red-400"
                  }`}
                  data-testid="button-dislike"
                >
                  <ThumbsDown className="w-4 h-4" /> Dislike
                </button>
              </div>
              <Textarea
                placeholder="Optional comment..."
                className="bg-black/40 border-white/10 focus:border-primary font-mono resize-none min-h-[60px] mb-3"
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                data-testid="input-review-comment"
              />
              <CyberButton
                className="w-full"
                onClick={() => submitReview.mutate()}
                loading={submitReview.isPending}
                disabled={reviewRating === null}
                data-testid="button-submit-review"
              >
                <Send className="w-4 h-4" /> SUBMIT REVIEW
              </CyberButton>
              {submitReview.isError && (
                <p className="font-mono text-xs text-red-400 mt-2 text-center">
                  {(submitReview.error as any)?.message || "Failed to submit review"}
                </p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
