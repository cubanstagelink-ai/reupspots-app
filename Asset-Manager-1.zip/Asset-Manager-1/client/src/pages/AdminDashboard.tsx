import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { ADMIN_EMAILS } from "@shared/schema";
import { Link } from "wouter";
import {
  Shield, FileText, Users, Briefcase, CheckCircle, Clock,
  ShieldCheck, BarChart3, TrendingUp, ArrowLeft, AlertTriangle
} from "lucide-react";
import { motion } from "framer-motion";
import type { Post, Booking } from "@shared/schema";

type AdminStats = {
  totalPosts: number;
  activePosts: number;
  totalBookings: number;
  pendingBookings: number;
  confirmedBookings: number;
  pendingVerifications: number;
  approvedVerifications: number;
  pendingProfVerifications: number;
  categoryBreakdown: Record<string, number>;
  recentPosts: Post[];
  recentBookings: Booking[];
  totalVerifications: number;
  totalProfVerifications: number;
};

function StatCard({ icon: Icon, label, value, accent = false, alert = false }: {
  icon: any;
  label: string;
  value: number | string;
  accent?: boolean;
  alert?: boolean;
}) {
  return (
    <div className={`bg-black/30 border rounded-xl p-5 ${
      alert ? "border-yellow-500/30" : accent ? "border-primary/30" : "border-white/10"
    }`} data-testid={`stat-${label.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="flex items-center gap-3 mb-2">
        <Icon className={`w-5 h-5 ${alert ? "text-yellow-400" : accent ? "text-primary" : "text-muted-foreground"}`} />
        <span className="font-mono text-xs text-muted-foreground uppercase tracking-wider">{label}</span>
      </div>
      <p className={`text-3xl font-black font-display ${alert ? "text-yellow-400" : accent ? "text-primary neon-text" : "text-white"}`}>
        {value}
      </p>
    </div>
  );
}

export default function AdminDashboard() {
  const { user, isAuthenticated } = useAuth();
  const isAdmin = !!user?.email && ADMIN_EMAILS.includes(user.email);

  const { data: stats, isLoading } = useQuery<AdminStats>({
    queryKey: ["/api/admin/stats"],
    enabled: isAuthenticated && isAdmin,
  });

  if (!isAuthenticated) {
    return (
      <div className="text-center py-20">
        <Shield className="w-12 h-12 mx-auto mb-4 text-muted-foreground/40" />
        <p className="font-mono text-muted-foreground">Authentication required</p>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="text-center py-20">
        <Shield className="w-12 h-12 mx-auto mb-4 text-destructive/40" />
        <p className="font-mono text-destructive">Access denied. Admin privileges required.</p>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="text-center py-20 font-mono text-accent animate-pulse" data-testid="text-loading">
        Loading admin dashboard...
      </div>
    );
  }

  if (!stats) return null;

  const categoryEntries = Object.entries(stats.categoryBreakdown).sort((a, b) => b[1] - a[1]);
  const maxCategoryCount = categoryEntries.length > 0 ? categoryEntries[0][1] : 1;

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex items-center gap-4">
        <Link href="/">
          <button type="button" className="flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-white transition-colors cursor-pointer" data-testid="button-back">
            <ArrowLeft className="w-4 h-4" /> Back
          </button>
        </Link>
      </div>

      <div className="text-center space-y-3">
        <h1 className="text-4xl md:text-5xl font-black font-display uppercase tracking-tight" data-testid="text-page-title">
          <span className="text-white">Admin</span>{" "}
          <span className="text-primary neon-text">Panel</span>
        </h1>
        <p className="font-mono text-sm text-muted-foreground">
          Platform overview and management
        </p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={FileText} label="Total Posts" value={stats.totalPosts} accent />
        <StatCard icon={TrendingUp} label="Active Posts" value={stats.activePosts} />
        <StatCard icon={Briefcase} label="Total Bookings" value={stats.totalBookings} accent />
        <StatCard icon={CheckCircle} label="Confirmed" value={stats.confirmedBookings} />
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={Clock} label="Pending Bookings" value={stats.pendingBookings} alert={stats.pendingBookings > 0} />
        <StatCard icon={ShieldCheck} label="Pending ID Verify" value={stats.pendingVerifications} alert={stats.pendingVerifications > 0} />
        <StatCard icon={ShieldCheck} label="Pending Pro Verify" value={stats.pendingProfVerifications} alert={stats.pendingProfVerifications > 0} />
        <StatCard icon={CheckCircle} label="Approved IDs" value={stats.approvedVerifications} />
      </div>

      {stats.pendingVerifications > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex items-center gap-3"
        >
          <AlertTriangle className="w-5 h-5 text-yellow-400 shrink-0" />
          <div className="flex-1">
            <p className="font-mono text-sm text-yellow-400">
              {stats.pendingVerifications} ID verification{stats.pendingVerifications > 1 ? "s" : ""} awaiting review
            </p>
          </div>
          <Link href="/verification">
            <button type="button" className="px-3 py-1.5 rounded-lg border border-yellow-500/30 bg-yellow-500/10 font-mono text-xs text-yellow-400 hover:bg-yellow-500/20 transition-colors cursor-pointer" data-testid="button-review-verifications">
              Review
            </button>
          </Link>
        </motion.div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
          <h2 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-primary" />
            CATEGORY BREAKDOWN
          </h2>
          <div className="space-y-3">
            {categoryEntries.map(([cat, count]) => (
              <div key={cat} className="space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs text-gray-400">{cat}</span>
                  <span className="font-mono text-xs text-white font-bold">{count}</span>
                </div>
                <div className="w-full h-2 bg-black/40 rounded-full overflow-hidden">
                  <motion.div
                    className="h-full bg-gradient-to-r from-primary to-accent rounded-full"
                    initial={{ width: 0 }}
                    animate={{ width: `${(count / maxCategoryCount) * 100}%` }}
                    transition={{ duration: 0.6, delay: 0.1 }}
                  />
                </div>
              </div>
            ))}
            {categoryEntries.length === 0 && (
              <p className="font-mono text-sm text-gray-500">No posts yet</p>
            )}
          </div>
        </div>

        <div className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
          <h2 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
            <FileText className="w-5 h-5 text-accent" />
            RECENT POSTS
          </h2>
          <div className="space-y-2">
            {stats.recentPosts.map((p) => (
              <Link key={p.id} href={`/opportunity/${p.id}`}>
                <div className="flex items-center justify-between gap-2 p-3 rounded-lg border border-white/5 bg-black/20 hover:bg-white/5 cursor-pointer transition-colors" data-testid={`admin-post-${p.id}`}>
                  <div className="flex-1 min-w-0">
                    <p className="font-mono text-sm text-white truncate">{p.title}</p>
                    <p className="font-mono text-[10px] text-muted-foreground">{p.category} &bull; ${p.pay}</p>
                  </div>
                  <span className="font-mono text-[10px] text-muted-foreground shrink-0">
                    {new Date(p.createdAt!).toLocaleDateString()}
                  </span>
                </div>
              </Link>
            ))}
            {stats.recentPosts.length === 0 && (
              <p className="font-mono text-sm text-gray-500">No posts yet</p>
            )}
          </div>
        </div>
      </div>

      <div className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
        <h2 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
          <Briefcase className="w-5 h-5 text-primary" />
          RECENT BOOKINGS
        </h2>
        <div className="space-y-2">
          {stats.recentBookings.map((b) => {
            const statusColors: Record<string, string> = {
              pending_payment: "text-yellow-400",
              payment_submitted: "text-blue-400",
              deposit_paid: "text-cyan-400",
              confirmed: "text-green-400",
              cancelled: "text-red-400",
            };
            return (
              <div key={b.id} className="flex items-center justify-between gap-2 p-3 rounded-lg border border-white/5 bg-black/20" data-testid={`admin-booking-${b.id}`}>
                <div className="flex-1 min-w-0">
                  <p className="font-mono text-sm text-white">Booking #{b.id}</p>
                  <p className="font-mono text-[10px] text-muted-foreground">Post #{b.postId}</p>
                </div>
                <span className={`font-mono text-xs font-bold uppercase ${statusColors[b.status || ""] || "text-gray-400"}`}>
                  {(b.status || "").replace(/_/g, " ")}
                </span>
                <span className="font-mono text-[10px] text-muted-foreground shrink-0">
                  {new Date(b.createdAt!).toLocaleDateString()}
                </span>
              </div>
            );
          })}
          {stats.recentBookings.length === 0 && (
            <p className="font-mono text-sm text-gray-500">No bookings yet</p>
          )}
        </div>
      </div>
    </div>
  );
}
