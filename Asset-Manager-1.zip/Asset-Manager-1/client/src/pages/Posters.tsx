import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { CyberButton } from "@/components/CyberButton";
import { CATEGORIES } from "@shared/schema";
import {
  Users, UserPlus, UserMinus, BadgeCheck, ThumbsUp, ThumbsDown,
  Building2, Briefcase, Search, Filter
} from "lucide-react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/input";

type Poster = {
  userId: string;
  name: string;
  bio: string | null;
  verified: boolean;
  categories: string[];
  postCount: number;
  followerCount: number;
  reviewSummary: { likes: number; dislikes: number; total: number };
  profileId: number | null;
};

export default function Posters() {
  const { isAuthenticated } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");

  const { data: posters, isLoading } = useQuery<Poster[]>({
    queryKey: ["/api/posters"],
  });

  const { data: myFollows } = useQuery<{ followedUserId: string }[]>({
    queryKey: ["/api/follows/mine"],
    enabled: isAuthenticated,
  });

  const followMutation = useMutation({
    mutationFn: async (followedUserId: string) => {
      return apiRequest("POST", "/api/follows", { followedUserId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follows/mine"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posters"] });
    },
  });

  const unfollowMutation = useMutation({
    mutationFn: async (followedUserId: string) => {
      return apiRequest("DELETE", `/api/follows/${followedUserId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/follows/mine"] });
      queryClient.invalidateQueries({ queryKey: ["/api/posters"] });
    },
  });

  const followedIds = new Set((myFollows || []).map(f => f.followedUserId));

  const allCategories = Array.from(
    new Set((posters || []).flatMap(p => p.categories))
  ).sort();

  const filtered = (posters || []).filter(p => {
    if (searchTerm && !p.name.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    if (categoryFilter !== "All" && !p.categories.includes(categoryFilter)) return false;
    return true;
  });

  return (
    <div className="space-y-8">
      <div className="text-center space-y-3">
        <h1 className="text-4xl md:text-5xl font-black font-display uppercase tracking-tight" data-testid="text-page-title">
          <span className="text-white">Host</span>{" "}
          <span className="text-primary neon-text">Directory</span>
        </h1>
        <p className="font-mono text-sm text-muted-foreground max-w-md mx-auto">
          Follow businesses and promoters to get notified when they post new opportunities
        </p>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 max-w-2xl mx-auto">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search hosts..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 bg-black/40 border-white/10 focus:border-primary font-mono"
            data-testid="input-search-posters"
          />
        </div>
        <div className="relative">
          <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full sm:w-auto pl-10 pr-8 py-2 rounded-md bg-black/40 border border-white/10 text-white font-mono text-sm focus:border-primary focus:outline-none appearance-none cursor-pointer"
            data-testid="select-category-filter"
          >
            <option value="All">All Categories</option>
            {allCategories.map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-20 font-mono text-accent animate-pulse" data-testid="text-loading">
          Loading host directory...
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-20">
          <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground/40" />
          <p className="font-mono text-muted-foreground">No hosts found</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((poster, i) => {
            const isFollowing = followedIds.has(poster.userId);
            return (
              <motion.div
                key={poster.userId}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
                className="bg-black/30 border border-white/10 rounded-xl overflow-hidden hover:border-primary/30 transition-colors"
                data-testid={`card-poster-${poster.userId}`}
              >
                <div className="h-2 bg-gradient-to-r from-primary/40 to-accent/40" />
                <div className="p-5 space-y-4">
                  <div className="flex items-start justify-between gap-3">
                    <Link href={`/poster/${poster.userId}`}>
                      <div className="flex items-center gap-3 cursor-pointer group">
                        <div className="w-12 h-12 rounded-full bg-zinc-900 border-2 border-white/10 flex items-center justify-center text-sm font-display font-bold text-gray-400 group-hover:border-primary/40 transition-colors shrink-0">
                          {poster.name.substring(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5">
                            <h3 className="font-display font-bold text-white group-hover:text-primary transition-colors" data-testid={`text-poster-name-${poster.userId}`}>
                              {poster.name}
                            </h3>
                            {poster.verified && <BadgeCheck className="w-4 h-4 text-primary" />}
                          </div>
                          <div className="flex items-center gap-3 font-mono text-xs text-muted-foreground mt-0.5">
                            <span className="flex items-center gap-1">
                              <Briefcase className="w-3 h-3" /> {poster.postCount} posts
                            </span>
                            <span className="flex items-center gap-1">
                              <Users className="w-3 h-3" /> {poster.followerCount}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  </div>

                  <div className="flex flex-wrap gap-1.5">
                    {poster.categories.slice(0, 3).map(cat => (
                      <span key={cat} className="px-2 py-0.5 rounded-md bg-accent/10 border border-accent/20 font-mono text-[10px] text-accent uppercase tracking-wider">
                        {cat}
                      </span>
                    ))}
                    {poster.categories.length > 3 && (
                      <span className="px-2 py-0.5 rounded-md bg-white/5 border border-white/10 font-mono text-[10px] text-muted-foreground">
                        +{poster.categories.length - 3}
                      </span>
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4 font-mono text-xs">
                      <span className="flex items-center gap-1 text-green-400">
                        <ThumbsUp className="w-3 h-3" /> {poster.reviewSummary.likes}
                      </span>
                      <span className="flex items-center gap-1 text-red-400">
                        <ThumbsDown className="w-3 h-3" /> {poster.reviewSummary.dislikes}
                      </span>
                    </div>

                    {isAuthenticated && (
                      <CyberButton
                        variant={isFollowing ? "accent" : "primary"}
                        onClick={() => {
                          if (isFollowing) {
                            unfollowMutation.mutate(poster.userId);
                          } else {
                            followMutation.mutate(poster.userId);
                          }
                        }}
                        loading={followMutation.isPending || unfollowMutation.isPending}
                        className="text-xs"
                        data-testid={`button-follow-${poster.userId}`}
                      >
                        {isFollowing ? (
                          <><UserMinus className="w-3 h-3" /> Unfollow</>
                        ) : (
                          <><UserPlus className="w-3 h-3" /> Follow</>
                        )}
                      </CyberButton>
                    )}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
