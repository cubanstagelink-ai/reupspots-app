import { useState, useEffect } from "react";
import { useProfile, useCreateBooking, useMyBookings, useBookingPaymentInfo, useMarkBookingPaid } from "@/hooks/use-stage-link";
import { useAuth } from "@/hooks/use-auth";
import { useRoute } from "wouter";
import { BadgeCheck, DollarSign, ExternalLink, Lock, CheckCircle, Clock, XCircle, Instagram, Youtube, Twitter, CreditCard, Shield, ThumbsUp, ThumbsDown, MessageSquare, Send, Share2, Check, ShieldCheck } from "lucide-react";
import { SiTiktok } from "react-icons/si";
import { CyberButton } from "@/components/CyberButton";
import { Button } from "@/components/ui/button";
import { calculateTotal } from "@shared/pricing";
import { PLATFORM_FEE_PERCENT } from "@shared/schema";
import type { Booking, Review } from "@shared/schema";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Textarea } from "@/components/ui/textarea";

function BookingStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; className: string; icon: any }> = {
    pending_payment: { label: "PENDING PAYMENT", className: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10", icon: Clock },
    payment_submitted: { label: "PAYMENT SUBMITTED", className: "text-blue-400 border-blue-400/30 bg-blue-400/10", icon: Clock },
    deposit_paid: { label: "DEPOSIT PAID", className: "text-cyan-400 border-cyan-400/30 bg-cyan-400/10", icon: CheckCircle },
    confirmed: { label: "CONFIRMED", className: "text-green-400 border-green-400/30 bg-green-400/10", icon: CheckCircle },
    cancelled: { label: "CANCELLED", className: "text-red-400 border-red-400/30 bg-red-400/10", icon: XCircle },
  };
  const c = config[status] || config.pending_payment;
  const Icon = c.icon;
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 text-xs font-mono font-bold uppercase tracking-wider rounded border ${c.className}`} data-testid={`badge-booking-status-${status}`}>
      <Icon className="w-3 h-3" /> {c.label}
    </span>
  );
}

export default function ProfileDetail() {
  const [, params] = useRoute("/profiles/:slug");
  const slug = params?.slug || "";
  const { data: profile, isLoading, error } = useProfile(slug);
  const { user, isAuthenticated } = useAuth();
  const createBooking = useCreateBooking();
  const markPaid = useMarkBookingPaid();
  const { data: myBookings } = useMyBookings();
  const [activeBookingId, setActiveBookingId] = useState<number | null>(null);
  const { data: paymentInfo } = useBookingPaymentInfo(activeBookingId);
  const [reviewRating, setReviewRating] = useState<1 | -1 | null>(null);
  const [reviewComment, setReviewComment] = useState("");
  const [linkCopied, setLinkCopied] = useState(false);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const escrowStatus = params.get("escrow");
    const bookingId = params.get("bookingId");
    const sessionId = params.get("session_id");

    if (escrowStatus === "success" && bookingId) {
      fetch("/api/escrow/confirm-reservation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ bookingId: Number(bookingId), sessionId }),
      })
        .then((r) => {
          if (!r.ok) throw new Error("Failed to confirm escrow");
          return r.json();
        })
        .then((data) => {
          if (data.success) {
            queryClient.invalidateQueries({ queryKey: ["/api/bookings/mine"] });
            setActiveBookingId(Number(bookingId));
            window.history.replaceState({}, "", window.location.pathname);
          }
        })
        .catch(console.error);
    }
  }, []);

  const copyProfileLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } catch {
      const input = document.createElement("input");
      input.value = window.location.href;
      document.body.appendChild(input);
      input.select();
      document.execCommand("copy");
      document.body.removeChild(input);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    }
  };

  const { data: reviewData } = useQuery<{ reviews: Review[]; summary: { likes: number; dislikes: number; total: number } }>({
    queryKey: ["/api/reviews/talent", profile?.id],
    queryFn: async () => {
      const res = await fetch(`/api/reviews/talent/${profile?.id}`);
      if (!res.ok) return { reviews: [], summary: { likes: 0, dislikes: 0, total: 0 } };
      return res.json();
    },
    enabled: !!profile?.id,
  });

  const submitReview = useMutation({
    mutationFn: async () => {
      if (!profile?.id || reviewRating === null) return;
      return apiRequest("POST", "/api/reviews", {
        targetProfileId: profile.id,
        targetType: "talent",
        rating: reviewRating,
        comment: reviewComment || null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews/talent", profile?.id] });
      setReviewRating(null);
      setReviewComment("");
    },
  });

  if (isLoading) return <div className="text-center py-20 font-mono text-accent animate-pulse" data-testid="text-loading">Scanning database...</div>;
  if (error) return (
    <div className="text-center py-20 space-y-2" data-testid="text-restricted">
      <p className="font-mono text-destructive">{(error as Error).message || "Subject Not Found."}</p>
      <p className="font-mono text-muted-foreground text-sm">This talent has restricted their profile visibility.</p>
    </div>
  );
  if (!profile) return <div className="text-center py-20 font-mono text-destructive" data-testid="text-not-found">Subject Not Found.</div>;

  const existingBooking = myBookings?.find(
    (b: Booking) => b.workerSlug === slug && b.status !== "cancelled"
  );

  if (existingBooking && !activeBookingId) {
    setActiveBookingId(existingBooking.id);
  }

  const pricing = calculateTotal({
    basePay: profile.baseRate,
    tier: profile.tier,
    boost: "None",
  });

  const handleRequestBooking = async () => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    try {
      const result = await createBooking.mutateAsync({
        workerSlug: slug,
        tier: profile.tier,
        basePay: profile.baseRate,
        boost: "None",
      });
      setActiveBookingId(result.id);
    } catch {
      // handled in hook
    }
  };

  const handleMarkPaid = async (installment?: "deposit" | "final") => {
    if (activeBookingId) {
      await markPaid.mutateAsync({ bookingId: activeBookingId, installment });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      {/* Hero Header */}
      <div className="relative rounded-2xl overflow-hidden bg-black/40 border border-white/10">
        <div className="h-48 bg-gradient-to-r from-purple-900/50 to-blue-900/50">
           <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
        </div>

        <div className="px-8 pb-8 flex flex-col md:flex-row gap-6 items-start -mt-12 relative z-10">
          <div className="w-32 h-32 rounded-full bg-black border-4 border-background shadow-xl flex items-center justify-center bg-zinc-900 text-3xl font-display font-bold text-gray-500" data-testid="img-avatar">
             {profile.displayName.substring(0,2).toUpperCase()}
          </div>

          <div className="flex-1 pt-14 md:pt-12">
             <div className="flex flex-col md:flex-row justify-between gap-4">
               <div>
                 <div className="flex items-center gap-2 mb-1">
                   <h1 className="text-4xl font-black text-white font-display uppercase" data-testid="text-display-name">{profile.displayName}</h1>
                   {profile.verified && <BadgeCheck className="w-6 h-6 text-primary neon-text" data-testid="icon-verified" />}
                 </div>
                 <p className="font-mono text-accent text-lg tracking-wider" data-testid="text-category-tier">
                   {profile.category} <span className="text-gray-600">|</span> {profile.tier}
                 </p>
               </div>

               <div className="flex flex-col items-end gap-2">
                 <div className="flex items-center gap-1 text-2xl font-bold text-white" data-testid="text-base-rate">
                   <DollarSign className="w-6 h-6 text-accent" />
                   {profile.baseRate}
                   <span className="text-sm font-normal text-gray-400 self-end mb-1">/ session</span>
                 </div>
                 <div className="flex items-center gap-3 font-mono text-sm">
                   <span className="flex items-center gap-1 text-green-400" data-testid="text-talent-likes">
                     <ThumbsUp className="w-4 h-4" /> {reviewData?.summary?.likes || 0}
                   </span>
                   <span className="flex items-center gap-1 text-red-400" data-testid="text-talent-dislikes">
                     <ThumbsDown className="w-4 h-4" /> {reviewData?.summary?.dislikes || 0}
                   </span>
                 </div>
                 <div className="flex items-center gap-1 text-xs font-mono text-muted-foreground">
                   <Lock className="w-3 h-3" />
                   Payment revealed after booking
                 </div>
                 <Button
                   variant="ghost"
                   size="sm"
                   onClick={copyProfileLink}
                   className="font-mono text-xs mt-1"
                   data-testid="button-share-profile"
                 >
                   {linkCopied ? <Check className="w-3.5 h-3.5 text-green-400" /> : <Share2 className="w-3.5 h-3.5" />}
                   {linkCopied ? "Link Copied" : "Share Profile"}
                 </Button>
               </div>
             </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Main Info */}
        <div className="md:col-span-2 space-y-8">
          <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
              <span className="w-1 h-6 bg-primary rounded-full"></span>
              BIO_DATA
            </h2>
            <p className="font-mono text-gray-300 leading-relaxed whitespace-pre-line" data-testid="text-bio">
              {profile.bio || "No bio data uploaded to the mainframe."}
            </p>
          </section>

          {(profile.instagram || profile.tiktok || profile.youtube || profile.twitter) && (
            <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
                <span className="w-1 h-6 bg-accent rounded-full"></span>
                SOCIAL_LINKS
              </h2>
              <div className="flex flex-wrap gap-3">
                {profile.instagram && (
                  <a href={`https://instagram.com/${profile.instagram.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-primary hover:border-primary/30 transition-colors"
                    data-testid="link-instagram">
                    <Instagram className="w-4 h-4" /> {profile.instagram}
                  </a>
                )}
                {profile.tiktok && (
                  <a href={`https://tiktok.com/@${profile.tiktok.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-accent hover:border-accent/30 transition-colors"
                    data-testid="link-tiktok">
                    <SiTiktok className="w-4 h-4" /> {profile.tiktok}
                  </a>
                )}
                {profile.youtube && (
                  <a href={profile.youtube.startsWith('http') ? profile.youtube : `https://youtube.com/@${profile.youtube.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-red-400 hover:border-red-400/30 transition-colors"
                    data-testid="link-youtube">
                    <Youtube className="w-4 h-4" /> {profile.youtube}
                  </a>
                )}
                {profile.twitter && (
                  <a href={`https://x.com/${profile.twitter.replace('@', '')}`} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 px-4 py-2 rounded-lg bg-black/40 border border-white/10 font-mono text-sm text-gray-300 hover:text-blue-400 hover:border-blue-400/30 transition-colors"
                    data-testid="link-twitter">
                    <Twitter className="w-4 h-4" /> {profile.twitter}
                  </a>
                )}
              </div>
            </section>
          )}

          <section>
             <h2 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
              <span className="w-1 h-6 bg-accent rounded-full"></span>
              PORTFOLIO_MEDIA
            </h2>
            <div className="grid grid-cols-2 gap-4">
               {[1,2,3,4].map(i => (
                 <div key={i} className="aspect-video bg-white/5 rounded-lg border border-white/5 flex items-center justify-center text-xs font-mono text-gray-600">
                   [ENCRYPTED MEDIA]
                 </div>
               ))}
            </div>
          </section>

          {profile.showReviews && reviewData && reviewData.reviews.length > 0 && (
            <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-primary" />
                REVIEWS ({reviewData.reviews.length})
              </h2>
              <div className="space-y-4">
                {reviewData.reviews.map((r: Review) => (
                  <div key={r.id} className="p-4 rounded-lg border border-white/5 bg-black/20" data-testid={`review-${r.id}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {r.rating === 1 ? (
                        <ThumbsUp className="w-4 h-4 text-green-400" />
                      ) : (
                        <ThumbsDown className="w-4 h-4 text-red-400" />
                      )}
                      <span className="font-mono text-xs text-gray-500">
                        {new Date(r.createdAt!).toLocaleDateString()}
                      </span>
                    </div>
                    {r.comment && (
                      <p className="font-mono text-sm text-gray-300">{r.comment}</p>
                    )}
                  </div>
                ))}
              </div>
            </section>
          )}

          {isAuthenticated && profile.userId !== (user as any)?.claims?.sub && (
            <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-xl font-display font-bold text-white mb-4 flex items-center gap-2">
                <Send className="w-5 h-5 text-accent" />
                LEAVE FEEDBACK
              </h2>
              <div className="flex gap-3 mb-3">
                <button
                  type="button"
                  onClick={() => setReviewRating(1)}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg border font-mono text-sm transition-colors ${
                    reviewRating === 1
                      ? "border-green-400/50 bg-green-400/20 text-green-400"
                      : "border-white/10 bg-black/40 text-gray-400 hover:text-green-400"
                  }`}
                  data-testid="button-talent-like"
                >
                  <ThumbsUp className="w-4 h-4" /> Like
                </button>
                <button
                  type="button"
                  onClick={() => setReviewRating(-1)}
                  className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg border font-mono text-sm transition-colors ${
                    reviewRating === -1
                      ? "border-red-400/50 bg-red-400/20 text-red-400"
                      : "border-white/10 bg-black/40 text-gray-400 hover:text-red-400"
                  }`}
                  data-testid="button-talent-dislike"
                >
                  <ThumbsDown className="w-4 h-4" /> Dislike
                </button>
              </div>
              <Textarea
                placeholder="Optional comment..."
                className="bg-black/40 border-white/10 focus:border-primary font-mono resize-none min-h-[60px] mb-3"
                value={reviewComment}
                onChange={(e) => setReviewComment(e.target.value)}
                data-testid="input-talent-review-comment"
              />
              <CyberButton
                className="w-full"
                onClick={() => submitReview.mutate()}
                loading={submitReview.isPending}
                disabled={reviewRating === null}
                data-testid="button-submit-talent-review"
              >
                <Send className="w-4 h-4" /> SUBMIT REVIEW
              </CyberButton>
              {submitReview.isError && (
                <p className="font-mono text-xs text-red-400 mt-2 text-center">
                  {(submitReview.error as any)?.message || "Failed to submit review"}
                </p>
              )}
            </section>
          )}
        </div>

        {/* Sidebar Actions */}
        <div className="space-y-6">
          <div className="bg-gradient-to-b from-primary/10 to-transparent border border-primary/20 rounded-xl p-6">
             <h3 className="font-display font-bold text-primary mb-2 text-lg">HIRE PROTOCOL</h3>

             {!existingBooking ? (
               <>
                 <div className="space-y-2 mb-4 font-mono text-sm text-gray-400">
                   <div className="flex justify-between">
                     <span>Base Rate</span>
                     <span className="text-white">${pricing.basePay}</span>
                   </div>
                   <div className="flex justify-between">
                     <span>Platform Fee ({profile.tier})</span>
                     <span className="text-white">${pricing.tierFee.toFixed(2)}</span>
                   </div>
                   <div className="border-t border-white/10 pt-2 flex justify-between font-bold">
                     <span className="text-accent">Total</span>
                     <span className="text-white">${pricing.totalAmount.toFixed(2)}</span>
                   </div>
                 </div>

                 <ul className="text-sm font-mono text-gray-400 space-y-3 mb-6">
                   <li className="flex items-start gap-2">
                     <span className="text-primary mt-1">01.</span> Request booking
                   </li>
                   <li className="flex items-start gap-2">
                     <span className="text-primary mt-1">02.</span> Pay securely with ReUpSpots
                   </li>
                   <li className="flex items-start gap-2">
                     <span className="text-primary mt-1">03.</span> Worker gets paid instantly
                   </li>
                 </ul>

                 <CyberButton
                   className="w-full"
                   onClick={handleRequestBooking}
                   loading={createBooking.isPending}
                   data-testid="button-request-booking"
                 >
                   REQUEST BOOKING
                 </CyberButton>
                 <p className="text-xs text-center font-mono text-muted-foreground mt-2">
                   Costs 1 credit
                 </p>
               </>
             ) : (
               <div className="space-y-4">
                 <BookingStatusBadge status={existingBooking.status} />

                 {(existingBooking.status === "pending_payment" || existingBooking.status === "deposit_paid") && (
                   <BookingPaymentOptions
                     booking={existingBooking}
                     paymentInfo={paymentInfo}
                     onMarkPaid={handleMarkPaid}
                     markPaidLoading={markPaid.isPending}
                   />
                 )}

                 {existingBooking.status === "payment_submitted" && (
                   <p className="font-mono text-sm text-blue-400">
                     Payment submitted. Awaiting admin verification.
                   </p>
                 )}

                 {existingBooking.status === "confirmed" && (
                   <p className="font-mono text-sm text-green-400">
                     Booking confirmed. You're all set.
                   </p>
                 )}
               </div>
             )}
          </div>
        </div>
      </div>
    </div>
  );
}

function EscrowReserveButton({ booking }: { booking: Booking }) {
  const escrowReserve = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/escrow/reserve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ bookingId: booking.id }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Escrow reserve failed");
      }
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
  });

  return (
    <div className="space-y-2">
      <CyberButton
        variant="accent"
        className="w-full"
        onClick={() => escrowReserve.mutate()}
        loading={escrowReserve.isPending}
        data-testid="button-escrow-reserve"
      >
        <ShieldCheck className="w-4 h-4" />
        PAY & RESERVE (ESCROW)
      </CyberButton>
      <p className="font-mono text-[10px] text-gray-500 text-center leading-relaxed">
        Funds held securely until the gig is completed. Released to talent after confirmation.
      </p>
      {escrowReserve.isError && (
        <p className="font-mono text-xs text-red-400 text-center">
          {escrowReserve.error?.message}
        </p>
      )}
    </div>
  );
}

function EscrowStatusPanel({ booking }: { booking: Booking }) {
  const confirmEscrow = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/escrow/release", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ bookingId: booking.id }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Escrow confirm failed");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/mine"] });
    },
  });

  const cancelEscrow = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/escrow/cancel", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ bookingId: booking.id }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Escrow cancel failed");
      }
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/bookings/mine"] });
    },
  });

  return (
    <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-3 space-y-3">
      <div className="flex items-center gap-2">
        <ShieldCheck className="w-4 h-4 text-green-400" />
        <span className="font-mono text-xs text-green-400 font-bold uppercase tracking-wider">
          Escrow Active
        </span>
      </div>
      <p className="font-mono text-[10px] text-gray-400 leading-relaxed">
        Funds are held securely. Confirm after the gig is completed to release payment to talent, or cancel for a full refund.
      </p>
      <div className="flex gap-2">
        <CyberButton
          className="flex-1 text-xs"
          onClick={() => confirmEscrow.mutate()}
          loading={confirmEscrow.isPending}
          data-testid="button-escrow-confirm"
        >
          <CheckCircle className="w-3 h-3" />
          RELEASE PAYMENT
        </CyberButton>
        <CyberButton
          variant="accent"
          className="flex-1 text-xs"
          onClick={() => cancelEscrow.mutate()}
          loading={cancelEscrow.isPending}
          data-testid="button-escrow-cancel"
        >
          <XCircle className="w-3 h-3" />
          CANCEL & REFUND
        </CyberButton>
      </div>
      {(confirmEscrow.isError || cancelEscrow.isError) && (
        <p className="font-mono text-xs text-red-400 text-center">
          {confirmEscrow.error?.message || cancelEscrow.error?.message}
        </p>
      )}
    </div>
  );
}

function BookingPaymentOptions({
  booking,
  paymentInfo,
  onMarkPaid,
  markPaidLoading,
}: {
  booking: Booking;
  paymentInfo: any;
  onMarkPaid: (installment?: "deposit" | "final") => void;
  markPaidLoading: boolean;
}) {
  const [showExternal, setShowExternal] = useState(false);

  const isSplit = booking.paymentStructure === "split_50_50";
  const isDepositPhase = booking.status === "pending_payment";
  const isFinalPhase = booking.status === "deposit_paid";

  const currentInstallment: "deposit" | "final" | undefined = isSplit
    ? (isDepositPhase ? "deposit" : "final")
    : undefined;

  const displayAmountCents = isSplit
    ? (isDepositPhase ? (booking.depositAmount ?? 0) : (booking.finalAmount ?? 0))
    : booking.totalAmount;

  const stripeCheckout = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/stripe/connect/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          bookingId: booking.id,
          ...(currentInstallment ? { installment: currentInstallment } : {}),
        }),
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to start checkout");
      }
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
  });

  const totalDollars = (booking.totalAmount / 100).toFixed(2);
  const currentDollars = (displayAmountCents / 100).toFixed(2);
  const platformFeeCents = Math.round(displayAmountCents * PLATFORM_FEE_PERCENT / 100);
  const workerReceivesCents = displayAmountCents - platformFeeCents;

  return (
    <div className="space-y-4">
      {isSplit && (
        <div className="bg-cyan-500/10 border border-cyan-500/20 rounded-lg p-3 space-y-2">
          <p className="font-mono text-xs text-cyan-400 font-bold uppercase tracking-wider">
            {isDepositPhase ? "Step 1: Deposit Payment" : "Step 2: Final Payment"}
          </p>
          <div className="flex justify-between font-mono text-xs text-gray-400">
            <span>Full total</span>
            <span className="text-white">${totalDollars}</span>
          </div>
          <div className="flex justify-between font-mono text-xs">
            <span className={isDepositPhase ? "text-cyan-400" : "text-gray-500"}>
              Deposit (50%)
            </span>
            <span className={isDepositPhase ? "text-cyan-400 font-bold" : "text-green-400 line-through"}>
              ${((booking.depositAmount ?? 0) / 100).toFixed(2)}
              {isFinalPhase && " PAID"}
            </span>
          </div>
          <div className="flex justify-between font-mono text-xs">
            <span className={isFinalPhase ? "text-cyan-400" : "text-gray-500"}>
              Final (50%)
            </span>
            <span className={isFinalPhase ? "text-cyan-400 font-bold" : "text-gray-500"}>
              ${((booking.finalAmount ?? 0) / 100).toFixed(2)}
            </span>
          </div>
        </div>
      )}

      <div className="space-y-2 font-mono text-xs text-gray-500">
        <div className="flex justify-between">
          <span>{isSplit ? "Due now" : "Total"}</span>
          <span className="text-white">${currentDollars}</span>
        </div>
        <div className="flex justify-between">
          <span>Platform fee ({PLATFORM_FEE_PERCENT}%)</span>
          <span className="text-gray-400">-${(platformFeeCents / 100).toFixed(2)}</span>
        </div>
        <div className="flex justify-between">
          <span>Worker receives</span>
          <span className="text-green-400">${(workerReceivesCents / 100).toFixed(2)}</span>
        </div>
      </div>

      <CyberButton
        className="w-full"
        onClick={() => stripeCheckout.mutate()}
        loading={stripeCheckout.isPending}
        data-testid="button-pay-stripe"
      >
        <Shield className="w-4 h-4" />
        {isSplit
          ? (isDepositPhase ? "PAY DEPOSIT SECURELY" : "PAY FINAL SECURELY")
          : "PAY SECURELY WITH REUPSPOTS"}
      </CyberButton>

      {stripeCheckout.isError && (
        <p className="font-mono text-xs text-yellow-400 text-center">
          {stripeCheckout.error?.message || "Stripe checkout unavailable"}
        </p>
      )}

      {!isSplit && booking.escrowStatus === "none" && (
        <EscrowReserveButton booking={booking} />
      )}

      {booking.escrowStatus === "authorized" && (
        <EscrowStatusPanel booking={booking} />
      )}

      <div className="border-t border-white/10 pt-3">
        <button
          type="button"
          onClick={() => setShowExternal(!showExternal)}
          className="font-mono text-xs text-gray-500 hover:text-gray-400 transition-colors w-full text-center"
          data-testid="button-toggle-external"
        >
          {showExternal ? "Hide" : "Arrange payment independently"}
        </button>

        {showExternal && paymentInfo?.cashAppHandle && (
          <div className="space-y-3 mt-3">
            <p className="font-mono text-xs text-gray-500">
              Send {isSplit ? (isDepositPhase ? "deposit" : "final payment") : "payment"} directly:
            </p>
            <a
              href={`https://cash.app/$${paymentInfo.cashAppHandle.replace('$', '')}`}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 text-sm text-primary hover:text-primary/80 transition-colors font-mono"
              data-testid="link-cashapp-payment"
            >
              <DollarSign className="w-4 h-4" />
              ${paymentInfo.cashAppHandle.replace('$', '')}
              <ExternalLink className="w-3 h-3" />
            </a>
            <CyberButton
              variant="accent"
              className="w-full text-xs"
              onClick={() => onMarkPaid(currentInstallment)}
              loading={markPaidLoading}
              data-testid="button-mark-paid"
            >
              {isSplit
                ? (isDepositPhase ? "MARK DEPOSIT AS PAID" : "MARK FINAL AS PAID")
                : "MARK AS PAID"}
            </CyberButton>
          </div>
        )}
      </div>
    </div>
  );
}
