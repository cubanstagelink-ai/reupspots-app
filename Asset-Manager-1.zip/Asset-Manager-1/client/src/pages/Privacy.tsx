import { motion } from "framer-motion";
import { Eye, Database, Lock, UserCheck } from "lucide-react";

export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto space-y-8 py-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600" data-testid="text-privacy-title">
          PRIVACY POLICY
        </h1>
        <p className="font-mono text-accent text-lg">Last Updated: February 8, 2026</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-primary/20 rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-4 mb-4">
          <Database className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">1. INFORMATION WE COLLECT</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm">
          <ul className="list-disc list-inside space-y-2 pl-2">
            <li>Account and profile information</li>
            <li>Payment handles and Stripe Connect account details (not publicly displayed)</li>
            <li>Payment transaction data processed through Stripe (booking amounts, fees, payout records)</li>
            <li>Verification documents</li>
            <li>Device, log, and usage data (IP address, browser type)</li>
          </ul>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-accent/20 rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-4 mb-4">
          <Eye className="w-8 h-8 text-accent" />
          <h2 className="text-2xl font-bold font-display text-white">2. HOW WE USE INFORMATION</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm">
          <p className="mb-2">Information is used to:</p>
          <ul className="list-disc list-inside space-y-2 pl-2">
            <li>Operate and improve the platform</li>
            <li>Facilitate connections and booking transactions</li>
            <li>Process in-app payments via Stripe and calculate platform fees</li>
            <li>Process verification</li>
            <li>Manage credits and subscriptions</li>
            <li>Enforce platform rules</li>
            <li>Communicate important updates</li>
          </ul>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-4 mb-4">
          <Lock className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">3. DATA PROTECTION</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm">
          <ul className="list-disc list-inside space-y-2 pl-2">
            <li>Payment handles are never publicly displayed (unless voluntarily shared by users after booking)</li>
            <li>In-app payment processing is handled securely by Stripe; The Re-Up Spots does not store credit card numbers or bank account details</li>
            <li>Stripe Connect account data is shared with Stripe per their privacy policy and is used solely for payment processing</li>
            <li>ID documents are stored in secure, encrypted cloud storage</li>
            <li>Direct messages are private between participants</li>
            <li>Access to sensitive data is limited to authorized administrators</li>
          </ul>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-4">
        <div className="flex items-center gap-4 mb-4">
          <UserCheck className="w-8 h-8 text-accent" />
          <h2 className="text-2xl font-bold font-display text-white">4. YOUR RIGHTS</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-3">
          <p>Users may request access, correction, or deletion of their data, or opt out of non-essential communications by contacting:</p>
          <p className="text-primary">support@reupspots.com</p>
        </div>
      </motion.div>

      <div className="text-center py-8">
        <p className="font-mono text-xs text-muted-foreground">
          For questions about this Privacy Policy, contact support@reupspots.com | Legal: legal@reupspots.com | HR: humanresources@reupspots.com
        </p>
      </div>
    </div>
  );
}
