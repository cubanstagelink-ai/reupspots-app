import { useState } from "react";
import { motion } from "framer-motion";
import { MessageCircle, Send, Lightbulb, RefreshCw, AlertTriangle } from "lucide-react";
import { CyberButton } from "@/components/CyberButton";
import { useToast } from "@/hooks/use-toast";

const FEEDBACK_TYPES = [
  { value: "suggestion", label: "Suggestion", icon: Lightbulb, email: "support@reupspots.com", color: "text-cyan-400 border-cyan-400/30 bg-cyan-400/10" },
  { value: "update_request", label: "Update Request", icon: RefreshCw, email: "support@reupspots.com", color: "text-accent border-accent/30 bg-accent/10" },
  { value: "complaint", label: "Complaint", icon: AlertTriangle, email: "humanresources@reupspots.com", color: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10" },
  { value: "legal", label: "Legal Concern", icon: AlertTriangle, email: "legal@reupspots.com", color: "text-red-400 border-red-400/30 bg-red-400/10" },
] as const;

export default function Feedback() {
  const { toast } = useToast();
  const [selectedType, setSelectedType] = useState<string>("suggestion");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");

  const currentType = FEEDBACK_TYPES.find(t => t.value === selectedType) || FEEDBACK_TYPES[0];

  const handleSubmit = () => {
    if (!subject.trim() || !message.trim()) {
      toast({
        title: "Missing Info",
        description: "Please fill in both the subject and your message.",
        variant: "destructive",
      });
      return;
    }

    const subjectLine = `[${currentType.label}] ${subject}`;
    const body = message;
    const mailto = `mailto:${currentType.email}?subject=${encodeURIComponent(subjectLine)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailto;

    toast({
      title: "Opening Email",
      description: `Your ${currentType.label.toLowerCase()} is being directed to ${currentType.email}`,
    });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-8 py-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-5xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600">
          FEEDBACK HUB
        </h1>
        <p className="font-mono text-accent text-sm md:text-base" data-testid="text-feedback-subtitle">
          Got ideas, requests, or concerns? We want to hear from you.
        </p>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="cyber-card p-6 md:p-8 rounded-2xl border border-primary/20 space-y-6"
      >
        <div className="flex items-center gap-3 mb-2">
          <MessageCircle className="w-6 h-6 text-primary" />
          <h2 className="text-xl font-display font-bold text-white uppercase">What's on your mind?</h2>
        </div>

        <div>
          <label className="font-mono text-xs text-gray-500 uppercase tracking-wider mb-3 block">Type of Feedback</label>
          <div className="grid grid-cols-2 gap-3">
            {FEEDBACK_TYPES.map(type => {
              const Icon = type.icon;
              const isSelected = selectedType === type.value;
              return (
                <button
                  key={type.value}
                  type="button"
                  onClick={() => setSelectedType(type.value)}
                  className={`flex items-center gap-2 px-4 py-3 rounded-lg border font-mono text-xs font-bold uppercase tracking-wider transition-all cursor-pointer ${
                    isSelected ? type.color : "border-white/10 bg-white/5 text-gray-500 hover:border-white/20"
                  }`}
                  data-testid={`button-feedback-type-${type.value}`}
                >
                  <Icon className="w-4 h-4" />
                  {type.label}
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-lg p-3">
          <p className="font-mono text-xs text-gray-400">
            This will be sent to: <span className="text-primary">{currentType.email}</span>
          </p>
        </div>

        <div>
          <label className="font-mono text-xs text-gray-500 uppercase tracking-wider mb-2 block">Subject</label>
          <input
            type="text"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Brief summary of your feedback..."
            className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 font-mono text-sm text-white placeholder:text-gray-600 focus:border-primary focus:outline-none transition-colors"
            data-testid="input-feedback-subject"
          />
        </div>

        <div>
          <label className="font-mono text-xs text-gray-500 uppercase tracking-wider mb-2 block">Message</label>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Tell us the details..."
            rows={6}
            className="w-full bg-black/40 border border-white/10 rounded-lg px-4 py-3 font-mono text-sm text-white placeholder:text-gray-600 focus:border-primary focus:outline-none transition-colors resize-none"
            data-testid="input-feedback-message"
          />
        </div>

        <CyberButton
          className="w-full"
          onClick={handleSubmit}
          data-testid="button-submit-feedback"
        >
          <Send className="w-4 h-4" /> SEND FEEDBACK
        </CyberButton>

        <p className="font-mono text-xs text-gray-600 text-center">
          This will open your email app with your message pre-filled and ready to send.
        </p>
      </motion.div>
    </div>
  );
}
