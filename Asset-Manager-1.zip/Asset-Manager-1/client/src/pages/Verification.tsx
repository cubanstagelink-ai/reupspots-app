import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { CyberButton } from "@/components/CyberButton";
import { useUpload } from "@/hooks/use-upload";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { ShieldCheck, Upload, Clock, CheckCircle, XCircle, AlertTriangle } from "lucide-react";

export default function Verification() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const queryClient = useQueryClient();
  const [idImagePath, setIdImagePath] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);

  const { uploadFile } = useUpload({
    onSuccess: (response) => {
      setIdImagePath(response.objectPath);
    },
  });

  const { data: verifications, isLoading } = useQuery<any[]>({
    queryKey: ["/api/verification"],
    enabled: isAuthenticated,
  });

  const [ageConfirmed, setAgeConfirmed] = useState(false);

  const submitVerification = useMutation({
    mutationFn: async () => {
      if (!idImagePath) throw new Error("Please upload your ID first");
      if (!ageConfirmed) throw new Error("You must confirm you are 18 or older");
      const res = await apiRequest("POST", "/api/verification", {
        idImagePath,
        ageConfirmed,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/verification"] });
      setIdImagePath(null);
    },
  });

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    await uploadFile(file);
    setUploading(false);
  };

  if (authLoading) return <div className="p-20 text-center font-mono animate-pulse">AUTHENTICATING...</div>;

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
        <ShieldCheck className="w-16 h-16 text-primary" />
        <h1 className="text-3xl font-display font-bold">ID VERIFICATION</h1>
        <p className="font-mono text-muted-foreground">You must be logged in to verify your identity.</p>
        <a href="/api/login"><CyberButton>Connect Node</CyberButton></a>
      </div>
    );
  }

  const latestVerification = verifications?.[0];
  const isPending = latestVerification?.status === "pending";
  const isApproved = latestVerification?.status === "approved";

  const statusConfig: Record<string, { icon: any; color: string; label: string }> = {
    pending: { icon: Clock, color: "text-yellow-400", label: "PENDING REVIEW" },
    approved: { icon: CheckCircle, color: "text-green-400", label: "VERIFIED" },
    rejected: { icon: XCircle, color: "text-red-400", label: "REJECTED" },
  };

  return (
    <div className="max-w-2xl mx-auto py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600" data-testid="text-verification-title">
          ID VERIFICATION
        </h1>
        <p className="font-mono text-accent text-lg">Verify your identity to build trust on the network.</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="bg-black/40 border border-destructive/20 rounded-2xl p-6">
        <div className="flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-destructive mt-0.5 shrink-0" />
          <div className="font-mono text-sm text-gray-400 space-y-2">
            <p className="text-white font-bold">IMPORTANT DISCLAIMER</p>
            <p>ID verification confirms basic identity only. It does not constitute a background check, criminal history review, or endorsement of character, safety, or reliability. Users interact at their own risk. See our Terms of Service for full details.</p>
          </div>
        </div>
      </motion.div>

      {latestVerification && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}
          className="bg-black/40 border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-display font-bold text-white mb-4">VERIFICATION STATUS</h2>
          {verifications?.map((v: any) => {
            const sc = statusConfig[v.status] || statusConfig.pending;
            const StatusIcon = sc.icon;
            return (
              <div key={v.id} className="flex items-center justify-between bg-black/40 rounded-lg p-4 border border-white/5 mb-3 flex-wrap gap-2" data-testid={`card-verification-${v.id}`}>
                <div className="flex items-center gap-3">
                  <StatusIcon className={`w-5 h-5 ${sc.color}`} />
                  <div>
                    <p className={`font-mono text-sm font-bold ${sc.color}`}>{sc.label}</p>
                    <p className="font-mono text-xs text-muted-foreground">
                      Submitted {new Date(v.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
                {v.adminNotes && (
                  <p className="font-mono text-xs text-muted-foreground w-full mt-2">
                    Admin Notes: {v.adminNotes}
                  </p>
                )}
              </div>
            );
          })}
        </motion.div>
      )}

      {!isPending && !isApproved && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}
          className="bg-black/40 border border-primary/20 rounded-2xl p-8 space-y-6">
          <h2 className="text-xl font-display font-bold text-white">SUBMIT VERIFICATION</h2>

          <div className="space-y-4">
            <div className="space-y-2">
              <p className="font-mono text-sm text-accent">Upload Government-Issued ID</p>
              <p className="font-mono text-xs text-muted-foreground">Driver's license, state ID, or passport. Must show your name and photo clearly.</p>
              <label className="flex items-center gap-3 cursor-pointer bg-black/40 border border-white/10 rounded-lg p-4 hover:border-primary/30 transition-colors">
                <Upload className="w-5 h-5 text-primary" />
                <span className="font-mono text-sm text-gray-300">
                  {uploading ? "Uploading..." : idImagePath ? "ID Uploaded" : "Choose File"}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  data-testid="input-id-upload"
                />
              </label>
              {idImagePath && (
                <p className="font-mono text-xs text-green-400 flex items-center gap-1">
                  <CheckCircle className="w-3 h-3" /> File uploaded successfully
                </p>
              )}
            </div>

            <label className="flex items-start gap-3 cursor-pointer bg-black/40 border border-red-500/20 rounded-lg p-4" data-testid="label-age-confirm">
              <input
                type="checkbox"
                checked={ageConfirmed}
                onChange={(e) => setAgeConfirmed(e.target.checked)}
                className="mt-1 accent-primary w-4 h-4 cursor-pointer"
                data-testid="checkbox-age-confirm"
              />
              <div>
                <p className="font-mono text-sm text-white font-bold">I confirm I am 18 years of age or older</p>
                <p className="font-mono text-xs text-muted-foreground mt-1">
                  This enables access to the full marketplace including age-restricted content categories. You must truthfully confirm your age as required by law.
                </p>
              </div>
            </label>

            <CyberButton
              className="w-full"
              onClick={() => submitVerification.mutate()}
              loading={submitVerification.isPending}
              disabled={!idImagePath || uploading || !ageConfirmed}
              data-testid="button-submit-verification"
            >
              SUBMIT FOR REVIEW
            </CyberButton>
          </div>
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}
        className="bg-black/20 border border-white/5 rounded-xl p-6">
        <h3 className="font-display font-bold text-white mb-3">HOW IT WORKS</h3>
        <ul className="font-mono text-sm text-gray-400 space-y-3">
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">01.</span> Upload a clear photo of your government-issued ID</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">02.</span> Our admin team reviews your submission</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">03.</span> Once approved, a verified badge appears on your profile</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">04.</span> Verified users get higher visibility in search results</li>
        </ul>
      </motion.div>
    </div>
  );
}
