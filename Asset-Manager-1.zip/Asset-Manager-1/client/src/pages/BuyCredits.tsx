import { useAuth } from "@/hooks/use-auth";
import { CyberButton } from "@/components/CyberButton";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { Coins, Zap, Star, Crown } from "lucide-react";
import { useLocation } from "wouter";

interface CreditPackage {
  product_id: string;
  product_name: string;
  product_description: string;
  product_metadata: { type: string; credits: string };
  price_id: string;
  unit_amount: number;
  currency: string;
}

export default function BuyCredits() {
  const { isAuthenticated, isLoading: authLoading } = useAuth();
  const [location] = useLocation();
  const cancelled = location.includes("cancelled=true");

  const { data: packages, isLoading } = useQuery<CreditPackage[]>({
    queryKey: ["/api/credit-packages"],
  });

  const checkout = useMutation({
    mutationFn: async ({ priceId, credits }: { priceId: string; credits: number }) => {
      const res = await apiRequest("POST", "/api/stripe/checkout", { priceId, credits });
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      }
      return data;
    },
  });

  if (authLoading) return <div className="p-20 text-center font-mono animate-pulse">AUTHENTICATING...</div>;

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
        <Coins className="w-16 h-16 text-primary" />
        <h1 className="text-3xl font-display font-bold">BUY CREDITS</h1>
        <p className="font-mono text-muted-foreground">You must be logged in to purchase credits.</p>
        <a href="/api/login"><CyberButton>Connect Node</CyberButton></a>
      </div>
    );
  }

  const icons = [Zap, Star, Crown];

  return (
    <div className="max-w-3xl mx-auto py-8 space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600" data-testid="text-buy-credits-title">
          BUY CREDITS
        </h1>
        <p className="font-mono text-accent text-lg">Power up your Re-Up Spots account with credits.</p>
      </div>

      {cancelled && (
        <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 text-center">
          <p className="font-mono text-sm text-destructive">Purchase cancelled. No charges were made.</p>
        </motion.div>
      )}

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        className="bg-black/20 border border-white/5 rounded-xl p-6">
        <h3 className="font-display font-bold text-white mb-3">WHAT ARE CREDITS?</h3>
        <ul className="font-mono text-sm text-gray-400 space-y-2">
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">*</span> Post opportunities to find talent (1-5 credits)</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">*</span> Apply to gigs and events (1 credit)</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">*</span> Boost your listings for more visibility (2-8 credits)</li>
          <li className="flex items-start gap-2"><span className="text-primary mt-0.5">*</span> Submit ID verification (10 credits)</li>
        </ul>
      </motion.div>

      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map(i => (
            <div key={i} className="bg-black/40 border border-white/10 rounded-2xl p-8 animate-pulse h-48" />
          ))}
        </div>
      )}

      {!isLoading && packages && packages.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {packages.map((pkg, i) => {
            const credits = parseInt(pkg.product_metadata?.credits || "0");
            const priceDisplay = (pkg.unit_amount / 100).toFixed(2);
            const perCredit = (pkg.unit_amount / 100 / credits).toFixed(2);
            const Icon = icons[i] || Zap;
            const isPopular = i === 1;

            return (
              <motion.div
                key={pkg.product_id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className={`relative bg-black/40 border rounded-2xl p-8 flex flex-col items-center text-center space-y-4 ${
                  isPopular ? 'border-primary/40 ring-1 ring-primary/20' : 'border-white/10'
                }`}
                data-testid={`card-credit-package-${credits}`}
              >
                {isPopular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full font-mono">
                    POPULAR
                  </span>
                )}

                <Icon className={`w-10 h-10 ${isPopular ? 'text-primary' : 'text-accent'}`} />

                <div>
                  <h3 className="text-2xl font-display font-bold text-white">{credits}</h3>
                  <p className="font-mono text-xs text-muted-foreground uppercase">Credits</p>
                </div>

                <p className="text-3xl font-display font-bold text-white">${priceDisplay}</p>
                <p className="font-mono text-xs text-muted-foreground">${perCredit} per credit</p>

                <CyberButton
                  className="w-full"
                  variant={isPopular ? "primary" : "accent"}
                  onClick={() => checkout.mutate({ priceId: pkg.price_id, credits })}
                  loading={checkout.isPending}
                  data-testid={`button-buy-${credits}`}
                >
                  BUY NOW
                </CyberButton>
              </motion.div>
            );
          })}
        </div>
      )}

      {!isLoading && (!packages || packages.length === 0) && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="bg-black/40 border border-white/10 rounded-2xl p-12 text-center">
          <Coins className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="font-mono text-muted-foreground">Credit packages are being set up. Check back soon.</p>
        </motion.div>
      )}

      <div className="text-center">
        <p className="font-mono text-xs text-muted-foreground">
          Payments are processed securely via Stripe. Credits are non-refundable once consumed.
        </p>
      </div>
    </div>
  );
}
