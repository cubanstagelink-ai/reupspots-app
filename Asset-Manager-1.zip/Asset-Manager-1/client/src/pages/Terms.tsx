import { motion } from "framer-motion";
import { ShieldCheck, FileText, AlertTriangle, Scale, Gavel } from "lucide-react";

export default function Terms() {
  return (
    <div className="max-w-3xl mx-auto space-y-8 py-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600" data-testid="text-terms-title">
          TERMS OF SERVICE
        </h1>
        <p className="font-mono text-accent text-lg">Last Updated: February 8, 2026 | Version 1.2</p>
      </div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-primary/20 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <Scale className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">1. ACCEPTANCE OF TERMS</h2>
        </div>
        <p className="font-mono text-gray-400 leading-relaxed text-sm">
          By accessing or using The Re-Up Spots ("the Platform"), you agree to be bound by these Terms of Service. If you do not agree to these terms, you may not use the Platform. The Re-Up Spots reserves the right to update these Terms at any time. Continued use of the Platform after changes constitutes acceptance of the new terms.
        </p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <FileText className="w-8 h-8 text-accent" />
          <h2 className="text-2xl font-bold font-display text-white">2. PLATFORM DESCRIPTION</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-3">
          <p>The Re-Up Spots is a marketplace that connects performers, creatives, and talent with promoters, venues, brands, and individuals.</p>
          <p>The Re-Up Spots:</p>
          <ul className="list-disc list-inside space-y-1 pl-2">
            <li>Offers secure in-app payments via Stripe with a 6% platform fee on each booking transaction</li>
            <li>Also supports external payment arrangements (e.g., Cash App) at 0% commission between parties</li>
            <li>Does not act as an employer, agent, broker, or representative</li>
            <li>Does not guarantee bookings, payments, or outcomes</li>
          </ul>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-destructive/20 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <AlertTriangle className="w-8 h-8 text-destructive" />
          <h2 className="text-2xl font-bold font-display text-white">3. DISCLAIMER OF LIABILITY</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-4">
          <p>
            <strong className="text-white">3.1 No Guarantee of Payment:</strong> All payment disputes are solely between the parties involved. The Re-Up Spots is not responsible for unpaid, delayed, or disputed payments.
          </p>
          <p>
            <strong className="text-white">3.2 No Background Check Guarantee:</strong> ID verification is a limited identity check only and does not constitute a background check, criminal record search, or endorsement of character or safety.
          </p>
          <p>
            <strong className="text-white">3.3 No Employer-Employee Relationship:</strong> All users operate as independent parties. The Re-Up Spots is not responsible for taxes, insurance, benefits, or worker's compensation.
          </p>
          <p>
            <strong className="text-white">3.4 Assumption of Risk:</strong> Users acknowledge that participation in opportunities arranged through The Re-Up Spots involves inherent risks, including physical harm, property damage, financial loss, or emotional distress, and assume all such risks voluntarily.
          </p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <ShieldCheck className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">4. USER RESPONSIBILITIES</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-4">
          <p>
            <strong className="text-white">4.1 Accurate Information:</strong> Users must provide truthful and accurate information. Misrepresentation may result in suspension or termination.
          </p>
          <p>
            <strong className="text-white">4.2 Legal Compliance:</strong> Users are solely responsible for complying with all applicable local, state, and federal laws.
          </p>
          <p>
            <strong className="text-white">4.3 Professional Conduct:</strong> Harassment, discrimination, threats, fraud, scams, or illegal activity will result in immediate removal.
          </p>
          <p>
            <strong className="text-white">4.4 Age Requirement:</strong> Users must be 18 years or older to use The Re-Up Spots.
          </p>
          <p>
            <strong className="text-white">4.5 Platform Abuse:</strong> Abuse of visibility systems, spam, manipulation, or repeated circumvention of platform rules may result in suspension or termination.
          </p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-accent/20 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <FileText className="w-8 h-8 text-accent" />
          <h2 className="text-2xl font-bold font-display text-white">5. CREDITS & PLATFORM FEES</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-4">
          <p>
            <strong className="text-white">5.1 In-App Payments:</strong> The Re-Up Spots offers secure in-app payments processed by Stripe. A 6% platform fee is applied to each in-app booking transaction. This fee is deducted from the total before funds are disbursed to the worker via their connected Stripe account. Workers must connect a Stripe Express account to receive in-app payments.
          </p>
          <p>
            <strong className="text-white">5.2 External Payments:</strong> Users may arrange payments independently outside the platform (e.g., via Cash App). External payments carry 0% commission. The Re-Up Spots is not responsible for disputes, non-payment, or fraud involving external payment arrangements.
          </p>
          <p>
            <strong className="text-white">5.3 Credits:</strong> Credits are used solely for platform services (posting, boosting, applying, verification) and are non-refundable once consumed. Credits are not a form of payment to other users.
          </p>
          <p>
            <strong className="text-white">5.4 Refund Policy:</strong> Platform fees on in-app Stripe payments are non-refundable. Refund requests for booking disputes must be resolved directly between parties. The Re-Up Spots does not mediate payment disputes.
          </p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-red-500/20 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <AlertTriangle className="w-8 h-8 text-red-400" />
          <h2 className="text-2xl font-bold font-display text-white">6. ADULT / NSFW CONTENT</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-4">
          <p>
            <strong className="text-white">6.1 Age Verification Required:</strong> Access to adult/NSFW content categories requires identity verification and age confirmation (18+). Users who falsify their age bear sole legal responsibility for doing so.
          </p>
          <p>
            <strong className="text-white">6.2 Content Responsibility:</strong> The Re-Up Spots does not create, endorse, or curate adult content. All listings in the Adult/NSFW category are created by users and do not represent the views or endorsement of the Platform. Users are solely responsible for the legality and nature of content they post or engage with.
          </p>
          <p>
            <strong className="text-white">6.3 Prohibited Content:</strong> Content involving minors, non-consensual activity, trafficking, or any illegal activity under federal or state law is strictly prohibited and will be immediately removed. Violations will be reported to law enforcement.
          </p>
          <p>
            <strong className="text-white">6.4 No Solicitation of Illegal Services:</strong> The Platform is a neutral marketplace for legal services only. Users may not use the Platform to solicit, offer, or arrange illegal activity of any kind.
          </p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <FileText className="w-8 h-8 text-accent" />
          <h2 className="text-2xl font-bold font-display text-white">7. COMPANIONSHIP & PERSONAL SERVICES</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-4">
          <p>
            <strong className="text-white">7.1 Nature of Service:</strong> "Companionship" listings on The Re-Up Spots refer to legal, social companionship services such as event attendance, social outings, dining companions, and similar lawful activities. No sexual services are implied, offered, or permitted through this category.
          </p>
          <p>
            <strong className="text-white">7.2 User Responsibility:</strong> Both parties to a companionship arrangement are solely responsible for defining the scope of the engagement. The Platform does not oversee, manage, or control any interactions between users. Users engage at their own risk.
          </p>
          <p>
            <strong className="text-white">7.3 Safety:</strong> The Re-Up Spots strongly recommends meeting in public places and informing a trusted person of your plans. The Platform is not responsible for the conduct, safety, or actions of any user.
          </p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-primary/20 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <ShieldCheck className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">8. SECTION 230 SAFE HARBOR</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-4">
          <p>
            The Re-Up Spots operates as an interactive computer service under Section 230 of the Communications Decency Act (47 U.S.C. 230). The Platform is not the publisher or speaker of any user-generated content posted on the Platform.
          </p>
          <p>
            <strong className="text-white">8.1 Neutral Marketplace:</strong> The Re-Up Spots serves solely as a neutral venue where users may post and discover opportunities. The Platform does not create, edit, endorse, or exercise editorial control over user-generated listings, profiles, messages, or other content.
          </p>
          <p>
            <strong className="text-white">8.2 Good Faith Moderation:</strong> The Platform may, in good faith, remove or restrict access to content that it considers objectionable or in violation of these Terms. Such moderation actions do not constitute the Platform as a publisher or speaker of any remaining user content.
          </p>
          <p>
            <strong className="text-white">8.3 No Liability for User Content:</strong> The Re-Up Spots shall not be liable for any content posted by users, including but not limited to defamatory, misleading, harmful, or illegal content. All responsibility for user content rests solely with the user who created it.
          </p>
        </div>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-6">
        <h2 className="text-2xl font-bold font-display text-white">9. INDEMNIFICATION</h2>
        <p className="font-mono text-gray-400 leading-relaxed text-sm">
          Users agree to indemnify and hold harmless The Re-Up Spots from any claims, damages, or disputes arising from their use of the platform, including claims related to user-generated content, interactions between users, and any activity arranged through the Platform.
        </p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-white/10 rounded-2xl p-8 space-y-6">
        <h2 className="text-2xl font-bold font-display text-white">10. LIMITATION OF LIABILITY</h2>
        <p className="font-mono text-gray-400 leading-relaxed text-sm">
          The Re-Up Spots shall not be liable for indirect, incidental, or consequential damages. Total liability is limited to the amount paid to The Re-Up Spots in platform fees during the preceding 12 months.
        </p>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
        className="bg-black/40 border border-primary/20 rounded-2xl p-8 space-y-6">
        <div className="flex items-center gap-4 mb-4">
          <Gavel className="w-8 h-8 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">11. DISPUTE RESOLUTION & GOVERNING LAW</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed text-sm space-y-3">
          <p>Any disputes arising from these Terms shall be resolved through binding arbitration, except where prohibited by law.</p>
          <p>These Terms are governed by the laws of the State of Illinois, United States.</p>
        </div>
      </motion.div>

      <div className="text-center py-8 space-y-2">
        <p className="font-mono text-xs text-muted-foreground">
          By using The Re-Up Spots, you acknowledge that you have read, understood, and agree to these Terms of Service.
        </p>
        <p className="font-mono text-xs text-muted-foreground">
          Contact: support@reupspots.com | Legal: legal@reupspots.com | HR: humanresources@reupspots.com
        </p>
      </div>
    </div>
  );
}
