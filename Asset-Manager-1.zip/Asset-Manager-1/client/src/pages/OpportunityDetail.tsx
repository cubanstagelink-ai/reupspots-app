import { useRoute, Link, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { useApplyToPost, useMyApplications } from "@/hooks/use-stage-link";
import { CyberButton } from "@/components/CyberButton";
import { Button } from "@/components/ui/button";
import { isBoostActive } from "@shared/pricing";
import { useState } from "react";
import {
  MapPin, Calendar, DollarSign, User, Flame, ArrowLeft,
  Phone, Navigation, FileText, Clock, CheckCircle, XCircle, ShieldAlert, ThumbsUp, ThumbsDown, Lock, RefreshCw, Share2, Check, CalendarHeart
} from "lucide-react";
import type { Application, Post } from "@shared/schema";

export default function OpportunityDetail() {
  const [, params] = useRoute("/opportunity/:id");
  const [, navigate] = useLocation();
  const postId = params?.id ? parseInt(params.id) : null;
  const { user, isAuthenticated } = useAuth();
  const applyToPost = useApplyToPost();
  const { data: myApplications } = useMyApplications();
  const [linkCopied, setLinkCopied] = useState(false);

  const { data: post, isLoading, error } = useQuery<Post>({
    queryKey: ["/api/posts", postId],
    queryFn: async () => {
      const res = await fetch(`/api/posts/${postId}`);
      if (!res.ok) throw new Error("Failed to load opportunity");
      return res.json();
    },
    enabled: !!postId,
  });

  const { data: posterData } = useQuery<any>({
    queryKey: ["/api/poster-profile", post?.userId],
    queryFn: async () => {
      const res = await fetch(`/api/poster-profile/${post?.userId}`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: !!post?.userId,
  });

  if (isLoading) return <div className="text-center py-20 font-mono text-accent animate-pulse" data-testid="text-loading">Loading opportunity...</div>;
  if (!post || error) return <div className="text-center py-20 font-mono text-destructive" data-testid="text-not-found">Opportunity not found.</div>;

  const application = myApplications?.find((a: Application) => a.postId === post.id);
  const appStatus = application?.status || null;
  const boosted = isBoostActive(post.boostExpiresAt);

  const copyOpportunityLink = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setLinkCopied(true);
      setTimeout(() => setLinkCopied(false), 2000);
    } catch {
    }
  };

  const handleApply = () => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    applyToPost.mutate(post.id);
  };

  const statusConfig: Record<string, { label: string; className: string; icon: any }> = {
    pending: { label: "AWAITING RESPONSE", className: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10", icon: Clock },
    accepted: { label: "ACCEPTED", className: "text-green-400 border-green-400/30 bg-green-400/10", icon: CheckCircle },
    rejected: { label: "NOT SELECTED", className: "text-red-400 border-red-400/30 bg-red-400/10", icon: XCircle },
  };

  const sc = appStatus ? statusConfig[appStatus] : null;

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <button
        type="button"
        onClick={() => navigate("/")}
        className="flex items-center gap-2 font-mono text-sm text-muted-foreground hover:text-white transition-colors"
        data-testid="button-back-feed"
      >
        <ArrowLeft className="w-4 h-4" /> Back to Feed
      </button>

      <div className="relative rounded-2xl overflow-hidden bg-black/40 border border-white/10">
        <div className={`h-32 ${boosted ? "bg-gradient-to-r from-primary/30 to-accent/30" : "bg-gradient-to-r from-purple-900/50 to-blue-900/50"}`}>
          <div className="absolute inset-0 opacity-20 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-white via-transparent to-transparent"></div>
        </div>

        <div className="px-8 pb-8 -mt-8 relative z-10">
          <div className="flex flex-wrap gap-2 mb-4">
            {post.postType === "event" && (
              <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider bg-cyan-500/10 text-cyan-300 rounded border border-cyan-500/20 flex items-center gap-1" data-testid="badge-event-type">
                <CalendarHeart className="w-3 h-3" /> EVENT
              </span>
            )}
            <span className={`px-3 py-1 text-xs font-bold uppercase tracking-wider rounded border ${
              post.nsfw
                ? "bg-red-500/10 text-red-400 border-red-500/20"
                : post.postType === "event"
                  ? "bg-purple-500/10 text-purple-300 border-purple-500/20"
                  : "bg-primary/10 text-primary border-primary/20"
            }`}>
              {post.category}
            </span>
            {post.postType !== "event" && (
              <span className="px-3 py-1 text-xs font-mono text-muted-foreground bg-white/5 rounded border border-white/10">
                {post.tier}
              </span>
            )}
            {boosted && (
              <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider bg-accent/10 text-accent rounded border border-accent/20 flex items-center gap-1">
                <Flame className="w-3 h-3" /> BOOSTED
              </span>
            )}
            {post.recurring && (
              <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider bg-cyan-500/10 text-cyan-400 rounded border border-cyan-500/20 flex items-center gap-1" data-testid="badge-recurring">
                <RefreshCw className="w-3 h-3" /> RECURRING
              </span>
            )}
            {post.nsfw && (
              <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider bg-red-500/10 text-red-400 rounded border border-red-500/20 flex items-center gap-1">
                <ShieldAlert className="w-3 h-3" /> 18+
              </span>
            )}
            {post.paymentStructure === "split_50_50" && (
              <span className="px-3 py-1 text-xs font-mono text-cyan-400 bg-cyan-500/10 rounded border border-cyan-500/20">
                50/50 Split
              </span>
            )}
          </div>

          <div className="flex items-start justify-between gap-4 flex-wrap">
            <h1 className="text-3xl md:text-4xl font-black text-white font-display uppercase mb-2" data-testid="text-post-title">
              {post.title}
            </h1>
            <Button
              variant="ghost"
              size="sm"
              onClick={copyOpportunityLink}
              className="font-mono text-xs shrink-0"
              data-testid="button-share-opportunity"
            >
              {linkCopied ? (
                <><Check className="w-3 h-3 text-green-400" /><span className="text-green-400">Copied</span></>
              ) : (
                <><Share2 className="w-3 h-3" /><span>Share</span></>
              )}
            </Button>
          </div>

          <div className="flex items-center gap-4 font-mono text-sm text-gray-400">
            {post.postType === "event" ? (
              <div className="flex items-center gap-2">
                <CalendarHeart className="w-5 h-5 text-cyan-400" />
                <span className="text-cyan-300 font-bold text-2xl" data-testid="text-post-free">FREE EVENT</span>
              </div>
            ) : (
              <>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-accent" />
                  <span className="text-white font-bold text-2xl" data-testid="text-post-pay">${post.pay}</span>
                </div>
                {post.paymentStructure === "split_50_50" && (
                  <span className="text-xs text-cyan-400">
                    (${Math.ceil(post.pay / 2)} deposit + ${post.pay - Math.ceil(post.pay / 2)} final)
                  </span>
                )}
                {post.pay === 0 && (
                  <p className="font-mono text-[10px] text-yellow-500/70 mt-1" data-testid="text-zero-pay-disclaimer">
                    * $0 listed — no payment through this platform. Any compensation must be arranged directly between you and the host.
                  </p>
                )}
              </>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          {post.description && (
            <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h2 className="text-lg font-display font-bold text-white mb-3 flex items-center gap-2">
                <FileText className="w-5 h-5 text-primary" />
                DESCRIPTION
              </h2>
              <p className="font-mono text-gray-300 leading-relaxed whitespace-pre-line" data-testid="text-description">
                {post.description}
              </p>
            </section>
          )}

          <section className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
            <h2 className="text-lg font-display font-bold text-white mb-4 flex items-center gap-2">
              <MapPin className="w-5 h-5 text-accent" />
              DETAILS
            </h2>
            <div className="space-y-4 font-mono text-sm">
              <div className="flex items-start gap-3">
                <User className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                <div>
                  <span className="text-gray-500 text-xs uppercase tracking-wider">Hosted by</span>
                  <Link
                    href={`/poster/${post.userId}`}
                    className="block text-white hover:text-primary transition-colors"
                    data-testid="link-poster-profile"
                  >
                    {post.promoterName}
                    {posterData?.reviewSummary && (
                      <span className="text-xs text-gray-500 ml-2">
                        <ThumbsUp className="w-3 h-3 inline text-green-400" /> {posterData.reviewSummary.likes}
                        <ThumbsDown className="w-3 h-3 inline text-red-400 ml-2" /> {posterData.reviewSummary.dislikes}
                      </span>
                    )}
                  </Link>
                </div>
              </div>

              {post.venue && (
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-gray-500 text-xs uppercase tracking-wider">Venue</span>
                    <p className="text-white" data-testid="text-venue">{post.venue}</p>
                  </div>
                </div>
              )}

              {post.address && (
                <div className="flex items-start gap-3">
                  <Navigation className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-gray-500 text-xs uppercase tracking-wider">Area</span>
                    <p className="text-white" data-testid="text-address">{post.address}</p>
                  </div>
                </div>
              )}

              {(post as any).fullAddress ? (
                <div className="flex items-start gap-3">
                  <MapPin className="w-4 h-4 text-green-400 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-green-400 text-xs uppercase tracking-wider flex items-center gap-1">
                      <CheckCircle className="w-3 h-3" /> Exact Address (You're accepted)
                    </span>
                    <p className="text-white font-bold" data-testid="text-full-address">{(post as any).fullAddress}</p>
                  </div>
                </div>
              ) : appStatus !== "accepted" && (
                <div className="flex items-start gap-3">
                  <Lock className="w-4 h-4 text-yellow-400/60 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-yellow-400/60 text-xs uppercase tracking-wider">Exact Address</span>
                    <p className="text-muted-foreground text-xs" data-testid="text-address-locked">Provided after your application is accepted</p>
                  </div>
                </div>
              )}

              {post.date && (
                <div className="flex items-start gap-3">
                  <Calendar className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-gray-500 text-xs uppercase tracking-wider">Date & Time</span>
                    <p className="text-white" data-testid="text-date">{post.date}</p>
                  </div>
                </div>
              )}

              {post.contactInfo && (
                <div className="flex items-start gap-3">
                  <Phone className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-gray-500 text-xs uppercase tracking-wider">Contact</span>
                    <p className="text-white" data-testid="text-contact">{post.contactInfo}</p>
                  </div>
                </div>
              )}

              {post.directions && (
                <div className="flex items-start gap-3">
                  <Navigation className="w-4 h-4 text-gray-500 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-gray-500 text-xs uppercase tracking-wider">Directions</span>
                    <p className="text-gray-300" data-testid="text-directions">{post.directions}</p>
                  </div>
                </div>
              )}
            </div>
          </section>
        </div>

        <div className="space-y-6">
          {post.postType === "event" ? (
            <div className="bg-gradient-to-b from-cyan-500/10 to-transparent border border-cyan-500/20 rounded-xl p-6">
              <h3 className="font-display font-bold text-cyan-300 mb-4 text-lg">FREE EVENT</h3>
              <p className="font-mono text-xs text-gray-400 mb-4">
                The host is not paying talent through this platform for this event. Check the host's page for paid gig opportunities.
              </p>
              <CyberButton
                className="w-full"
                onClick={() => navigate(`/poster/${post.userId}`)}
                data-testid="button-view-host-page"
              >
                VIEW HOST PAGE
              </CyberButton>
              <p className="font-mono text-[10px] text-gray-600 mt-4 leading-relaxed border-t border-cyan-500/10 pt-3" data-testid="text-event-disclaimer">
                * Some events (battle raps, open mics, showcases, etc.) may have a door fee or entry cost for participants — see description for details. The $0 listing means no payment is being arranged through The Re-Up Spots. Any payment between you and the host must be handled directly between both parties off-platform. The Re-Up Spots is not responsible for any off-platform payment arrangements.
              </p>
            </div>
          ) : (
            <div className="bg-gradient-to-b from-primary/10 to-transparent border border-primary/20 rounded-xl p-6">
              <h3 className="font-display font-bold text-primary mb-4 text-lg">APPLY</h3>

              {appStatus && sc ? (
                <div className={`flex items-center justify-center gap-2 px-4 py-3 rounded-lg border font-mono text-sm font-bold uppercase tracking-wider ${sc.className}`}
                  data-testid="badge-application-status">
                  <sc.icon className="w-4 h-4" />
                  {sc.label}
                </div>
              ) : (
                <>
                  <p className="font-mono text-xs text-gray-400 mb-4">
                    Apply to let the host know you're interested. Costs 1 credit.
                  </p>
                  <CyberButton
                    className="w-full"
                    onClick={handleApply}
                    loading={applyToPost.isPending}
                    data-testid="button-apply-now"
                  >
                    APPLY NOW
                  </CyberButton>
                </>
              )}
            </div>
          )}

          {posterData && (
            <div className="bg-black/20 border border-white/5 rounded-xl p-6 backdrop-blur-sm">
              <h3 className="font-display font-bold text-white mb-3 text-sm">ABOUT THE HOST</h3>
              <Link
                href={`/poster/${post.userId}`}
                className="block font-mono text-sm text-primary hover:text-primary/80 transition-colors mb-2"
                data-testid="link-poster-name"
              >
                {posterData.posterName}
              </Link>
              <div className="flex items-center gap-4 font-mono text-xs text-gray-400">
                <span className="flex items-center gap-1">
                  <ThumbsUp className="w-3 h-3 text-green-400" /> {posterData.reviewSummary?.likes || 0}
                </span>
                <span className="flex items-center gap-1">
                  <ThumbsDown className="w-3 h-3 text-red-400" /> {posterData.reviewSummary?.dislikes || 0}
                </span>
                <span>{posterData.posts?.length || 0} posts</span>
              </div>
              {posterData.profile?.bio && (
                <p className="font-mono text-xs text-gray-500 mt-2 line-clamp-3">{posterData.profile.bio}</p>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
