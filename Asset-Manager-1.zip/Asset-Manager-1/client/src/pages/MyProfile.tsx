import { useState, useEffect } from "react";
import { useMyProfile, useCreateProfile, useCredits, useMyBookings, useCancelBooking } from "@/hooks/use-stage-link";
import { useAuth } from "@/hooks/use-auth";
import { CyberButton } from "@/components/CyberButton";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CATEGORIES, TIERS } from "@shared/schema";
import { getPlanDetails } from "@shared/subscriptions";
import { motion } from "framer-motion";
import { Coins, Crown, Clock, CheckCircle, XCircle, Instagram, Youtube, Twitter, Upload, X, ImagePlus, ShoppingCart, CreditCard, ExternalLink, DollarSign, TrendingUp, Eye, EyeOff, Shield, Users, Mic, Building2, FileText, Share2, Trash2, Link2, Copy, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { SiTiktok } from "react-icons/si";
import { useUpload } from "@/hooks/use-upload";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function MyProfile() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const { data: myData, isLoading: dataLoading } = useMyProfile();
  const { data: creditData } = useCredits();
  const { data: myBookings } = useMyBookings();
  const cancelBooking = useCancelBooking();
  const createProfile = useCreateProfile();

  const { toast } = useToast();
  const [mediaUrls, setMediaUrls] = useState<string[]>([]);
  const [mediaUploading, setMediaUploading] = useState(false);
  const [role, setRole] = useState<"talent" | "host" | "both">("talent");

  const { uploadFile } = useUpload({
    onSuccess: (response) => {
      setMediaUrls(prev => [...prev, response.objectPath]);
    },
  });

  const [formData, setFormData] = useState({
    displayName: "",
    category: CATEGORIES[0],
    tier: TIERS[0],
    baseRate: 50,
    bio: "",
    cashAppHandle: "",
    venmoHandle: "",
    zelleHandle: "",
    paypalHandle: "",
    instagram: "",
    tiktok: "",
    youtube: "",
    twitter: "",
    profileSlug: "",
    visibility: "public" as "public" | "category_only",
    hostDisplayName: "",
    defaultVenue: "",
    hostBio: "",
  });

  useEffect(() => {
    if (myData?.profile) {
      const p = myData.profile;
      const isHost = !!p.isPoster;
      const isTalent = !!p.isWorker;
      if (isHost && isTalent) setRole("both");
      else if (isHost) setRole("host");
      else setRole("talent");

      setFormData({
        displayName: p.displayName,
        category: p.category as any,
        tier: p.tier as any,
        baseRate: p.baseRate,
        bio: p.bio || "",
        cashAppHandle: p.cashAppHandle || "",
        venmoHandle: p.venmoHandle || "",
        zelleHandle: p.zelleHandle || "",
        paypalHandle: p.paypalHandle || "",
        instagram: p.instagram || "",
        tiktok: p.tiktok || "",
        youtube: p.youtube || "",
        twitter: p.twitter || "",
        profileSlug: p.profileSlug,
        visibility: (p.visibility as "public" | "category_only") || "public",
        hostDisplayName: p.hostDisplayName || "",
        defaultVenue: p.defaultVenue || "",
        hostBio: p.hostBio || "",
      });
      if (p.media && Array.isArray(p.media)) {
        setMediaUrls(p.media);
      }
    } else if (user) {
      const slug = `${user.firstName}-${user.lastName || ''}-${Math.floor(Math.random()*1000)}`.toLowerCase().replace(/\s+/g, '-');
      setFormData(prev => ({
        ...prev,
        displayName: `${user.firstName} ${user.lastName || ''}`.trim(),
        profileSlug: slug
      }));
    }
  }, [myData, user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    const isTalent = role === "talent" || role === "both";
    const isHost = role === "host" || role === "both";

    await createProfile.mutateAsync({
      userId: user.id,
      displayName: formData.displayName,
      category: formData.category,
      tier: formData.tier,
      baseRate: Number(formData.baseRate),
      bio: formData.bio,
      cashAppHandle: formData.cashAppHandle,
      venmoHandle: formData.venmoHandle,
      zelleHandle: formData.zelleHandle,
      paypalHandle: formData.paypalHandle,
      instagram: formData.instagram,
      tiktok: formData.tiktok,
      youtube: formData.youtube,
      twitter: formData.twitter,
      profileSlug: formData.profileSlug,
      media: mediaUrls,
      verified: myData?.profile?.verified || false,
      isWorker: isTalent,
      isPoster: isHost,
      plan: myData?.profile?.plan || "free",
      visibility: formData.visibility,
      hostDisplayName: isHost ? formData.hostDisplayName : null,
      defaultVenue: isHost ? formData.defaultVenue : null,
      hostBio: isHost ? formData.hostBio : null,
    });
  };

  const showTalentFields = role === "talent" || role === "both";
  const showHostFields = role === "host" || role === "both";

  if (authLoading || dataLoading) return <div className="p-20 text-center font-mono animate-pulse">AUTHENTICATING...</div>;

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
        <h1 className="text-3xl font-display font-bold">ACCESS DENIED</h1>
        <p className="font-mono text-muted-foreground">You must connect to the network to view this terminal.</p>
        <a href="/api/login">
          <CyberButton>Connect Node</CyberButton>
        </a>
      </div>
    );
  }

  const plan = myData?.profile?.plan || "free";
  const planDetails = getPlanDetails(plan);

  const statusConfig: Record<string, { icon: any; color: string }> = {
    pending_payment: { icon: Clock, color: "text-yellow-400" },
    payment_submitted: { icon: Clock, color: "text-blue-400" },
    confirmed: { icon: CheckCircle, color: "text-green-400" },
    cancelled: { icon: XCircle, color: "text-red-400" },
  };

  return (
    <div className="max-w-2xl mx-auto py-8 space-y-8">
      {/* Credits & Plan Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-black/40 border border-accent/20 p-6 rounded-2xl backdrop-blur-md"
      >
        <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
          <h2 className="text-xl font-display font-bold text-accent flex items-center gap-2">
            <Coins className="w-5 h-5" />
            CREDITS & PLAN
          </h2>
          <span className="px-3 py-1 text-xs font-bold uppercase tracking-wider bg-primary/10 text-primary rounded border border-primary/20 flex items-center gap-1" data-testid="badge-plan">
            <Crown className="w-3 h-3" /> {planDetails.name}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-4 font-mono text-sm">
          <div className="bg-black/40 rounded-lg p-4 border border-white/5">
            <p className="text-muted-foreground text-xs uppercase mb-1">Balance</p>
            <p className="text-2xl font-bold text-white" data-testid="text-credit-balance">{creditData?.balance ?? 0}</p>
          </div>
          <div className="bg-black/40 rounded-lg p-4 border border-white/5">
            <p className="text-muted-foreground text-xs uppercase mb-1">Boosts</p>
            <p className="text-sm text-white">{planDetails.boostsEnabled ? "Enabled" : "Upgrade to Pro"}</p>
          </div>
        </div>

        <div className="mt-4">
          <Link href="/buy-credits">
            <CyberButton variant="accent" className="w-full text-sm" data-testid="button-buy-credits">
              <ShoppingCart className="w-4 h-4" /> BUY MORE CREDITS
            </CyberButton>
          </Link>
        </div>
      </motion.div>

      {/* Stripe Connect - Get Paid Section */}
      {myData?.profile && (
        <StripeConnectSection />
      )}

      {/* Bookings */}
      {myBookings && myBookings.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="bg-black/40 border border-white/10 p-6 rounded-2xl backdrop-blur-md"
        >
          <h2 className="text-xl font-display font-bold text-white mb-4">MY BOOKINGS</h2>
          <div className="space-y-3">
            {myBookings.map((booking: any) => {
              const sc = statusConfig[booking.status] || statusConfig.pending_payment;
              const StatusIcon = sc.icon;
              return (
                <div key={booking.id} className="flex items-center justify-between bg-black/40 rounded-lg p-4 border border-white/5 flex-wrap gap-2" data-testid={`card-booking-${booking.id}`}>
                  <div className="flex items-center gap-3">
                    <StatusIcon className={`w-4 h-4 ${sc.color}`} />
                    <div>
                      <p className="font-mono text-sm text-white">
                        {booking.workerSlug || `Post #${booking.postId}`}
                      </p>
                      <p className="font-mono text-xs text-muted-foreground">
                        ${(booking.totalAmount / 100).toFixed(2)} - {booking.status.replace("_", " ").toUpperCase()}
                      </p>
                    </div>
                  </div>
                  {(booking.status === "pending_payment" || booking.status === "payment_submitted") && (
                    <CyberButton
                      variant="accent"
                      className="text-xs"
                      onClick={() => cancelBooking.mutate(booking.id)}
                      loading={cancelBooking.isPending}
                      data-testid={`button-cancel-booking-${booking.id}`}
                    >
                      CANCEL
                    </CyberButton>
                  )}
                </div>
              );
            })}
          </div>
        </motion.div>
      )}

      {/* Profile Form */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="bg-black/40 border border-white/10 p-8 rounded-2xl backdrop-blur-md"
      >
        <h1 className="text-3xl font-display font-bold text-white mb-6 border-b border-white/10 pb-4">
          PROFILE CONFIGURATION
        </h1>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-3">
            <Label className="font-mono text-accent text-sm">I AM A...</Label>
            <div className="grid grid-cols-3 gap-3">
              <Button
                type="button"
                variant={role === "talent" ? "default" : "ghost"}
                onClick={() => setRole("talent")}
                className={`gap-2 font-mono text-xs ${role === "talent" ? "" : "opacity-60"}`}
                data-testid="button-role-talent"
              >
                <Mic className="w-4 h-4" />
                Talent
              </Button>
              <Button
                type="button"
                variant={role === "host" ? "default" : "ghost"}
                onClick={() => setRole("host")}
                className={`gap-2 font-mono text-xs ${role === "host" ? "" : "opacity-60"}`}
                data-testid="button-role-host"
              >
                <Building2 className="w-4 h-4" />
                Host
              </Button>
              <Button
                type="button"
                variant={role === "both" ? "default" : "ghost"}
                onClick={() => setRole("both")}
                className={`gap-2 font-mono text-xs ${role === "both" ? "" : "opacity-60"}`}
                data-testid="button-role-both"
              >
                <Users className="w-4 h-4" />
                Both
              </Button>
            </div>
            <p className="text-xs text-muted-foreground font-mono">
              {role === "talent" && "You perform at events and gigs. Your profile will appear in the talent directory."}
              {role === "host" && "You organize events and book talent. You can post opportunities for performers."}
              {role === "both" && "You both perform and host events. Access all features for talent and hosts."}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label className="font-mono text-accent">Display Name</Label>
              <Input
                value={formData.displayName}
                onChange={e => setFormData({...formData, displayName: e.target.value})}
                className="bg-black/40 border-white/10 font-mono"
                data-testid="input-display-name"
              />
            </div>

            <div className="space-y-2">
              <Label className="font-mono text-accent">Unique Slug ID</Label>
              <Input
                value={formData.profileSlug}
                onChange={e => setFormData({...formData, profileSlug: e.target.value})}
                className="bg-black/40 border-white/10 font-mono"
                data-testid="input-slug"
              />
            </div>

            {showTalentFields && (
              <div className="space-y-2">
                <Label className="font-mono text-accent">Specialization</Label>
                <Select
                  value={formData.category}
                  onValueChange={(val: any) => setFormData({...formData, category: val})}
                >
                  <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    {CATEGORIES.map(cat => (
                      <SelectItem key={cat} value={cat} className="font-mono">{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {showTalentFields && (
              <div className="space-y-2 md:col-span-2">
                <Label className="font-mono text-accent">Profile Visibility</Label>
                <div className="flex gap-2">
                  <Button
                    type="button"
                    variant={formData.visibility === "public" ? "default" : "ghost"}
                    onClick={() => setFormData({...formData, visibility: "public"})}
                    className={`flex-1 gap-2 font-mono text-xs ${formData.visibility === "public" ? "" : "opacity-60"}`}
                    data-testid="button-visibility-public"
                  >
                    <Eye className="w-4 h-4" />
                    Visible to Everyone
                  </Button>
                  <Button
                    type="button"
                    variant={formData.visibility === "category_only" ? "default" : "ghost"}
                    onClick={() => setFormData({...formData, visibility: "category_only"})}
                    className={`flex-1 gap-2 font-mono text-xs ${formData.visibility === "category_only" ? "" : "opacity-60"}`}
                    data-testid="button-visibility-category"
                  >
                    <EyeOff className="w-4 h-4" />
                    Only Matching Hosts
                  </Button>
                </div>
                <p className="text-xs text-muted-foreground font-mono mt-1">
                  {formData.visibility === "category_only"
                    ? `Only hosts looking for "${formData.category}" talent can see your profile.`
                    : "Your profile is visible to everyone browsing the talent network."}
                </p>
              </div>
            )}

            {showTalentFields && (
              <div className="space-y-2">
                <Label className="font-mono text-accent">Clearance Tier</Label>
                <Select
                  value={formData.tier}
                  onValueChange={(val: any) => setFormData({...formData, tier: val})}
                >
                  <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-tier">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-background border-white/10">
                    {TIERS.map(tier => (
                      <SelectItem key={tier} value={tier} className="font-mono">{tier}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            {showTalentFields && (
              <div className="space-y-2">
                <Label className="font-mono text-accent">Base Rate ($)</Label>
                <Input
                  type="number"
                  value={formData.baseRate}
                  onChange={e => setFormData({...formData, baseRate: Number(e.target.value)})}
                  className="bg-black/40 border-white/10 font-mono"
                  data-testid="input-base-rate"
                />
              </div>
            )}
          </div>

          {showTalentFields && (
            <div className="space-y-2">
              <Label className="font-mono text-accent">Bio Data</Label>
              <Textarea
                value={formData.bio}
                onChange={e => setFormData({...formData, bio: e.target.value})}
                className="bg-black/40 border-white/10 font-mono h-32"
                placeholder="Enter your experience protocols..."
                data-testid="input-bio"
              />
            </div>
          )}

          {showHostFields && (
            <div className="pt-4 border-t border-white/10">
              <h3 className="text-lg font-display font-bold text-primary mb-4 flex items-center gap-2">
                <Building2 className="w-5 h-5" /> HOST DETAILS
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-mono text-accent">Promoter / Host Name</Label>
                  <Input
                    value={formData.hostDisplayName}
                    onChange={e => setFormData({...formData, hostDisplayName: e.target.value})}
                    className="bg-black/40 border-white/10 font-mono"
                    placeholder="Your brand or promoter name"
                    data-testid="input-host-display-name"
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-mono text-accent">Default Venue</Label>
                  <Input
                    value={formData.defaultVenue}
                    onChange={e => setFormData({...formData, defaultVenue: e.target.value})}
                    className="bg-black/40 border-white/10 font-mono"
                    placeholder="Your main venue or location"
                    data-testid="input-default-venue"
                  />
                </div>
              </div>
              <div className="space-y-2 mt-4">
                <Label className="font-mono text-accent">Host Bio</Label>
                <Textarea
                  value={formData.hostBio}
                  onChange={e => setFormData({...formData, hostBio: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono h-24"
                  placeholder="Tell talent about your events and what you're looking for..."
                  data-testid="input-host-bio"
                />
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-white/10">
            <h3 className="text-lg font-display font-bold text-primary mb-4">PAYMENT METHODS</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="font-mono text-accent">Cash App ($)</Label>
                <Input
                  value={formData.cashAppHandle}
                  onChange={e => setFormData({...formData, cashAppHandle: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="$cashtag"
                  data-testid="input-cashapp"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-accent">Venmo</Label>
                <Input
                  value={formData.venmoHandle}
                  onChange={e => setFormData({...formData, venmoHandle: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="@username"
                  data-testid="input-venmo"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-accent">Zelle</Label>
                <Input
                  value={formData.zelleHandle}
                  onChange={e => setFormData({...formData, zelleHandle: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="Email or phone"
                  data-testid="input-zelle"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-accent">PayPal</Label>
                <Input
                  value={formData.paypalHandle}
                  onChange={e => setFormData({...formData, paypalHandle: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="Email or @username"
                  data-testid="input-paypal"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10">
            <h3 className="text-lg font-display font-bold text-accent mb-4">SOCIAL MEDIA</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="font-mono text-accent flex items-center gap-2"><Instagram className="w-4 h-4" /> Instagram</Label>
                <Input
                  value={formData.instagram}
                  onChange={e => setFormData({...formData, instagram: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="@username"
                  data-testid="input-instagram"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-accent flex items-center gap-2"><SiTiktok className="w-4 h-4" /> TikTok</Label>
                <Input
                  value={formData.tiktok}
                  onChange={e => setFormData({...formData, tiktok: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="@username"
                  data-testid="input-tiktok"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-accent flex items-center gap-2"><Youtube className="w-4 h-4" /> YouTube</Label>
                <Input
                  value={formData.youtube}
                  onChange={e => setFormData({...formData, youtube: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="Channel URL or @handle"
                  data-testid="input-youtube"
                />
              </div>
              <div className="space-y-2">
                <Label className="font-mono text-accent flex items-center gap-2"><Twitter className="w-4 h-4" /> X / Twitter</Label>
                <Input
                  value={formData.twitter}
                  onChange={e => setFormData({...formData, twitter: e.target.value})}
                  className="bg-black/40 border-white/10 font-mono"
                  placeholder="@username"
                  data-testid="input-twitter"
                />
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-white/10">
            <h3 className="text-lg font-display font-bold text-primary mb-4 flex items-center gap-2">
              <ImagePlus className="w-5 h-5" /> PORTFOLIO MEDIA
            </h3>
            <p className="font-mono text-xs text-muted-foreground mb-4">Upload photos and images for your portfolio. These will be displayed on your public profile.</p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
              {mediaUrls.map((url, i) => (
                <div key={i} className="relative group aspect-square bg-black/40 rounded-lg border border-white/10 overflow-hidden">
                  <img
                    src={`/api/objects/${url}`}
                    alt={`Portfolio ${i + 1}`}
                    className="w-full h-full object-cover"
                    data-testid={`img-media-${i}`}
                  />
                  <button
                    type="button"
                    onClick={() => setMediaUrls(prev => prev.filter((_, idx) => idx !== i))}
                    className="absolute top-2 right-2 bg-black/70 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                    data-testid={`button-remove-media-${i}`}
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}

              {mediaUrls.length < 6 && (
                <label className="aspect-square bg-black/40 rounded-lg border border-dashed border-white/20 flex flex-col items-center justify-center gap-2 cursor-pointer hover:border-primary/40 transition-colors">
                  <Upload className="w-6 h-6 text-muted-foreground" />
                  <span className="font-mono text-xs text-muted-foreground">
                    {mediaUploading ? "Uploading..." : "Add Photo"}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      setMediaUploading(true);
                      await uploadFile(file);
                      setMediaUploading(false);
                    }}
                    disabled={mediaUploading}
                    data-testid="input-media-upload"
                  />
                </label>
              )}
            </div>
          </div>

          <div className="pt-6 border-t border-white/10 flex justify-end">
            <CyberButton
              type="submit"
              loading={createProfile.isPending}
              className="w-full md:w-auto"
              data-testid="button-save-profile"
            >
              SAVE CONFIGURATION
            </CyberButton>
          </div>
        </form>
      </motion.div>

      <DocumentVault />
    </div>
  );
}

function StripeConnectSection() {
  const { data: stripeStatus, isLoading } = useQuery<{ connected: boolean; status: string }>({
    queryKey: ["/api/stripe/connect/status"],
  });

  const { data: earnings } = useQuery<{ gross: number; fees: number; net: number; count: number; feePercent: number }>({
    queryKey: ["/api/stripe/connect/earnings"],
    enabled: stripeStatus?.status === "active",
  });

  const createAccount = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/stripe/connect/create-account", {
        method: "POST",
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.message || "Failed to create Stripe account");
      }
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
  });

  const getAccountLink = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/stripe/connect/account-link", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to get account link");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) window.location.href = data.url;
    },
  });

  const getDashboardLink = useMutation({
    mutationFn: async () => {
      const res = await fetch("/api/stripe/connect/dashboard-link", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to get dashboard link");
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) window.open(data.url, "_blank");
    },
  });

  if (isLoading) return null;

  const status = stripeStatus?.status || "not_connected";

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.05 }}
      className="bg-black/40 border border-primary/20 p-6 rounded-2xl backdrop-blur-md"
    >
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h2 className="text-xl font-display font-bold text-primary flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          GET PAID WITH STRIPE
        </h2>
        <span
          className={`px-3 py-1 text-xs font-bold uppercase tracking-wider rounded border flex items-center gap-1 ${
            status === "active"
              ? "bg-green-400/10 text-green-400 border-green-400/20"
              : status === "pending"
              ? "bg-yellow-400/10 text-yellow-400 border-yellow-400/20"
              : "bg-gray-400/10 text-gray-400 border-gray-400/20"
          }`}
          data-testid="badge-stripe-status"
        >
          {status === "active" ? "Connected" : status === "pending" ? "Pending" : "Not Connected"}
        </span>
      </div>

      {status === "not_connected" && (
        <div className="space-y-3">
          <p className="font-mono text-sm text-gray-400">
            Connect your Stripe account to receive in-app payments directly from promoters. ReUpSpots handles everything — you just get paid.
          </p>
          <CyberButton
            onClick={() => createAccount.mutate()}
            loading={createAccount.isPending}
            className="w-full text-sm"
            data-testid="button-connect-stripe"
          >
            <CreditCard className="w-4 h-4" /> CONNECT STRIPE TO GET PAID
          </CyberButton>
        </div>
      )}

      {status === "pending" && (
        <div className="space-y-3">
          <p className="font-mono text-sm text-yellow-400/80">
            Your Stripe account setup is incomplete. Finish onboarding to start receiving payments.
          </p>
          <CyberButton
            variant="accent"
            onClick={() => getAccountLink.mutate()}
            loading={getAccountLink.isPending}
            className="w-full text-sm"
            data-testid="button-finish-stripe"
          >
            <ExternalLink className="w-4 h-4" /> FINISH STRIPE SETUP
          </CyberButton>
        </div>
      )}

      {status === "active" && (
        <div className="space-y-4">
          {earnings && (
            <div className="grid grid-cols-3 gap-3 font-mono text-sm">
              <div className="bg-black/40 rounded-lg p-3 border border-white/5 text-center">
                <p className="text-muted-foreground text-xs uppercase mb-1">Gross</p>
                <p className="text-lg font-bold text-white" data-testid="text-earnings-gross">${(earnings.gross / 100).toFixed(2)}</p>
              </div>
              <div className="bg-black/40 rounded-lg p-3 border border-white/5 text-center">
                <p className="text-muted-foreground text-xs uppercase mb-1">Fees ({earnings.feePercent}%)</p>
                <p className="text-lg font-bold text-red-400" data-testid="text-earnings-fees">-${(earnings.fees / 100).toFixed(2)}</p>
              </div>
              <div className="bg-black/40 rounded-lg p-3 border border-white/5 text-center">
                <p className="text-muted-foreground text-xs uppercase mb-1">Net</p>
                <p className="text-lg font-bold text-green-400" data-testid="text-earnings-net">${(earnings.net / 100).toFixed(2)}</p>
              </div>
            </div>
          )}
          <div className="flex gap-2 flex-wrap">
            <CyberButton
              variant="accent"
              onClick={() => getDashboardLink.mutate()}
              loading={getDashboardLink.isPending}
              className="text-sm flex-1"
              data-testid="button-stripe-dashboard"
            >
              <TrendingUp className="w-4 h-4" /> STRIPE DASHBOARD
            </CyberButton>
          </div>
          <p className="font-mono text-xs text-green-400/60">
            Stripe account active. You'll receive payments directly when promoters book you.
          </p>
        </div>
      )}
    </motion.div>
  );
}

const DOC_TYPES = [
  { value: "license", label: "License" },
  { value: "certification", label: "Certification" },
  { value: "insurance", label: "Insurance" },
  { value: "id_document", label: "ID Document" },
  { value: "resume", label: "Resume" },
  { value: "portfolio", label: "Portfolio" },
  { value: "other", label: "Other" },
] as const;

function DocumentVault() {
  const { toast } = useToast();
  const [showUpload, setShowUpload] = useState(false);
  const [docName, setDocName] = useState("");
  const [docType, setDocType] = useState("license");
  const [docDescription, setDocDescription] = useState("");
  const [uploading, setUploading] = useState(false);
  const [copiedId, setCopiedId] = useState<number | null>(null);

  const { data: documents, isLoading } = useQuery<any[]>({
    queryKey: ["/api/documents"],
  });

  const { uploadFile } = useUpload({
    onSuccess: async (response) => {
      const res = await apiRequest("POST", "/api/documents", {
        name: docName,
        docType,
        filePath: response.objectPath,
        description: docDescription || null,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      setShowUpload(false);
      setDocName("");
      setDocType("license");
      setDocDescription("");
      setUploading(false);
      toast({ title: "Document uploaded", description: "Your document has been securely stored." });
    },
  });

  const deleteDoc = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/documents/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/documents"] });
      toast({ title: "Document removed" });
    },
  });

  const shareDoc = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest("POST", `/api/documents/${id}/share`);
      return res.json();
    },
    onSuccess: (data, id) => {
      navigator.clipboard.writeText(data.shareUrl);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 3000);
      toast({
        title: "Share link copied",
        description: "Link expires in 7 days. Paste it to share with a host.",
      });
    },
  });

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.3 }}
      className="bg-black/40 border border-white/10 p-6 rounded-2xl backdrop-blur-md"
    >
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <h2 className="text-xl font-display font-bold text-accent flex items-center gap-2">
          <Lock className="w-5 h-5" />
          DOCUMENT VAULT
        </h2>
        <Button
          size="sm"
          variant={showUpload ? "ghost" : "default"}
          onClick={() => setShowUpload(!showUpload)}
          className="gap-2 font-mono text-xs"
          data-testid="button-toggle-upload"
        >
          {showUpload ? <X className="w-4 h-4" /> : <Upload className="w-4 h-4" />}
          {showUpload ? "Cancel" : "Upload"}
        </Button>
      </div>

      <p className="font-mono text-xs text-muted-foreground mb-4">
        Store licenses, certifications, and credentials privately. Generate temporary share links to send to hosts on demand.
      </p>

      {showUpload && (
        <div className="bg-black/40 border border-accent/20 rounded-lg p-4 mb-4 space-y-3">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="font-mono text-accent text-xs">Document Name</Label>
              <Input
                value={docName}
                onChange={e => setDocName(e.target.value)}
                className="bg-black/40 border-white/10 font-mono"
                placeholder="e.g. Business License 2025"
                data-testid="input-doc-name"
              />
            </div>
            <div className="space-y-1">
              <Label className="font-mono text-accent text-xs">Type</Label>
              <Select value={docType} onValueChange={setDocType}>
                <SelectTrigger className="bg-black/40 border-white/10 font-mono" data-testid="select-doc-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-background border-white/10">
                  {DOC_TYPES.map(dt => (
                    <SelectItem key={dt.value} value={dt.value} className="font-mono">{dt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-1">
            <Label className="font-mono text-accent text-xs">Description (optional)</Label>
            <Input
              value={docDescription}
              onChange={e => setDocDescription(e.target.value)}
              className="bg-black/40 border-white/10 font-mono"
              placeholder="Any notes about this document..."
              data-testid="input-doc-description"
            />
          </div>
          <label className="flex items-center justify-center gap-2 bg-black/40 rounded-lg border border-dashed border-white/20 p-4 cursor-pointer hover:border-primary/40 transition-colors">
            <FileText className="w-5 h-5 text-muted-foreground" />
            <span className="font-mono text-sm text-muted-foreground">
              {uploading ? "Uploading..." : "Choose File"}
            </span>
            <input
              type="file"
              accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
              className="hidden"
              disabled={uploading || !docName}
              onChange={async (e) => {
                const file = e.target.files?.[0];
                if (!file || !docName) return;
                setUploading(true);
                await uploadFile(file);
              }}
              data-testid="input-doc-file"
            />
          </label>
          {!docName && (
            <p className="font-mono text-xs text-yellow-400/70">Enter a document name before uploading.</p>
          )}
        </div>
      )}

      {isLoading && (
        <div className="text-center py-4 font-mono text-sm text-muted-foreground animate-pulse">
          Loading documents...
        </div>
      )}

      {!isLoading && documents && documents.length === 0 && !showUpload && (
        <div className="text-center py-6 border border-dashed border-white/10 rounded-lg">
          <Shield className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
          <p className="font-mono text-sm text-muted-foreground">No documents yet</p>
          <p className="font-mono text-xs text-muted-foreground mt-1">Upload licenses, certifications, or credentials to your private vault.</p>
        </div>
      )}

      {documents && documents.length > 0 && (
        <div className="space-y-2">
          {documents.map((doc: any) => (
            <div
              key={doc.id}
              className="flex items-center justify-between bg-black/40 rounded-lg p-3 border border-white/5 flex-wrap gap-2"
              data-testid={`card-document-${doc.id}`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <FileText className="w-4 h-4 text-accent shrink-0" />
                <div className="min-w-0">
                  <p className="font-mono text-sm text-white truncate" data-testid={`text-doc-name-${doc.id}`}>{doc.name}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono text-xs text-muted-foreground uppercase">{doc.docType.replace("_", " ")}</span>
                    {doc.description && (
                      <span className="font-mono text-xs text-muted-foreground truncate max-w-[200px]">{doc.description}</span>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => shareDoc.mutate(doc.id)}
                  disabled={shareDoc.isPending}
                  data-testid={`button-share-doc-${doc.id}`}
                >
                  {copiedId === doc.id ? <Copy className="w-4 h-4 text-green-400" /> : <Share2 className="w-4 h-4" />}
                </Button>
                <Button
                  size="icon"
                  variant="ghost"
                  onClick={() => deleteDoc.mutate(doc.id)}
                  disabled={deleteDoc.isPending}
                  data-testid={`button-delete-doc-${doc.id}`}
                >
                  <Trash2 className="w-4 h-4 text-red-400" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
