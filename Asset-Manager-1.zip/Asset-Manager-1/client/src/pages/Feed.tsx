import { useState } from "react";
import { usePosts, useMyApplications, useApplyToPost } from "@/hooks/use-stage-link";
import { useAuth } from "@/hooks/use-auth";
import { CATEGORIES, ALL_CATEGORIES, BOOST_FEES, EVENT_CATEGORIES } from "@shared/schema";
import { CreatePostModal } from "@/components/CreatePostModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, MapPin, Calendar, DollarSign, User, Flame, Clock, CheckCircle, XCircle, ShieldAlert, Eye, EyeOff, ArrowRight, RefreshCw, Share2, Check, CalendarHeart, Briefcase } from "lucide-react";
import { motion } from "framer-motion";
import { isBoostActive } from "@shared/pricing";
import { useQuery } from "@tanstack/react-query";
import type { Application } from "@shared/schema";
import { useLocation } from "wouter";

export default function Feed() {
  const { isAuthenticated } = useAuth();
  const [filters, setFilters] = useState({
    search: "",
    category: "All",
    sortBy: "Newest" as "Newest" | "Pay",
    includeNsfw: false,
    postType: "all" as "all" | "gig" | "event",
  });

  const { data: posts, isLoading, error } = usePosts(filters);
  const { data: myApplications } = useMyApplications();
  const applyToPost = useApplyToPost();

  const [, navigate] = useLocation();
  const [copiedPostId, setCopiedPostId] = useState<number | null>(null);

  const copyOpportunityLink = async (postId: number, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/opportunity/${postId}`);
      setCopiedPostId(postId);
      setTimeout(() => setCopiedPostId(null), 2000);
    } catch {
    }
  };

  const { data: verifications } = useQuery<any[]>({
    queryKey: ["/api/verification"],
    enabled: isAuthenticated,
  });
  const isAgeVerified = verifications?.some((v: any) => v.status === "approved" && v.ageConfirmed);

  const getApplicationStatus = (postId: number): Application | undefined => {
    return myApplications?.find((a: Application) => a.postId === postId);
  };

  const handleApply = (postId: number) => {
    if (!isAuthenticated) {
      window.location.href = "/api/login";
      return;
    }
    applyToPost.mutate(postId);
  };

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 }
  };

  const statusConfig: Record<string, { label: string; className: string; icon: any }> = {
    pending: { label: "AWAITING RESPONSE", className: "text-yellow-400 border-yellow-400/30 bg-yellow-400/10", icon: Clock },
    accepted: { label: "ACCEPTED", className: "text-green-400 border-green-400/30 bg-green-400/10", icon: CheckCircle },
    rejected: { label: "NOT SELECTED", className: "text-red-400 border-red-400/30 bg-red-400/10", icon: XCircle },
  };

  const showingEvents = filters.postType === "event";
  const categoryOptions = showingEvents
    ? EVENT_CATEGORIES
    : CATEGORIES;

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row gap-6 justify-between items-start lg:items-end">
        <div>
          <h1 className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-500 mb-2 glitch-text" data-text="OPPORTUNITY FEED">
            OPPORTUNITY FEED
          </h1>
          <p className="font-mono text-accent/80 text-sm md:text-base" data-testid="text-feed-subtitle">
            {showingEvents ? "Discover events, parties & happenings." : "Live gigs, tasks & services from the network."}
          </p>
        </div>

        <CreatePostModal />
      </div>

      <div className="p-4 rounded-xl bg-white/5 border border-white/10 backdrop-blur-sm space-y-4">
        <div className="flex gap-2" data-testid="toggle-feed-type">
          <Button
            variant={filters.postType === "all" ? "default" : "ghost"}
            size="sm"
            onClick={() => setFilters(prev => ({ ...prev, postType: "all", category: "All" }))}
            className="font-mono text-xs gap-1"
            data-testid="button-filter-all"
          >
            All
          </Button>
          <Button
            variant={filters.postType === "gig" ? "default" : "ghost"}
            size="sm"
            onClick={() => setFilters(prev => ({ ...prev, postType: "gig", category: "All" }))}
            className="font-mono text-xs gap-1"
            data-testid="button-filter-gigs"
          >
            <Briefcase className="w-3 h-3" />
            Paid Gigs
          </Button>
          <Button
            variant={filters.postType === "event" ? "default" : "ghost"}
            size="sm"
            onClick={() => setFilters(prev => ({ ...prev, postType: "event", category: "All" }))}
            className="font-mono text-xs gap-1"
            data-testid="button-filter-events"
          >
            <CalendarHeart className="w-3 h-3" />
            Free Events
          </Button>
        </div>

        {showingEvents && (
          <p className="font-mono text-[10px] text-gray-500 leading-relaxed border-t border-white/5 pt-2" data-testid="text-event-disclaimer">
            * "Free Events" means the host is not paying talent through this platform. Some events (battle raps, open mics, showcases, etc.) may charge a door fee or entry cost — check the description for details. If any payment is arranged between you and the host for these $0-listed opportunities, it must be handled directly between both parties off-platform. The Re-Up Spots is not responsible for any off-platform payment arrangements.
          </p>
        )}

        <div className="flex flex-col md:flex-row gap-4 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground w-4 h-4" />
            <Input
              placeholder={showingEvents ? "Search events, venues..." : "Search roles, venues, services..."}
              className="pl-9 bg-black/40 border-white/10 focus:border-primary font-mono h-10"
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
              data-testid="input-search"
            />
          </div>

          <Select
            value={filters.category}
            onValueChange={(val) => setFilters(prev => ({ ...prev, category: val }))}
          >
            <SelectTrigger className="w-full md:w-[200px] bg-black/40 border-white/10 font-mono h-10" data-testid="select-filter-category">
              <SelectValue placeholder="Category" />
            </SelectTrigger>
            <SelectContent className="bg-background border-white/10 max-h-[300px]">
              <SelectItem value="All" className="font-mono">All {showingEvents ? "Event Types" : "Categories"}</SelectItem>
              {categoryOptions.map(cat => (
                <SelectItem key={cat} value={cat} className="font-mono">{cat}</SelectItem>
              ))}
              {!showingEvents && isAgeVerified && (
                <SelectItem value="Adult/NSFW" className="font-mono text-red-400">Adult/NSFW</SelectItem>
              )}
              {showingEvents && isAgeVerified && (
                <SelectItem value="Adult Club Event" className="font-mono text-red-400">Adult Club Event</SelectItem>
              )}
            </SelectContent>
          </Select>

          <Select
            value={filters.sortBy}
            onValueChange={(val: any) => setFilters(prev => ({ ...prev, sortBy: val }))}
          >
            <SelectTrigger className="w-full md:w-[180px] bg-black/40 border-white/10 font-mono h-10" data-testid="select-sort">
              <SelectValue placeholder="Sort By" />
            </SelectTrigger>
            <SelectContent className="bg-background border-white/10">
              <SelectItem value="Newest" className="font-mono">Newest First</SelectItem>
              {!showingEvents && <SelectItem value="Pay" className="font-mono">Highest Pay</SelectItem>}
            </SelectContent>
          </Select>

          {isAgeVerified && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setFilters(prev => ({ ...prev, includeNsfw: !prev.includeNsfw }))}
              className={`font-mono text-xs h-10 gap-2 ${
                filters.includeNsfw ? "text-red-400" : "text-gray-500"
              }`}
              data-testid="button-toggle-nsfw"
            >
              {filters.includeNsfw ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              18+
            </Button>
          )}
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-64 rounded-xl bg-white/5 animate-pulse" />
          ))}
        </div>
      ) : error ? (
        <div className="text-center py-20 text-destructive font-mono border border-destructive/20 rounded-xl bg-destructive/5" data-testid="text-error">
          SYSTEM ERROR: Could not retrieve data stream.
        </div>
      ) : posts?.length === 0 ? (
        <div className="text-center py-20 text-muted-foreground font-mono" data-testid="text-empty">
          {showingEvents ? "NO EVENTS FOUND." : "NO SIGNALS FOUND."}
        </div>
      ) : (
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {posts?.map((post: any) => {
            const boosted = isBoostActive(post.boostExpiresAt);
            const application = getApplicationStatus(post.id);
            const appStatus = application?.status || null;
            const sc = appStatus ? statusConfig[appStatus] : null;
            const isEventPost = post.postType === "event";

            return (
              <motion.div
                key={post.id}
                variants={item}
                className={`cyber-card group rounded-xl p-6 flex flex-col h-full transition-all cursor-pointer ${
                  post.nsfw ? "border-red-500/20" : ""
                } ${isEventPost ? "border-cyan-500/20" : ""}
                ${boosted ? "shadow-lg shadow-primary/20 border-primary/30" : "hover:shadow-lg hover:shadow-primary/10"}`}
                data-testid={`card-post-${post.id}`}
                onClick={() => navigate(`/opportunity/${post.id}`)}
              >
                <div className="flex justify-between items-start mb-4 flex-wrap gap-1">
                  <div className="flex items-center gap-2">
                    {isEventPost && (
                      <span className="px-2 py-1 text-xs font-bold uppercase tracking-wider bg-cyan-500/10 text-cyan-300 rounded border border-cyan-500/20 flex items-center gap-1" data-testid={`badge-event-${post.id}`}>
                        <CalendarHeart className="w-3 h-3" /> EVENT
                      </span>
                    )}
                    <span className={`px-2 py-1 text-xs font-bold uppercase tracking-wider rounded border ${
                      post.nsfw
                        ? "bg-red-500/10 text-red-400 border-red-500/20"
                        : isEventPost
                          ? "bg-purple-500/10 text-purple-300 border-purple-500/20"
                          : "bg-primary/10 text-primary border-primary/20"
                    }`}>
                      {post.category}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    {post.nsfw && (
                      <span className="px-2 py-1 text-xs font-bold uppercase tracking-wider bg-red-500/10 text-red-400 rounded border border-red-500/20 flex items-center gap-1" data-testid={`badge-nsfw-${post.id}`}>
                        <ShieldAlert className="w-3 h-3" /> 18+
                      </span>
                    )}
                    {post.recurring && (
                      <span className="px-2 py-1 text-xs font-bold uppercase tracking-wider bg-cyan-500/10 text-cyan-400 rounded border border-cyan-500/20 flex items-center gap-1" data-testid={`badge-recurring-${post.id}`}>
                        <RefreshCw className="w-3 h-3" /> RECURRING
                      </span>
                    )}
                    {boosted && (
                      <span className="px-2 py-1 text-xs font-bold uppercase tracking-wider bg-accent/10 text-accent rounded border border-accent/20 flex items-center gap-1" data-testid={`badge-boosted-${post.id}`}>
                        <Flame className="w-3 h-3" /> BOOSTED
                      </span>
                    )}
                    {!isEventPost && (
                      <span className="text-xs font-mono text-muted-foreground">
                        {post.tier}
                      </span>
                    )}
                  </div>
                </div>

                <h3 className="text-xl font-bold font-display text-white mb-2 group-hover:text-primary transition-colors line-clamp-2" data-testid={`text-post-title-${post.id}`}>
                  {post.title}
                </h3>

                <div className="space-y-3 font-mono text-sm text-gray-400 mb-6 flex-1">
                  {isEventPost ? (
                    <div className="flex items-center gap-2">
                      <CalendarHeart className="w-4 h-4 text-cyan-400" />
                      <span className="text-cyan-300 font-bold" data-testid={`text-post-free-${post.id}`}>FREE EVENT</span>
                    </div>
                  ) : (
                    <>
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-4 h-4 text-accent" />
                        <span className="text-white font-bold text-lg" data-testid={`text-post-pay-${post.id}`}>${post.pay}</span>
                      </div>
                      {post.pay === 0 && (
                        <p className="font-mono text-[10px] text-yellow-500/70 leading-tight" data-testid={`text-zero-disclaimer-${post.id}`}>
                          * $0 — no payment through platform. See details.
                        </p>
                      )}
                    </>
                  )}
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    <span>{post.promoterName}</span>
                  </div>
                  {post.venue && (
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      <span className="truncate">{post.venue}</span>
                    </div>
                  )}
                  {post.date && (
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      <span>{post.date}</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-2 mt-auto">
                  {isEventPost ? (
                    <Button
                      variant="ghost"
                      className="flex-1 font-mono text-xs font-bold uppercase tracking-wider text-cyan-400 border border-cyan-500/30 bg-cyan-500/10"
                      data-testid={`button-view-event-${post.id}`}
                      onClick={(e: React.MouseEvent) => {
                        e.stopPropagation();
                        navigate(`/opportunity/${post.id}`);
                      }}
                    >
                      VIEW EVENT
                    </Button>
                  ) : appStatus && sc ? (
                    <div className={`flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border font-mono text-xs font-bold uppercase tracking-wider ${sc.className}`}
                      data-testid={`badge-application-status-${post.id}`}>
                      <sc.icon className="w-4 h-4" />
                      {sc.label}
                    </div>
                  ) : (
                    <button
                      type="button"
                      className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg border border-primary/30 bg-primary/10 font-mono text-xs font-bold uppercase tracking-wider text-primary"
                      data-testid={`button-apply-${post.id}`}
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApply(post.id);
                      }}
                      disabled={applyToPost.isPending}
                    >
                      APPLY NOW
                    </button>
                  )}
                  <Button
                    variant="ghost"
                    size="icon"
                    data-testid={`button-share-${post.id}`}
                    onClick={(e: React.MouseEvent) => copyOpportunityLink(post.id, e)}
                    title="Copy link"
                  >
                    {copiedPostId === post.id ? (
                      <Check className="w-4 h-4 text-green-400" />
                    ) : (
                      <Share2 className="w-4 h-4" />
                    )}
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    data-testid={`button-details-${post.id}`}
                    onClick={(e: React.MouseEvent) => {
                      e.stopPropagation();
                      navigate(`/opportunity/${post.id}`);
                    }}
                  >
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </motion.div>
      )}
    </div>
  );
}
