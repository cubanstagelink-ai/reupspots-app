import { motion } from "framer-motion";
import { ShieldCheck, AlertTriangle, Zap } from "lucide-react";

export default function Rules() {
  return (
    <div className="max-w-3xl mx-auto space-y-12 py-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl md:text-6xl font-black font-display text-transparent bg-clip-text bg-gradient-to-br from-white to-gray-600">
          NETWORK PROTOCOLS
        </h1>
        <p className="font-mono text-accent text-lg">Read carefully before engaging.</p>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="cyber-card p-8 rounded-2xl border border-primary/20"
      >
        <div className="flex items-center gap-4 mb-6">
          <ShieldCheck className="w-10 h-10 text-primary" />
          <h2 className="text-2xl font-bold font-display text-white">1. TRANSPARENCY MANDATE</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed space-y-3">
          <p>All listings on The Re-Up Spots must clearly and accurately state:</p>
          <ul className="list-disc list-inside space-y-1 pl-2">
            <li>Pay amount</li>
            <li>Opportunity tier</li>
            <li>Venue or location (if applicable)</li>
          </ul>
          <p>Hidden fees, misleading compensation, "exposure-only" offers, or vague payment terms are strictly prohibited. Violators may be removed from the platform without refund of any platform fees or credits.</p>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.2 }}
        className="cyber-card p-8 rounded-2xl border border-accent/20"
      >
        <div className="flex items-center gap-4 mb-6">
          <Zap className="w-10 h-10 text-accent" />
          <h2 className="text-2xl font-bold font-display text-white">2. DIRECT TRANSACTIONS</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed space-y-3">
          <p>The Re-Up Spots is a connection and discovery platform only. All financial transactions occur directly between Promoter and Talent via Cash App or other mutually agreed payment methods.</p>
          <p>The Re-Up Spots:</p>
          <ul className="list-disc list-inside space-y-1 pl-2">
            <li>Does not process payments</li>
            <li>Does not hold funds</li>
            <li>Takes 0% percentage-based commission from talent earnings</li>
          </ul>
        </div>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.4 }}
        className="cyber-card p-8 rounded-2xl border border-destructive/20"
      >
        <div className="flex items-center gap-4 mb-6">
          <AlertTriangle className="w-10 h-10 text-destructive" />
          <h2 className="text-2xl font-bold font-display text-white">3. PROFESSIONAL CONDUCT</h2>
        </div>
        <div className="font-mono text-gray-400 leading-relaxed space-y-3">
          <p>All users are expected to act professionally:</p>
          <ul className="list-disc list-inside space-y-1 pl-2">
            <li>Respect venues, equipment, schedules, and agreements</li>
            <li>Late arrivals, no-shows, or unprofessional behavior may be flagged in The Re-Up Spots's internal reputation system</li>
          </ul>
          <p>Repeated violations (three strikes) may result in indefinite suspension or removal from the platform.</p>
        </div>
      </motion.div>
    </div>
  );
}
