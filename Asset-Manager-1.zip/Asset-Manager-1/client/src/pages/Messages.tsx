import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { CyberButton } from "@/components/CyberButton";
import { Input } from "@/components/ui/input";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { motion } from "framer-motion";
import { MessageSquare, Send, ArrowLeft } from "lucide-react";

interface Conversation {
  partnerId: string;
  partnerName?: string;
  lastMessage: string;
  lastAt: string;
  unreadCount: number;
}

interface ChatMessage {
  id: number;
  fromUserId: string;
  toUserId: string;
  content: string;
  read: boolean;
  createdAt: string;
}

export default function Messages() {
  const { user, isAuthenticated, isLoading: authLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedPartner, setSelectedPartner] = useState<string | null>(null);
  const [messageInput, setMessageInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const { data: conversations, isLoading: convLoading } = useQuery<Conversation[]>({
    queryKey: ["/api/conversations"],
    enabled: isAuthenticated,
    refetchInterval: 5000,
  });

  const { data: chatMessages, isLoading: chatLoading } = useQuery<ChatMessage[]>({
    queryKey: ["/api/messages", selectedPartner],
    enabled: !!selectedPartner,
    refetchInterval: 3000,
  });

  const sendMessage = useMutation({
    mutationFn: async () => {
      if (!messageInput.trim() || !selectedPartner) return;
      const res = await apiRequest("POST", "/api/messages", {
        toUserId: selectedPartner,
        content: messageInput.trim(),
      });
      return res.json();
    },
    onSuccess: () => {
      setMessageInput("");
      queryClient.invalidateQueries({ queryKey: ["/api/messages", selectedPartner] });
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  const markRead = useMutation({
    mutationFn: async (partnerId: string) => {
      await apiRequest("POST", `/api/messages/${partnerId}/read`, {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversations"] });
    },
  });

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  useEffect(() => {
    if (selectedPartner) {
      markRead.mutate(selectedPartner);
    }
  }, [selectedPartner]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (messageInput.trim()) sendMessage.mutate();
  };

  if (authLoading) return <div className="p-20 text-center font-mono animate-pulse">AUTHENTICATING...</div>;

  if (!isAuthenticated) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center space-y-6">
        <MessageSquare className="w-16 h-16 text-accent" />
        <h1 className="text-3xl font-display font-bold">DIRECT MESSAGES</h1>
        <p className="font-mono text-muted-foreground">You must be logged in to access messages.</p>
        <a href="/api/login"><CyberButton>Connect Node</CyberButton></a>
      </div>
    );
  }

  const userId = (user as any)?.claims?.sub || (user as any)?.id;

  return (
    <div className="max-w-4xl mx-auto py-4">
      <h1 className="text-3xl font-black font-display text-white mb-6" data-testid="text-messages-title">
        DIRECT MESSAGES
      </h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[calc(100vh-280px)] min-h-[400px]">
        <div className={`bg-black/40 border border-white/10 rounded-xl overflow-hidden flex flex-col ${selectedPartner ? 'hidden md:flex' : ''}`}>
          <div className="p-4 border-b border-white/10">
            <h2 className="font-display font-bold text-accent text-sm uppercase">Conversations</h2>
          </div>
          <div className="flex-1 overflow-y-auto">
            {convLoading && <p className="p-4 font-mono text-sm text-muted-foreground animate-pulse">Loading...</p>}
            {!convLoading && (!conversations || conversations.length === 0) && (
              <div className="p-6 text-center">
                <MessageSquare className="w-8 h-8 text-muted-foreground mx-auto mb-3" />
                <p className="font-mono text-sm text-muted-foreground">No messages yet</p>
                <p className="font-mono text-xs text-muted-foreground mt-1">Visit a performer's profile to start a conversation</p>
              </div>
            )}
            {conversations?.map((conv) => (
              <button
                key={conv.partnerId}
                onClick={() => setSelectedPartner(conv.partnerId)}
                className={`w-full text-left p-4 border-b border-white/5 hover:bg-white/5 transition-colors ${
                  selectedPartner === conv.partnerId ? 'bg-primary/10 border-l-2 border-l-primary' : ''
                }`}
                data-testid={`button-conversation-${conv.partnerId}`}
              >
                <div className="flex items-center justify-between mb-1 gap-2">
                  <span className="font-mono text-sm text-white font-bold truncate">
                    {conv.partnerName || conv.partnerId.slice(0, 12)}
                  </span>
                  {conv.unreadCount > 0 && (
                    <span className="bg-primary text-white text-xs font-bold px-2 py-0.5 rounded-full shrink-0">
                      {conv.unreadCount}
                    </span>
                  )}
                </div>
                <p className="font-mono text-xs text-muted-foreground truncate">{conv.lastMessage}</p>
                <p className="font-mono text-xs text-muted-foreground/50 mt-1">
                  {new Date(conv.lastAt).toLocaleDateString()}
                </p>
              </button>
            ))}
          </div>
        </div>

        <div className={`md:col-span-2 bg-black/40 border border-white/10 rounded-xl overflow-hidden flex flex-col ${!selectedPartner ? 'hidden md:flex' : ''}`}>
          {selectedPartner ? (
            <>
              <div className="p-4 border-b border-white/10 flex items-center gap-3">
                <button onClick={() => setSelectedPartner(null)} className="md:hidden text-muted-foreground hover:text-white">
                  <ArrowLeft className="w-5 h-5" />
                </button>
                <h2 className="font-mono text-sm text-white font-bold">
                  {conversations?.find(c => c.partnerId === selectedPartner)?.partnerName || selectedPartner.slice(0, 12)}
                </h2>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3">
                {chatLoading && <p className="font-mono text-sm text-muted-foreground animate-pulse text-center">Loading messages...</p>}
                {chatMessages?.map((msg) => {
                  const isMine = msg.fromUserId === userId;
                  return (
                    <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[75%] rounded-lg px-4 py-2 ${
                        isMine
                          ? 'bg-primary/20 border border-primary/30 text-white'
                          : 'bg-white/5 border border-white/10 text-gray-300'
                      }`} data-testid={`message-${msg.id}`}>
                        <p className="font-mono text-sm">{msg.content}</p>
                        <p className="font-mono text-xs text-muted-foreground mt-1">
                          {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </p>
                      </div>
                    </div>
                  );
                })}
                <div ref={messagesEndRef} />
              </div>

              <form onSubmit={handleSend} className="p-4 border-t border-white/10 flex gap-2">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder="Type a message..."
                  className="bg-black/40 border-white/10 font-mono flex-1"
                  data-testid="input-message"
                />
                <CyberButton
                  type="submit"
                  variant="accent"
                  loading={sendMessage.isPending}
                  disabled={!messageInput.trim()}
                  data-testid="button-send-message"
                >
                  <Send className="w-4 h-4" />
                </CyberButton>
              </form>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center">
              <div className="text-center">
                <MessageSquare className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="font-mono text-sm text-muted-foreground">Select a conversation to start chatting</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
